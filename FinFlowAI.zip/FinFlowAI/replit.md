# BusinessAnalytics Pro - Система бизнес-аналитики

## Overview

BusinessAnalytics Pro is a comprehensive business analytics system designed specifically for Russian small and medium businesses. The application provides daily income/expense tracking, automated tax calculations for Russian tax regimes, 24 analytical tools, and seamless integration with 1C:Бухгалтерия. The system follows a Carbon Design approach optimized for data-rich professional interfaces, featuring a dark mode theme with teal accents for optimal readability during extended financial analysis sessions.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript, built using Vite
- **UI Components**: Radix UI primitives with shadcn/ui component library
- **Styling**: Tailwind CSS with custom design tokens following Carbon Design principles
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query for server state, React Context for UI state
- **Charts & Analytics**: Recharts library for data visualization

### Backend Architecture  
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **API Design**: RESTful API structure with `/api` prefix
- **Session Management**: Implemented using connect-pg-simple for PostgreSQL session store
- **Development**: Hot module replacement via Vite middleware integration

### Data Models
The system uses a comprehensive schema supporting:
- **User Management**: Multi-role authentication (admin, analyst, user)
- **Company Management**: Organization data with Russian tax system support (USN, OSNO, Patent)  
- **Financial Data**: Imported data from 1C, manual data entry with period breakdown, analytical reports
- **Reporting Periods**: Flexible period management (daily/monthly/quarterly/annual) with manual financial data input
- **Test Data Generation**: Automated generation of realistic financial data for demonstration and testing purposes

### Authentication & Authorization
- JWT-based authentication with role-based access control
- Session-based state management for persistent login
- Role hierarchy supporting admin, analyst, and standard user permissions

### Analytics Engine
The system implements 24 specialized analytical tools categorized into:
- **Financial Health**: Cash flow analysis, liquidity ratios, profitability metrics
- **Sales Analytics**: Conversion tracking, revenue analysis, sales pipeline management  
- **Budget Planning**: Income/expense forecasting, budget variance analysis
- **Tax Compliance**: Automated calculations for Russian tax regimes with quarterly reporting
- **Data Entry Tools**: Manual financial data input with period breakdown and automated test data generation

### Design System
- **Color Palette**: Dark mode primary with teal accent (#20B8C6) for positive metrics, red for negative values
- **Typography**: Inter font family with specialized mono fonts for financial data
- **Component Architecture**: Consistent spacing system (4px base units), elevation patterns for card hierarchy
- **Responsive Design**: Mobile-first approach with breakpoints at 768px for tablet/desktop layouts

## Recent Changes (September 2025)

### Manual Financial Data Entry System
- **New Schema**: Added `manualFinancialData` table supporting comprehensive financial metrics input
- **API Endpoints**: Full CRUD operations for financial data management (`POST/GET/PUT/DELETE /api/financial-data`)
- **Test Data Generation**: Intelligent generation of realistic financial data via `/api/financial-data/generate-test`
- **Zod Validation**: Robust data validation with support for both Date objects and ISO strings
- **Period Flexibility**: Support for daily, monthly, quarterly, and annual data entry periods
- **Financial Metrics**: Complete coverage of P&L, balance sheet, and cash flow indicators
- **Mobile Optimization**: Touch-friendly interface with ≥44px touch targets for mobile devices

### Technical Implementation Details
- **Storage Layer**: In-memory storage with full CRUD operations for development/testing
- **Data Validation**: Enhanced Zod schemas with automatic type coercion for date handling
- **User Interface**: Tabbed interface with manual entry and automated test data generation
- **API Integration**: Seamless frontend-backend communication with proper error handling
- **Progress Indicators**: Real-time feedback during test data generation processes
- **Toast Notifications**: User-friendly success/error messaging in Russian localization

### Quality Assurance
- **End-to-End Testing**: Verified complete workflow from data generation to storage persistence  
- **Mobile Compatibility**: All components tested for responsive design and touch interactions
- **Error Handling**: Comprehensive validation and user feedback for all error scenarios
- **Data Integrity**: Proper financial ratio calculations with realistic business data patterns

## External Dependencies

### Core Framework Dependencies
- **React Ecosystem**: React 18, React DOM, TanStack Query for data fetching
- **UI Components**: Complete Radix UI suite including dialogs, dropdowns, forms, navigation
- **Styling**: Tailwind CSS with PostCSS, class-variance-authority for component variants
- **Development**: Vite build system, TypeScript for type safety, ESBuild for production builds

### Backend Dependencies
- **Database**: PostgreSQL via @neondatabase/serverless, Drizzle ORM with Zod validation
- **Server**: Express.js with session management via connect-pg-simple
- **Development Tools**: tsx for TypeScript execution, Drizzle Kit for database migrations

### Chart & Analytics Libraries
- **Recharts**: Primary charting library for line charts, bar charts, pie charts
- **Data Manipulation**: Built-in JavaScript analytics with date-fns for date handling

### Russian Business Integration
- **1C:Бухгалтерия Import**: Custom parsing logic for Russian accounting software integration
- **Tax Calculation**: Native implementation of Russian tax regimes (УСН, ОСНО, Патент)
- **Reporting Standards**: Compliance with Russian financial reporting requirements

### Development & Deployment
- **Replit Integration**: @replit/vite-plugin-runtime-error-modal and cartographer for development
- **Build Process**: Vite for frontend, ESBuild for backend compilation
- **Environment**: Node.js with ES modules, TypeScript configuration for both client and server