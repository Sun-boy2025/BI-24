import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, decimal, json, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Пользователи системы
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  role: text("role").notNull().default("user"), // admin, analyst, user
  createdAt: timestamp("created_at").defaultNow(),
});

// Организации/компании
export const companies = pgTable("companies", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  inn: text("inn").notNull().unique(),
  kpp: text("kpp"),
  taxSystem: text("tax_system").notNull(), // USN, OSNO, Patent
  userId: varchar("user_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

// Периоды отчетности
export const reportingPeriods = pgTable("reporting_periods", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  companyId: varchar("company_id").references(() => companies.id),
  year: integer("year").notNull(),
  quarter: integer("quarter"), // 1-4, null для годового
  month: integer("month"), // 1-12, null если не месячный
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Импортированные данные из 1С
export const importedData = pgTable("imported_data", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  companyId: varchar("company_id").references(() => companies.id),
  periodId: varchar("period_id").references(() => reportingPeriods.id),
  dataType: text("data_type").notNull(), // balance_sheet, profit_loss, cash_flow, etc
  rawData: json("raw_data").notNull(),
  processedData: json("processed_data"),
  importedAt: timestamp("imported_at").defaultNow(),
  status: text("status").default("processed"), // imported, processed, error
});

// Аналитические отчеты
export const analyticalReports = pgTable("analytical_reports", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  companyId: varchar("company_id").references(() => companies.id),
  periodId: varchar("period_id").references(() => reportingPeriods.id),
  reportType: text("report_type").notNull(), // один из 24 типов отчетов
  reportData: json("report_data").notNull(),
  generatedAt: timestamp("generated_at").defaultNow(),
  generatedBy: varchar("generated_by").references(() => users.id),
});

// Экспортированные файлы
export const exportedFiles = pgTable("exported_files", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  reportId: varchar("report_id").references(() => analyticalReports.id),
  fileName: text("file_name").notNull(),
  fileType: text("file_type").notNull(), // PDF, XLSX
  filePath: text("file_path").notNull(),
  exportedAt: timestamp("exported_at").defaultNow(),
  exportedBy: varchar("exported_by").references(() => users.id),
});

// AI-анализы и рекомендации
export const aiAnalyses = pgTable("ai_analyses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  companyId: varchar("company_id").references(() => companies.id),
  reportId: varchar("report_id").references(() => analyticalReports.id),
  analysisType: text("analysis_type").notNull(), // trend, recommendation, forecast
  analysisResult: json("analysis_result").notNull(),
  confidence: decimal("confidence", { precision: 3, scale: 2 }),
  createdAt: timestamp("created_at").defaultNow(),
});

// Справочник аналитических инструментов
export const analyticalInstruments = pgTable("analytical_instruments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  instrumentNumber: integer("instrument_number").notNull().unique(), // 1-25
  instrumentKey: text("instrument_key").notNull().unique(), // платежный_календарь, dds_классический, etc
  title: text("title").notNull(),
  category: text("category").notNull(),
  description: text("description"),
  
  // Поля для каждого типа данных инструмента
  manualInputFields: json("manual_input_fields").notNull(), // Поля для ручного ввода
  editableCalculationFields: json("editable_calculation_fields").notNull(), // Редактируемые параметры расчета
  autoCalculatedFields: json("auto_calculated_fields").notNull(), // Автоматически рассчитываемые поля
  
  // Дополнительные метаданные
  mainFormulas: json("main_formulas"), // Основные формулы
  keyMetrics: json("key_metrics"), // Ключевые метрики
  calculationAlgorithm: json("calculation_algorithm"), // Алгоритм расчета
  
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Иерархические периоды данных
export const dataPeriods = pgTable("data_periods", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  companyId: varchar("company_id").references(() => companies.id).notNull(),
  
  // Иерархия периодов
  parentId: varchar("parent_id").references(() => dataPeriods.id), // Ссылка на родительский период
  periodType: text("period_type").notNull(), // year, quarter, month, day
  
  // Временные характеристики
  year: integer("year").notNull(),
  quarter: integer("quarter"), // 1-4 для квартальных периодов
  month: integer("month"), // 1-12 для месячных периодов
  day: integer("day"), // 1-31 для дневных периодов
  periodDate: timestamp("period_date").notNull(), // Точная дата периода
  
  // Метаданные
  isExpanded: boolean("is_expanded").default(false), // Раскрыт ли период в UI
  hasData: boolean("has_data").default(false), // Есть ли данные за этот период
  createdAt: timestamp("created_at").defaultNow(),
});

// Основная таблица данных для аналитических инструментов
export const instrumentData = pgTable("instrument_data", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  companyId: varchar("company_id").references(() => companies.id).notNull(),
  instrumentId: varchar("instrument_id").references(() => analyticalInstruments.id).notNull(),
  periodId: varchar("period_id").references(() => dataPeriods.id).notNull(),
  
  // Данные инструмента по типам полей
  manualInputData: json("manual_input_data").default('{}'), // Данные ручного ввода
  editableCalculationData: json("editable_calculation_data").default('{}'), // Редактируемые параметры
  autoCalculatedData: json("auto_calculated_data").default('{}'), // Рассчитанные данные
  
  // Финансовое движение (основные показатели)
  transactionType: text("transaction_type"), // income, expense, transfer
  transactionCategory: text("transaction_category"), // sales, purchases, salaries, etc.
  amount: decimal("amount", { precision: 15, scale: 2 }), // Сумма операции
  description: text("description"), // Описание операции
  
  // Метаданные
  isCalculated: boolean("is_calculated").default(false), // Рассчитаны ли auto_calculated поля
  lastCalculatedAt: timestamp("last_calculated_at"),
  notes: text("notes"),
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Индексы для производительности
// CREATE INDEX idx_instrument_data_company_instrument ON instrument_data(company_id, instrument_id);
// CREATE INDEX idx_instrument_data_period ON instrument_data(period_id);
// CREATE INDEX idx_data_periods_parent ON data_periods(parent_id);
// CREATE INDEX idx_data_periods_company_date ON data_periods(company_id, period_date);

// Шаблоны для генерации тестовых данных
export const testDataTemplates = pgTable("test_data_templates", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  businessType: text("business_type").notNull(), // retail, manufacturing, services, etc
  templateData: json("template_data").notNull(), // Шаблон для генерации данных
  createdAt: timestamp("created_at").defaultNow(),
});

// Типы отчетов для валидации
export const REPORT_TYPES = [
  "financial_health",
  "profitability_analysis", 
  "liquidity_ratios",
  "debt_analysis",
  "efficiency_ratios",
  "growth_trends",
  "cash_flow_analysis", 
  "break_even_analysis",
  "cost_structure",
  "revenue_analysis",
  "margin_analysis",
  "working_capital",
  "inventory_turnover",
  "receivables_analysis",
  "payables_analysis",
  "tax_optimization",
  "budget_variance",
  "forecast_accuracy",
  "seasonal_analysis",
  "competitor_benchmarking",
  "risk_assessment",
  "investment_analysis",
  "performance_kpi",
  "executive_dashboard"
] as const;

// Зодовые схемы для валидации
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  fullName: true,
  role: true,
});

// Схемы для новых таблиц
export const insertAnalyticalInstrumentSchema = createInsertSchema(analyticalInstruments).pick({
  instrumentNumber: true,
  instrumentKey: true,
  title: true,
  category: true,
  description: true,
  manualInputFields: true,
  editableCalculationFields: true,
  autoCalculatedFields: true,
  mainFormulas: true,
  keyMetrics: true,
  calculationAlgorithm: true,
});

export const insertDataPeriodSchema = createInsertSchema(dataPeriods).pick({
  companyId: true,
  parentId: true,
  periodType: true,
  year: true,
  quarter: true,
  month: true,
  day: true,
  periodDate: true,
  isExpanded: true,
  hasData: true,
}).extend({
  periodDate: z.union([z.date(), z.string()]).transform((val) => {
    if (typeof val === 'string') {
      return new Date(val);
    }
    return val;
  }),
});

export const insertInstrumentDataSchema = createInsertSchema(instrumentData).pick({
  companyId: true,
  instrumentId: true,
  periodId: true,
  manualInputData: true,
  editableCalculationData: true,
  autoCalculatedData: true,
  transactionType: true,
  transactionCategory: true,
  amount: true,
  description: true,
  notes: true,
  createdBy: true,
});

export const insertTestDataTemplateSchema = createInsertSchema(testDataTemplates).pick({
  name: true,
  description: true,
  businessType: true,
  templateData: true,
});

export const insertCompanySchema = createInsertSchema(companies).pick({
  name: true,
  inn: true,
  kpp: true,
  taxSystem: true,
  userId: true,
});

export const insertReportingPeriodSchema = createInsertSchema(reportingPeriods).pick({
  companyId: true,
  year: true,
  quarter: true,
  month: true,
});

export const insertImportedDataSchema = createInsertSchema(importedData).pick({
  companyId: true,
  periodId: true,
  dataType: true,
  rawData: true,
});

export const insertAnalyticalReportSchema = createInsertSchema(analyticalReports).pick({
  companyId: true,
  periodId: true,
  reportType: true,
  reportData: true,
  generatedBy: true,
});

// Типы для TypeScript
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertCompany = z.infer<typeof insertCompanySchema>;
export type Company = typeof companies.$inferSelect;

export type InsertReportingPeriod = z.infer<typeof insertReportingPeriodSchema>;
export type ReportingPeriod = typeof reportingPeriods.$inferSelect;

export type InsertImportedData = z.infer<typeof insertImportedDataSchema>;
export type ImportedData = typeof importedData.$inferSelect;

export type InsertAnalyticalReport = z.infer<typeof insertAnalyticalReportSchema>;
export type AnalyticalReport = typeof analyticalReports.$inferSelect;

export type InsertAnalyticalInstrument = z.infer<typeof insertAnalyticalInstrumentSchema>;
export type AnalyticalInstrument = typeof analyticalInstruments.$inferSelect;

export type InsertDataPeriod = z.infer<typeof insertDataPeriodSchema>;
export type DataPeriod = typeof dataPeriods.$inferSelect;

export type InsertInstrumentData = z.infer<typeof insertInstrumentDataSchema>;
export type InstrumentData = typeof instrumentData.$inferSelect;

export type InsertTestDataTemplate = z.infer<typeof insertTestDataTemplateSchema>;
export type TestDataTemplate = typeof testDataTemplates.$inferSelect;

export type ExportedFile = typeof exportedFiles.$inferSelect;
export type AIAnalysis = typeof aiAnalyses.$inferSelect;

export type ReportType = typeof REPORT_TYPES[number];
export type TaxSystem = "USN" | "OSNO" | "Patent";
export type UserRole = "admin" | "analyst" | "user";
export type PeriodType = "day" | "month" | "quarter" | "year";
export type BusinessType = "retail" | "manufacturing" | "services" | "consulting" | "ecommerce";
export type TransactionType = "income" | "expense" | "transfer";

// Константы для аналитических инструментов
export const ANALYTICAL_INSTRUMENTS = [
  "01_platezhnyy_kalendar",
  "02_dds_klassicheskiy", 
  "03_finansovaya_model",
  "04_vliyanie_skidki",
  "05_abc_analiz",
  "06_otchet_otdela_prodazh",
  "07_faktory_prodazh", 
  "08_sebestoimost_tovara",
  "09_tochka_bezubytochnosti",
  "10_operatsionnyy_rychag",
  "11_plan_dokhodov_rashodov",
  "12_kalkulyator_finansovogo_rychaga",
  "13_pokazateli_likvidnosti",
  "14_pokazateli_finansovoy_ustoychivosti",
  "15_analiz_struktury_kapitala",
  "16_analiz_debitorskoy_zadolzhennosti",
  "17_analiz_kreditorstkoy_zadolzhennosti",
  "18_analiz_oborotnyh_sredstv",
  "19_cash_conversion_cycle",
  "20_dupont_analiz",
  "21_analiz_investitsionnoy_privlekatelnosti",
  "22_analiz_rentabelnosti",
  "23_analiz_likvidnosti",
  "24_byudzhetirovanie_i_planirovanie",
  "25_kompleksnaya_otsenka_biznesa"
] as const;

export type InstrumentKey = typeof ANALYTICAL_INSTRUMENTS[number];

// Расширенные типы для иерархических структур
export type HierarchicalDataPeriod = DataPeriod & {
  children?: HierarchicalDataPeriod[];
};