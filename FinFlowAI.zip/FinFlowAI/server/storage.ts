import { 
  type User, 
  type InsertUser,
  type AnalyticalInstrument,
  type InsertAnalyticalInstrument,
  type DataPeriod,
  type InsertDataPeriod,
  type InstrumentData,
  type InsertInstrumentData,
  type InstrumentKey,
  type PeriodType,
  type TransactionType,
  type HierarchicalDataPeriod
} from "@shared/schema";
import { randomUUID } from "crypto";

// Интерфейс для управления данными системы бизнес-аналитики

export interface IStorage {
  // User management
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Analytical Instruments management
  getInstruments(): Promise<AnalyticalInstrument[]>;
  getInstrument(id: string): Promise<AnalyticalInstrument | undefined>;
  getInstrumentByKey(key: InstrumentKey): Promise<AnalyticalInstrument | undefined>;
  createInstrument(instrument: InsertAnalyticalInstrument): Promise<AnalyticalInstrument>;
  updateInstrument(id: string, instrument: Partial<InsertAnalyticalInstrument>): Promise<AnalyticalInstrument | undefined>;
  
  // Data Periods management (hierarchical)
  getDataPeriods(companyId: string, parentId?: string): Promise<DataPeriod[]>;
  getDataPeriod(id: string): Promise<DataPeriod | undefined>;
  createDataPeriod(period: InsertDataPeriod): Promise<DataPeriod>;
  updateDataPeriod(id: string, period: Partial<InsertDataPeriod>): Promise<DataPeriod | undefined>;
  deleteDataPeriod(id: string): Promise<boolean>;
  
  // Get hierarchical period tree for a company
  getPeriodHierarchy(companyId: string, year: number): Promise<HierarchicalDataPeriod[]>;
  
  // Toggle period expansion state
  togglePeriodExpansion(periodId: string): Promise<DataPeriod | undefined>;
  
  // Instrument Data management
  getInstrumentData(companyId: string, instrumentId?: string, periodId?: string): Promise<InstrumentData[]>;
  getInstrumentDataItem(id: string): Promise<InstrumentData | undefined>;
  createInstrumentData(data: InsertInstrumentData): Promise<InstrumentData>;
  updateInstrumentData(id: string, data: Partial<InsertInstrumentData>): Promise<InstrumentData | undefined>;
  deleteInstrumentData(id: string): Promise<boolean>;
  
  // Get data for specific instrument and period hierarchy
  getInstrumentDataByPeriod(companyId: string, instrumentId: string, periodId: string): Promise<InstrumentData[]>;
  
  // Financial transactions (money movements)
  getFinancialTransactions(companyId: string, periodId?: string, transactionType?: TransactionType): Promise<InstrumentData[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private instruments: Map<string, AnalyticalInstrument>;
  private dataPeriods: Map<string, DataPeriod>;
  private instrumentData: Map<string, InstrumentData>;

  constructor() {
    this.users = new Map();
    this.instruments = new Map();
    this.dataPeriods = new Map();
    this.instrumentData = new Map();
    
    // Initialize with basic analytical instruments
    this.initializeInstruments();
  }

  private initializeInstruments() {
    // Initialize with first 5 instruments for demo
    const basicInstruments = [
      {
        id: randomUUID(),
        instrumentNumber: 1,
        instrumentKey: "01_platezhnyy_kalendar" as InstrumentKey,
        title: "Платежный календарь",
        category: "cash_flow_management",
        description: "Планирование денежных потоков компании по датам, предотвращение кассовых разрывов",
        manualInputFields: {
          initial_balance: { type: "number", label: "Начальный остаток" },
          planned_receipts: { type: "object", label: "Планируемые поступления по дням" },
          planned_payments: { type: "object", label: "Планируемые платежи по дням" }
        },
        editableCalculationFields: {
          forecast_period_days: { type: "number", label: "Период прогнозирования в днях", default: 90 },
          critical_balance_level: { type: "number", label: "Критический уровень остатка", default: 0 }
        },
        autoCalculatedFields: {
          daily_balance: { type: "array", label: "Остаток на каждый день" },
          cash_gaps: { type: "array", label: "Кассовые разрывы" }
        },
        isActive: true,
        createdAt: new Date()
      },
      {
        id: randomUUID(),
        instrumentNumber: 2,
        instrumentKey: "02_dds_klassicheskiy" as InstrumentKey,
        title: "ДДС классический",
        category: "cash_flow_analysis",
        description: "Анализ движения денежных средств по операционной, инвестиционной и финансовой деятельности",
        manualInputFields: {
          operating_receipts: { type: "object", label: "Поступления от операционной деятельности" },
          operating_payments: { type: "object", label: "Платежи по операционной деятельности" },
          investing_receipts: { type: "object", label: "Поступления от инвестиционной деятельности" }
        },
        editableCalculationFields: {
          analysis_period_months: { type: "number", label: "Период анализа в месяцах", default: 12 }
        },
        autoCalculatedFields: {
          operating_cash_flow: { type: "number", label: "Операционный денежный поток" },
          net_cash_flow: { type: "number", label: "Чистый денежный поток" }
        },
        isActive: true,
        createdAt: new Date()
      }
    ];

    basicInstruments.forEach(instrument => {
      this.instruments.set(instrument.id, instrument);
    });
  }

  // User management
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser,
      role: insertUser.role || 'user',
      id, 
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  // Analytical Instruments management
  async getInstruments(): Promise<AnalyticalInstrument[]> {
    return Array.from(this.instruments.values()).sort((a, b) => a.instrumentNumber - b.instrumentNumber);
  }

  async getInstrument(id: string): Promise<AnalyticalInstrument | undefined> {
    return this.instruments.get(id);
  }

  async getInstrumentByKey(key: InstrumentKey): Promise<AnalyticalInstrument | undefined> {
    return Array.from(this.instruments.values()).find(
      (instrument) => instrument.instrumentKey === key,
    );
  }

  async createInstrument(insertInstrument: InsertAnalyticalInstrument): Promise<AnalyticalInstrument> {
    const id = randomUUID();
    const instrument: AnalyticalInstrument = {
      ...insertInstrument,
      id,
      isActive: true,
      createdAt: new Date()
    };
    this.instruments.set(id, instrument);
    return instrument;
  }

  async updateInstrument(id: string, updateData: Partial<InsertAnalyticalInstrument>): Promise<AnalyticalInstrument | undefined> {
    const existing = this.instruments.get(id);
    if (!existing) {
      return undefined;
    }
    
    const updated: AnalyticalInstrument = {
      ...existing,
      ...updateData
    };
    
    this.instruments.set(id, updated);
    return updated;
  }

  // Data Periods management
  async getDataPeriods(companyId: string, parentId?: string): Promise<DataPeriod[]> {
    let results = Array.from(this.dataPeriods.values()).filter(
      period => period.companyId === companyId
    );
    
    if (parentId !== undefined) {
      results = results.filter(period => period.parentId === parentId);
    }
    
    return results.sort((a, b) => new Date(a.periodDate).getTime() - new Date(b.periodDate).getTime());
  }

  async getDataPeriod(id: string): Promise<DataPeriod | undefined> {
    return this.dataPeriods.get(id);
  }

  async createDataPeriod(insertPeriod: InsertDataPeriod): Promise<DataPeriod> {
    // Validate parent exists and belongs to same company
    if (insertPeriod.parentId) {
      const parent = this.dataPeriods.get(insertPeriod.parentId);
      if (!parent) {
        throw new Error(`Parent period ${insertPeriod.parentId} not found`);
      }
      if (parent.companyId !== insertPeriod.companyId) {
        throw new Error(`Parent period belongs to different company`);
      }
    }
    
    const id = randomUUID();
    const period: DataPeriod = {
      ...insertPeriod,
      id,
      isExpanded: false,
      hasData: false,
      createdAt: new Date()
    };
    this.dataPeriods.set(id, period);
    return period;
  }

  async updateDataPeriod(id: string, updateData: Partial<InsertDataPeriod & {isExpanded?: boolean, hasData?: boolean}>): Promise<DataPeriod | undefined> {
    const existing = this.dataPeriods.get(id);
    if (!existing) {
      return undefined;
    }
    
    const updated: DataPeriod = {
      ...existing,
      ...updateData
    };
    
    this.dataPeriods.set(id, updated);
    return updated;
  }

  private async updatePeriodDataFlags(periodId: string) {
    const startPeriod = this.dataPeriods.get(periodId);
    if (!startPeriod) return;
    
    // Build efficient hierarchy map for the company
    const companyPeriods = Array.from(this.dataPeriods.values())
      .filter(p => p.companyId === startPeriod.companyId);
    
    const childrenMap = new Map<string, string[]>();
    companyPeriods.forEach(period => {
      const parentId = period.parentId || 'root';
      if (!childrenMap.has(parentId)) {
        childrenMap.set(parentId, []);
      }
      childrenMap.get(parentId)!.push(period.id);
    });
    
    // Get all descendant periods efficiently
    const getAllDescendants = (pid: string): string[] => {
      const children = childrenMap.get(pid) || [];
      const result = [...children];
      for (const childId of children) {
        result.push(...getAllDescendants(childId));
      }
      return result;
    };
    
    // Update hasData flag for this period and all ancestors
    let currentPeriodId: string | null = periodId;
    
    while (currentPeriodId) {
      const period = this.dataPeriods.get(currentPeriodId);
      if (!period) break;
      
      // Check if this period or any descendant has instrument data (scoped to company)
      const relevantPeriods = [currentPeriodId, ...getAllDescendants(currentPeriodId)];
      const hasData = Array.from(this.instrumentData.values()).some(
        data => data.companyId === startPeriod.companyId && relevantPeriods.includes(data.periodId)
      );
      
      // Update the period if hasData changed
      if (period.hasData !== hasData) {
        period.hasData = hasData;
        this.dataPeriods.set(currentPeriodId, period);
      }
      
      currentPeriodId = period.parentId;
    }
  }

  async deleteDataPeriod(id: string): Promise<boolean> {
    return this.dataPeriods.delete(id);
  }

  async getPeriodHierarchy(companyId: string, year: number): Promise<HierarchicalDataPeriod[]> {
    const periods = Array.from(this.dataPeriods.values())
      .filter(period => period.companyId === companyId && period.year === year);
    
    // Build hierarchical structure with nested children
    const buildHierarchy = (parentId: string | null | undefined = null): HierarchicalDataPeriod[] => {
      const children = periods
        .filter(p => {
          // Handle both null and undefined as root level
          if (parentId === null || parentId === undefined) {
            return p.parentId === null || p.parentId === undefined;
          }
          return p.parentId === parentId;
        })
        .sort((a, b) => {
          // Sort by period type hierarchy (year > quarter > month > day)
          const typeOrder = { year: 0, quarter: 1, month: 2, day: 3 };
          if (a.periodType !== b.periodType) {
            return typeOrder[a.periodType as keyof typeof typeOrder] - typeOrder[b.periodType as keyof typeof typeOrder];
          }
          return new Date(a.periodDate).getTime() - new Date(b.periodDate).getTime();
        });
      
      return children.map(period => ({
        ...period,
        children: buildHierarchy(period.id)
      }));
    };
    
    return buildHierarchy();
  }

  async togglePeriodExpansion(periodId: string): Promise<DataPeriod | undefined> {
    const period = this.dataPeriods.get(periodId);
    if (!period) {
      return undefined;
    }
    
    // Toggle isExpanded state
    const updated: DataPeriod = {
      ...period,
      isExpanded: !period.isExpanded
    };
    
    this.dataPeriods.set(periodId, updated);
    return updated;
  }

  // Instrument Data management
  async getInstrumentData(companyId: string, instrumentId?: string, periodId?: string): Promise<InstrumentData[]> {
    let results = Array.from(this.instrumentData.values()).filter(
      data => data.companyId === companyId
    );
    
    if (instrumentId) {
      results = results.filter(data => data.instrumentId === instrumentId);
    }
    
    if (periodId) {
      results = results.filter(data => data.periodId === periodId);
    }
    
    return results.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getInstrumentDataItem(id: string): Promise<InstrumentData | undefined> {
    return this.instrumentData.get(id);
  }

  async createInstrumentData(insertData: InsertInstrumentData): Promise<InstrumentData> {
    const id = randomUUID();
    const data: InstrumentData = {
      ...insertData,
      id,
      isCalculated: false,
      lastCalculatedAt: null,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.instrumentData.set(id, data);
    
    // Update hasData flags for the period and its ancestors
    await this.updatePeriodDataFlags(insertData.periodId);
    
    return data;
  }

  async updateInstrumentData(id: string, updateData: Partial<InsertInstrumentData>): Promise<InstrumentData | undefined> {
    const existing = this.instrumentData.get(id);
    if (!existing) {
      return undefined;
    }
    
    const updated: InstrumentData = {
      ...existing,
      ...updateData,
      updatedAt: new Date()
    };
    
    this.instrumentData.set(id, updated);
    return updated;
  }

  async deleteInstrumentData(id: string): Promise<boolean> {
    const existing = this.instrumentData.get(id);
    if (!existing) {
      return false;
    }
    
    const deleted = this.instrumentData.delete(id);
    
    if (deleted) {
      // Update hasData flags for the period and its ancestors
      await this.updatePeriodDataFlags(existing.periodId);
    }
    
    return deleted;
  }

  async getInstrumentDataByPeriod(companyId: string, instrumentId: string, periodId: string): Promise<InstrumentData[]> {
    return Array.from(this.instrumentData.values()).filter(
      data => data.companyId === companyId && data.instrumentId === instrumentId && data.periodId === periodId
    );
  }

  async getFinancialTransactions(companyId: string, periodId?: string, transactionType?: TransactionType): Promise<InstrumentData[]> {
    let results = Array.from(this.instrumentData.values()).filter(
      data => data.companyId === companyId && data.amount !== null && data.amount !== undefined
    );
    
    if (periodId) {
      results = results.filter(data => data.periodId === periodId);
    }
    
    if (transactionType) {
      results = results.filter(data => data.transactionType === transactionType);
    }
    
    return results.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }
}

export const storage = new MemStorage();
