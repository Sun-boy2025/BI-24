import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertInstrumentDataSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Financial Data Management API Routes
  
  // Create new financial data entry
  app.post('/api/financial-data', async (req, res) => {
    try {
      console.log('Received financial data:', JSON.stringify(req.body, null, 2));
      
      // Convert financial data to proper structure for storage
      const financialData = req.body;
      const insertData = {
        companyId: financialData.companyId,
        instrumentId: financialData.instrumentId,
        periodId: financialData.periodId,
        manualInputData: {
          // Financial data fields
          revenue: financialData.revenue,
          costs: financialData.costs,
          grossProfit: financialData.grossProfit,
          operatingExpenses: financialData.operatingExpenses,
          operatingProfit: financialData.operatingProfit,
          netProfit: financialData.netProfit,
          totalAssets: financialData.totalAssets,
          currentAssets: financialData.currentAssets,
          fixedAssets: financialData.fixedAssets,
          currentLiabilities: financialData.currentLiabilities,
          longTermLiabilities: financialData.longTermLiabilities,
          equity: financialData.equity,
          operatingCashFlow: financialData.operatingCashFlow,
          investingCashFlow: financialData.investingCashFlow,
          financingCashFlow: financialData.financingCashFlow,
          inventory: financialData.inventory,
          receivables: financialData.receivables,
          payables: financialData.payables
        },
        editableCalculationData: {},
        autoCalculatedData: {},
        description: `Financial data for ${financialData.periodType} period`,
        notes: financialData.notes,
        createdBy: financialData.createdBy || 'user'
      };

      console.log('Prepared data for storage:', JSON.stringify(insertData, null, 2));
      
      // Create instrument data entry
      const instrumentData = await storage.createInstrumentData(insertData);
      
      console.log('Instrument data created successfully:', instrumentData.id);
      res.json({ success: true, data: instrumentData });
    } catch (error: any) {
      console.error('Error creating financial data:', error);
      console.error('Error details:', error.stack);
      res.status(400).json({ 
        success: false, 
        error: error.message || 'Invalid financial data' 
      });
    }
  });
  
  // Get financial data with optional filters
  app.get('/api/financial-data', async (req, res) => {
    try {
      const { companyId, periodType } = req.query as { companyId?: string; periodType?: string };
      
      const instrumentData = await storage.getInstrumentData(companyId || 'demo-company');
      
      res.json({ success: true, data: instrumentData });
    } catch (error: any) {
      console.error('Error fetching financial data:', error);
      res.status(500).json({ 
        success: false, 
        error: 'Failed to fetch financial data' 
      });
    }
  });
  
  // Update financial data entry
  app.put('/api/financial-data/:id', async (req, res) => {
    try {
      const { id } = req.params;
      
      // Validate update data (allow partial updates)
      const updateData = insertInstrumentDataSchema.partial().parse(req.body);
      
      const updated = await storage.updateInstrumentData(id, updateData);
      
      if (!updated) {
        return res.status(404).json({ 
          success: false, 
          error: 'Financial data entry not found' 
        });
      }
      
      res.json({ success: true, data: updated });
    } catch (error: any) {
      console.error('Error updating financial data:', error);
      res.status(400).json({ 
        success: false, 
        error: error.message || 'Invalid update data' 
      });
    }
  });
  
  // Delete financial data entry
  app.delete('/api/financial-data/:id', async (req, res) => {
    try {
      const { id } = req.params;
      
      const deleted = await storage.deleteInstrumentData(id);
      
      if (!deleted) {
        return res.status(404).json({ 
          success: false, 
          error: 'Financial data entry not found' 
        });
      }
      
      res.json({ success: true, message: 'Financial data deleted successfully' });
    } catch (error: any) {
      console.error('Error deleting financial data:', error);
      res.status(500).json({ 
        success: false, 
        error: 'Failed to delete financial data' 
      });
    }
  });
  
  // Generate test financial data
  app.post('/api/financial-data/generate-test', async (req, res) => {
    try {
      const { 
        periodType = 'month', 
        periodDate = new Date().toISOString().split('T')[0],
        businessType = 'retail',
        companyId = 'demo-company',
        instrumentId = 'test_instrument',
        periodId = 'test_period'
      } = req.body;
      
      // Generate realistic test data based on business type
      const baseRevenue = businessType === 'manufacturing' ? 15000000 : 
                         businessType === 'services' ? 8000000 :
                         businessType === 'consulting' ? 5000000 :
                         businessType === 'ecommerce' ? 12000000 : 10000000;
      
      const testData = {
        companyId,
        instrumentId,
        periodId,
        periodType,
        periodDate: new Date(periodDate),
        year: new Date(periodDate).getFullYear(),
        quarter: Math.floor((new Date(periodDate).getMonth() + 3) / 3),
        month: periodType === 'month' ? new Date(periodDate).getMonth() + 1 : null,
        day: periodType === 'day' ? new Date(periodDate).getDate() : null,
        
        // P&L data with realistic ratios - convert to strings for Drizzle decimal fields
        revenue: Math.round(baseRevenue * (0.8 + Math.random() * 0.4)).toString(), // +/- 20%
        costs: Math.round(baseRevenue * (0.35 + Math.random() * 0.15)).toString(), // 35-50% of revenue
        grossProfit: "0", // Will be calculated
        operatingExpenses: Math.round(baseRevenue * (0.15 + Math.random() * 0.1)).toString(), // 15-25%
        operatingProfit: "0", // Will be calculated
        netProfit: "0", // Will be calculated
        
        // Balance sheet ratios - convert to strings for Drizzle decimal fields
        totalAssets: Math.round(baseRevenue * (1.5 + Math.random() * 1)).toString(), // 1.5-2.5x revenue
        currentAssets: "0", // Will be calculated
        fixedAssets: "0", // Will be calculated  
        currentLiabilities: Math.round(baseRevenue * (0.2 + Math.random() * 0.15)).toString(), // 20-35%
        longTermLiabilities: Math.round(baseRevenue * (0.15 + Math.random() * 0.2)).toString(), // 15-35%
        equity: "0", // Will be calculated
        
        // Cash flows - convert to strings for Drizzle decimal fields
        operatingCashFlow: Math.round(baseRevenue * (0.12 + Math.random() * 0.08)).toString(), // 12-20%
        investingCashFlow: Math.round(baseRevenue * (-0.05 + Math.random() * 0.1)).toString(), // -5% to +5%
        financingCashFlow: Math.round(baseRevenue * (-0.03 + Math.random() * 0.06)).toString(), // -3% to +3%
        
        // Working capital components - convert to strings for Drizzle decimal fields
        inventory: Math.round(baseRevenue * (0.08 + Math.random() * 0.12)).toString(), // 8-20%
        receivables: Math.round(baseRevenue * (0.06 + Math.random() * 0.08)).toString(), // 6-14%
        payables: Math.round(baseRevenue * (0.04 + Math.random() * 0.06)).toString(), // 4-10%
        
        notes: `Тестовые данные сгенерированы автоматически для ${periodType === 'day' ? 'дня' : periodType === 'month' ? 'месяца' : periodType === 'quarter' ? 'квартала' : 'года'} (${businessType})`,
        createdBy: 'system'
      };
      
      // Calculate dependent values - all calculations as strings for Drizzle decimal fields
      const revenueNum = parseInt(testData.revenue);
      const costsNum = parseInt(testData.costs);
      const grossProfitNum = revenueNum - costsNum;
      const operatingExpensesNum = parseInt(testData.operatingExpenses);
      const operatingProfitNum = grossProfitNum - operatingExpensesNum;
      
      testData.grossProfit = grossProfitNum.toString();
      testData.operatingProfit = operatingProfitNum.toString();
      testData.netProfit = Math.round(operatingProfitNum * (0.8 + Math.random() * 0.1)).toString(); // After taxes/other
      
      const totalAssetsNum = parseInt(testData.totalAssets);
      const currentAssetsNum = Math.round(totalAssetsNum * (0.4 + Math.random() * 0.2)); // 40-60%
      const currentLiabilitiesNum = parseInt(testData.currentLiabilities);
      const longTermLiabilitiesNum = parseInt(testData.longTermLiabilities);
      
      testData.currentAssets = currentAssetsNum.toString();
      testData.fixedAssets = (totalAssetsNum - currentAssetsNum).toString();
      testData.equity = (totalAssetsNum - currentLiabilitiesNum - longTermLiabilitiesNum).toString();
      
      // Return the generated data in the format expected by the client
      console.log('Generated test financial data for period:', periodType);
      res.json({ 
        success: true, 
        data: {
          periodType,
          periodDate,
          revenue: parseInt(testData.revenue),
          costs: parseInt(testData.costs), 
          grossProfit: parseInt(testData.grossProfit),
          operatingExpenses: parseInt(testData.operatingExpenses),
          operatingProfit: parseInt(testData.operatingProfit),
          netProfit: parseInt(testData.netProfit),
          totalAssets: parseInt(testData.totalAssets),
          currentAssets: parseInt(testData.currentAssets),
          fixedAssets: parseInt(testData.fixedAssets),
          currentLiabilities: parseInt(testData.currentLiabilities),
          longTermLiabilities: parseInt(testData.longTermLiabilities),
          equity: parseInt(testData.equity),
          operatingCashFlow: parseInt(testData.operatingCashFlow),
          investingCashFlow: parseInt(testData.investingCashFlow),
          financingCashFlow: parseInt(testData.financingCashFlow),
          inventory: parseInt(testData.inventory),
          receivables: parseInt(testData.receivables),
          payables: parseInt(testData.payables),
          notes: testData.notes
        }
      });
      
    } catch (error: any) {
      console.error('Error generating test data:', error);
      res.status(500).json({ 
        success: false, 
        error: error.message || 'Failed to generate test data' 
      });
    }
  });

  // Get instrument data for specific company and instrument
  app.get('/api/instrument-data/:companyId/:instrumentKey', async (req, res) => {
    try {
      const { companyId, instrumentKey } = req.params;
      
      // Get real saved financial data from storage for this company
      const savedData = await storage.getInstrumentData(companyId);
      
      // Create aggregated financial data from all saved periods
      let aggregatedData = {
        // Core financial metrics  
        annual_revenue: "",
        net_profit: "",
        current_assets: "",
        current_liabilities: "",
        total_assets: "",
        total_equity: "",
        debt_amount: "",
        cash_reserves: "",
        // Additional business metrics
        gross_profit: "",
        operating_profit: "",
        operating_cash_flow: "",
        fixed_assets: "",
        long_term_liabilities: "",
        investing_cash_flow: "",
        financing_cash_flow: "",
        inventory: "",
        receivables: "",
        payables: ""
      };
      
      // If we have saved data, use the most recent values
      if (savedData.length > 0) {
        const latestData = savedData[0]; // Most recent data
        const manualData = latestData.manualInputData as any || {};
        
        // Map the financial data to instrument fields
        aggregatedData = {
          annual_revenue: manualData.revenue || "",
          net_profit: manualData.netProfit || "",
          current_assets: manualData.currentAssets || "",
          current_liabilities: manualData.currentLiabilities || "",
          total_assets: manualData.totalAssets || "",
          total_equity: manualData.equity || "",
          debt_amount: manualData.longTermLiabilities || "",
          cash_reserves: manualData.operatingCashFlow || "",
          gross_profit: manualData.grossProfit || "",
          operating_profit: manualData.operatingProfit || "",
          operating_cash_flow: manualData.operatingCashFlow || "",
          fixed_assets: manualData.fixedAssets || "",
          long_term_liabilities: manualData.longTermLiabilities || "",
          investing_cash_flow: manualData.investingCashFlow || "",
          financing_cash_flow: manualData.financingCashFlow || "",
          inventory: manualData.inventory || "",
          receivables: manualData.receivables || "",
          payables: manualData.payables || ""
        };
      }
      
      const instrumentData = {
        companyId,
        instrumentKey,
        inputData: aggregatedData,
        settingsData: {
          risk_tolerance_level: "",
          benchmark_industry: "",
          health_score_weights: "",
          critical_ratios_thresholds: "",
          analysis_period: ""
        },
        timestamp: new Date().toISOString()
      };
      
      res.json({ success: true, data: instrumentData });
    } catch (error: any) {
      console.error('Error fetching instrument data:', error);
      res.status(500).json({ 
        success: false, 
        error: 'Failed to fetch instrument data' 
      });
    }
  });

  // Get periods hierarchy for company and year
  app.get('/api/periods/hierarchy/:companyId/:year', async (req, res) => {
    try {
      const { companyId, year } = req.params;
      
      // Return mock periods hierarchy data as flat array for HierarchicalTable
      const mockPeriodsData = [
        {
          id: `${companyId}-${year}-q1`,
          name: 'I квартал',
          period: 'quarter',
          children: [
            { id: `${companyId}-${year}-01`, name: 'Январь', period: 'month' },
            { id: `${companyId}-${year}-02`, name: 'Февраль', period: 'month' },
            { id: `${companyId}-${year}-03`, name: 'Март', period: 'month' }
          ]
        },
        {
          id: `${companyId}-${year}-q2`,
          name: 'II квартал',
          period: 'quarter',
          children: [
            { id: `${companyId}-${year}-04`, name: 'Апрель', period: 'month' },
            { id: `${companyId}-${year}-05`, name: 'Май', period: 'month' },
            { id: `${companyId}-${year}-06`, name: 'Июнь', period: 'month' }
          ]
        },
        {
          id: `${companyId}-${year}-q3`,
          name: 'III квартал',
          period: 'quarter',
          children: [
            { id: `${companyId}-${year}-07`, name: 'Июль', period: 'month' },
            { id: `${companyId}-${year}-08`, name: 'Август', period: 'month' },
            { id: `${companyId}-${year}-09`, name: 'Сентябрь', period: 'month' }
          ]
        },
        {
          id: `${companyId}-${year}-q4`,
          name: 'IV квартал',
          period: 'quarter',
          children: [
            { id: `${companyId}-${year}-10`, name: 'Октябрь', period: 'month' },
            { id: `${companyId}-${year}-11`, name: 'Ноябрь', period: 'month' },
            { id: `${companyId}-${year}-12`, name: 'Декабрь', period: 'month' }
          ]
        }
      ];
      
      res.json({ success: true, data: mockPeriodsData });
    } catch (error: any) {
      console.error('Error fetching periods hierarchy:', error);
      res.status(500).json({ 
        success: false, 
        error: 'Failed to fetch periods hierarchy' 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
