// Унифицированные финансовые данные для всех компонентов системы
// Используется в обзоре, движениях, графиках и аналитических инструментах

export interface UnifiedFinancialData {
  id: string;
  period: string;
  periodType: 'year' | 'quarter' | 'month' | 'day';
  revenue: number;
  expenses: number;
  costs: number; // Себестоимость
  grossProfit: number;
  operatingExpenses: number;
  operatingProfit: number;
  netProfit: number;
  netFlow: number; // Чистый денежный поток
  totalAssets: number;
  currentAssets: number;
  currentLiabilities: number;
  equity: number;
  operatingCashFlow: number;
  children?: UnifiedFinancialData[];
  expanded?: boolean;
}

// Генерация реалистичных ежедневных данных
function generateDailyData(year: number, month: number, baseMonthlyRevenue: number): UnifiedFinancialData[] {
  const daysInMonth = new Date(year, month, 0).getDate();
  const dailyData: UnifiedFinancialData[] = [];
  
  const monthNames = [
    'января', 'февраля', 'марта', 'апреля', 'мая', 'июня',
    'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'
  ];
  
  for (let day = 1; day <= daysInMonth; day++) {
    const dailyRevenue = Math.round(baseMonthlyRevenue / daysInMonth * (0.8 + Math.random() * 0.4));
    const costs = Math.round(dailyRevenue * (0.35 + Math.random() * 0.15)); // 35-50%
    const operatingExpenses = Math.round(dailyRevenue * (0.15 + Math.random() * 0.1)); // 15-25%
    const grossProfit = dailyRevenue - costs;
    const operatingProfit = grossProfit - operatingExpenses;
    const netProfit = Math.round(operatingProfit * (0.8 + Math.random() * 0.2)); // Учет налогов
    const expenses = costs + operatingExpenses;
    const netFlow = dailyRevenue - expenses;
    
    dailyData.push({
      id: `${year}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`,
      period: `${day} ${monthNames[month - 1]} ${year}`,
      periodType: 'day',
      revenue: dailyRevenue,
      expenses,
      costs,
      grossProfit,
      operatingExpenses,
      operatingProfit,
      netProfit,
      netFlow,
      totalAssets: Math.round(dailyRevenue * (1.5 + Math.random() * 1)),
      currentAssets: Math.round(dailyRevenue * (0.6 + Math.random() * 0.4)),
      currentLiabilities: Math.round(dailyRevenue * (0.2 + Math.random() * 0.15)),
      equity: Math.round(dailyRevenue * (0.8 + Math.random() * 0.4)),
      operatingCashFlow: Math.round(netProfit * (1.1 + Math.random() * 0.2))
    });
  }
  
  return dailyData;
}

// Генерация данных по месяцам с полными ежедневными данными
function generateMonthlyData(year: number, quarter: number): UnifiedFinancialData[] {
  const startMonth = (quarter - 1) * 3 + 1;
  const monthNames = [
    'Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь',
    'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'
  ];
  
  const baseRevenues = {
    1: 8500000, 2: 8200000, 3: 8300000,   // Q1
    4: 9200000, 5: 9500000, 6: 9300000,   // Q2  
    7: 10500000, 8: 11000000, 9: 10500000, // Q3
    10: 11200000, 11: 10900000, 12: 12100000 // Q4
  };
  
  const months: UnifiedFinancialData[] = [];
  
  for (let monthOffset = 0; monthOffset < 3; monthOffset++) {
    const month = startMonth + monthOffset;
    const baseMonthlyRevenue = baseRevenues[month as keyof typeof baseRevenues];
    const dailyData = generateDailyData(year, month, baseMonthlyRevenue);
    
    // Суммируем ежедневные данные для получения месячных
    const monthlyRevenue = dailyData.reduce((sum, day) => sum + day.revenue, 0);
    const monthlyExpenses = dailyData.reduce((sum, day) => sum + day.expenses, 0);
    const monthlyCosts = dailyData.reduce((sum, day) => sum + day.costs, 0);
    const monthlyGrossProfit = dailyData.reduce((sum, day) => sum + day.grossProfit, 0);
    const monthlyOperatingExpenses = dailyData.reduce((sum, day) => sum + day.operatingExpenses, 0);
    const monthlyOperatingProfit = dailyData.reduce((sum, day) => sum + day.operatingProfit, 0);
    const monthlyNetProfit = dailyData.reduce((sum, day) => sum + day.netProfit, 0);
    const monthlyNetFlow = dailyData.reduce((sum, day) => sum + day.netFlow, 0);
    
    months.push({
      id: `${year}-${month.toString().padStart(2, '0')}`,
      period: `${monthNames[month - 1]} ${year}`,
      periodType: 'month',
      revenue: monthlyRevenue,
      expenses: monthlyExpenses,
      costs: monthlyCosts,
      grossProfit: monthlyGrossProfit,
      operatingExpenses: monthlyOperatingExpenses,
      operatingProfit: monthlyOperatingProfit,
      netProfit: monthlyNetProfit,
      netFlow: monthlyNetFlow,
      totalAssets: Math.round(monthlyRevenue * 1.8),
      currentAssets: Math.round(monthlyRevenue * 0.7),
      currentLiabilities: Math.round(monthlyRevenue * 0.25),
      equity: Math.round(monthlyRevenue * 0.9),
      operatingCashFlow: Math.round(monthlyNetProfit * 1.15),
      expanded: true, // Показывать ежедневные данные по умолчанию
      children: dailyData
    });
  }
  
  return months;
}

// Основные данные для 2025 года с полными ежедневными данными
export const unifiedFinancialData: UnifiedFinancialData[] = [
  {
    id: '2025',
    period: '2025 год',
    periodType: 'year',
    revenue: 126000000, // Сумма всех кварталов
    expenses: 89000000,
    costs: 54000000,
    grossProfit: 72000000,
    operatingExpenses: 35000000,
    operatingProfit: 37000000,
    netProfit: 29600000, // ~23.5% от выручки
    netFlow: 37000000,
    totalAssets: 226800000,
    currentAssets: 88200000,
    currentLiabilities: 31500000,
    equity: 113400000,
    operatingCashFlow: 34040000,
    expanded: true,
    children: [
      // Q1 2025
      {
        id: '2025-q1',
        period: 'I квартал 2025',
        periodType: 'quarter',
        revenue: 25000000,
        expenses: 17600000,
        costs: 10750000,
        grossProfit: 14250000,
        operatingExpenses: 6850000,
        operatingProfit: 7400000,
        netProfit: 5920000,
        netFlow: 7400000,
        totalAssets: 45000000,
        currentAssets: 17500000,
        currentLiabilities: 6250000,
        equity: 22500000,
        operatingCashFlow: 6808000,
        expanded: true,
        children: generateMonthlyData(2025, 1)
      },
      // Q2 2025  
      {
        id: '2025-q2',
        period: 'II квартал 2025',
        periodType: 'quarter',
        revenue: 28000000,
        expenses: 19700000,
        costs: 12040000,
        grossProfit: 15960000,
        operatingExpenses: 7660000,
        operatingProfit: 8300000,
        netProfit: 6640000,
        netFlow: 8300000,
        totalAssets: 50400000,
        currentAssets: 19600000,
        currentLiabilities: 7000000,
        equity: 25200000,
        operatingCashFlow: 7636000,
        expanded: true,
        children: generateMonthlyData(2025, 2)
      },
      // Q3 2025
      {
        id: '2025-q3',
        period: 'III квартал 2025',
        periodType: 'quarter',
        revenue: 32000000,
        expenses: 22500000,
        costs: 13760000,
        grossProfit: 18240000,
        operatingExpenses: 8740000,
        operatingProfit: 9500000,
        netProfit: 7600000,
        netFlow: 9500000,
        totalAssets: 57600000,
        currentAssets: 22400000,
        currentLiabilities: 8000000,
        equity: 28800000,
        operatingCashFlow: 8740000,
        expanded: true,
        children: generateMonthlyData(2025, 3)
      },
      // Q4 2025
      {
        id: '2025-q4',
        period: 'IV квартал 2025',
        periodType: 'quarter',
        revenue: 41000000,
        expenses: 29200000,
        costs: 17630000,
        grossProfit: 23370000,
        operatingExpenses: 11570000,
        operatingProfit: 11800000,
        netProfit: 9440000,
        netFlow: 11800000,
        totalAssets: 73800000,
        currentAssets: 28700000,
        currentLiabilities: 10250000,
        equity: 36900000,
        operatingCashFlow: 10856000,
        expanded: true,
        children: generateMonthlyData(2025, 4)
      }
    ]
  }
];

// Вспомогательные функции для компонентов
export function getDataForPeriod(periodId: string, data: UnifiedFinancialData[] = unifiedFinancialData): UnifiedFinancialData | null {
  for (const item of data) {
    if (item.id === periodId) return item;
    if (item.children) {
      const found = getDataForPeriod(periodId, item.children);
      if (found) return found;
    }
  }
  return null;
}

export function getAggregatedData(periodType: 'month' | 'quarter' | 'year' = 'month'): UnifiedFinancialData[] {
  const flattened: UnifiedFinancialData[] = [];
  
  function flatten(items: UnifiedFinancialData[]) {
    for (const item of items) {
      if (item.periodType === periodType) {
        flattened.push(item);
      }
      if (item.children) {
        flatten(item.children);
      }
    }
  }
  
  flatten(unifiedFinancialData);
  return flattened;
}

// Данные для Dashboard Cards (обзор)
export function getDashboardCards(): any[] {
  const yearData = unifiedFinancialData[0]; // 2025 данные
  const q4Data = yearData.children?.find(q => q.id === '2025-q4');
  
  return [
    {
      title: "Общая выручка",
      value: `${(yearData.revenue / 1000000).toFixed(1)} млн ₽`,
      description: `За ${yearData.period}`,
      trend: "up" as const,
      trendValue: "+18.5%",
      badge: "Рост",
      badgeVariant: "default" as const,
      icon: "DollarSign"
    },
    {
      title: "Чистая прибыль", 
      value: `${(yearData.netProfit / 1000000).toFixed(1)} млн ₽`,
      description: `Маржинальность ${((yearData.netProfit / yearData.revenue) * 100).toFixed(1)}%`,
      trend: "up" as const,
      trendValue: "+12.3%",
      badge: "Рост",
      badgeVariant: "default" as const,
      icon: "TrendingUp"
    },
    {
      title: "Коэффициент ликвидности",
      value: (yearData.currentAssets / yearData.currentLiabilities).toFixed(2),
      description: "Отличный уровень ликвидности",
      trend: "neutral" as const,
      trendValue: "0%",
      badge: "Стабильно",
      badgeVariant: "secondary" as const,
      icon: "Activity"
    },
    {
      title: "ROI (рентабельность)",
      value: `${((yearData.netProfit / yearData.totalAssets) * 100).toFixed(1)}%`,
      description: "Выше среднего по отрасли",
      trend: "up" as const,
      trendValue: "+3.2%",
      badge: "Отлично",
      badgeVariant: "default" as const,
      icon: "Target"
    }
  ];
}

// Данные для графиков
export function getRevenueChartData(): any[] {
  return getAggregatedData('month').slice(0, 12).map(month => ({
    name: month.period.split(' ')[0].substring(0, 3),
    value: month.revenue
  }));
}

export function getProfitChartData(): any[] {
  const quarters = getAggregatedData('quarter');
  return quarters.map((quarter, index) => ({
    name: `Q${index + 1} 2025`,
    value: quarter.netProfit
  }));
}

export function getExpenseStructureData(): any[] {
  const yearData = unifiedFinancialData[0];
  const totalExpenses = yearData.expenses;
  
  return [
    { name: 'Себестоимость', value: Math.round((yearData.costs / totalExpenses) * 100) },
    { name: 'Операционные расходы', value: Math.round((yearData.operatingExpenses / totalExpenses) * 100) },
    { name: 'Зарплата', value: 25 },
    { name: 'Аренда', value: 12 }, 
    { name: 'Прочие', value: 8 }
  ];
}

// Конвертация для HierarchicalMovementsTable
export function convertToMovementData(data: UnifiedFinancialData[] = unifiedFinancialData): any[] {
  return data.map(item => ({
    id: item.id,
    period: item.period,
    periodType: item.periodType,
    revenue: item.revenue,
    expenses: item.expenses,
    netFlow: item.netFlow,
    children: item.children ? convertToMovementData(item.children) : undefined,
    expanded: item.expanded
  }));
}