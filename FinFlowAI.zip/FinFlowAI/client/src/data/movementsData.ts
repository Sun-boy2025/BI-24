export interface MovementData {
  id: string;
  period: string;
  periodType: 'year' | 'quarter' | 'month' | 'day';
  revenue: number;
  expenses: number;
  netFlow: number;
  children?: MovementData[];
  expanded?: boolean;
}

export const mockMovementsData: MovementData[] = [
  {
    id: '2024',
    period: '2024 год',
    periodType: 'year',
    revenue: 120000000,
    expenses: 85000000,
    netFlow: 35000000,
    expanded: true,
    children: [
      {
        id: '2024-q1',
        period: 'I квартал 2024',
        periodType: 'quarter',
        revenue: 25000000,
        expenses: 18000000,
        netFlow: 7000000,
        expanded: true,
        children: [
          {
            id: '2024-01',
            period: 'Январь 2024',
            periodType: 'month',
            revenue: 8500000,
            expenses: 6200000,
            netFlow: 2300000,
            children: [
              {
                id: '2024-01-01',
                period: '1 января 2024',
                periodType: 'day',
                revenue: 280000,
                expenses: 210000,
                netFlow: 70000
              },
              {
                id: '2024-01-02',
                period: '2 января 2024',
                periodType: 'day',
                revenue: 295000,
                expenses: 215000,
                netFlow: 80000
              }
            ]
          },
          {
            id: '2024-02',
            period: 'Февраль 2024',
            periodType: 'month',
            revenue: 8200000,
            expenses: 5900000,
            netFlow: 2300000
          },
          {
            id: '2024-03',
            period: 'Март 2024',
            periodType: 'month',
            revenue: 8300000,
            expenses: 5900000,
            netFlow: 2400000
          }
        ]
      },
      {
        id: '2024-q2',
        period: 'II квартал 2024',
        periodType: 'quarter',
        revenue: 28000000,
        expenses: 19500000,
        netFlow: 8500000,
        children: [
          {
            id: '2024-04',
            period: 'Апрель 2024',
            periodType: 'month',
            revenue: 9200000,
            expenses: 6400000,
            netFlow: 2800000
          },
          {
            id: '2024-05',
            period: 'Май 2024',
            periodType: 'month',
            revenue: 9500000,
            expenses: 6600000,
            netFlow: 2900000
          },
          {
            id: '2024-06',
            period: 'Июнь 2024',
            periodType: 'month',
            revenue: 9300000,
            expenses: 6500000,
            netFlow: 2800000
          }
        ]
      },
      {
        id: '2024-q3',
        period: 'III квартал 2024',
        periodType: 'quarter',
        revenue: 32000000,
        expenses: 22500000,
        netFlow: 9500000,
        children: [
          {
            id: '2024-07',
            period: 'Июль 2024',
            periodType: 'month',
            revenue: 10500000,
            expenses: 7200000,
            netFlow: 3300000
          },
          {
            id: '2024-08',
            period: 'Август 2024',
            periodType: 'month',
            revenue: 11000000,
            expenses: 7800000,
            netFlow: 3200000
          },
          {
            id: '2024-09',
            period: 'Сентябрь 2024',
            periodType: 'month',
            revenue: 10500000,
            expenses: 7500000,
            netFlow: 3000000
          }
        ]
      },
      {
        id: '2024-q4',
        period: 'IV квартал 2024',
        periodType: 'quarter',
        revenue: 35000000,
        expenses: 25000000,
        netFlow: 10000000,
        children: [
          {
            id: '2024-10',
            period: 'Октябрь 2024',
            periodType: 'month',
            revenue: 11800000,
            expenses: 8300000,
            netFlow: 3500000
          },
          {
            id: '2024-11',
            period: 'Ноябрь 2024',
            periodType: 'month',
            revenue: 11700000,
            expenses: 8200000,
            netFlow: 3500000
          },
          {
            id: '2024-12',
            period: 'Декабрь 2024',
            periodType: 'month',
            revenue: 11500000,
            expenses: 8500000,
            netFlow: 3000000
          }
        ]
      }
    ]
  },
  {
    id: '2023',
    period: '2023 год',
    periodType: 'year',
    revenue: 98000000,
    expenses: 72000000,
    netFlow: 26000000,
    children: [
      {
        id: '2023-q4',
        period: 'IV квартал 2023',
        periodType: 'quarter',
        revenue: 28000000,
        expenses: 20000000,
        netFlow: 8000000,
        children: [
          {
            id: '2023-12',
            period: 'Декабрь 2023',
            periodType: 'month',
            revenue: 10200000,
            expenses: 7300000,
            netFlow: 2900000
          }
        ]
      }
    ]
  }
];