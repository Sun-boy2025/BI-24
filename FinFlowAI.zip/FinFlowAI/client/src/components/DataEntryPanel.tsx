import { useState } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Plus, 
  Dice3,
  Save, 
  Edit3, 
  Calendar,
  BarChart3,
  TrendingUp,
  DollarSign,
  Target,
  FileSpreadsheet
} from "lucide-react";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";

interface FinancialDataEntry {
  periodType: 'day' | 'month' | 'quarter' | 'year';
  periodDate: string;
  revenue?: number;
  costs?: number;
  grossProfit?: number;
  operatingExpenses?: number;
  operatingProfit?: number;
  netProfit?: number;
  totalAssets?: number;
  currentAssets?: number;
  fixedAssets?: number;
  currentLiabilities?: number;
  longTermLiabilities?: number;
  equity?: number;
  operatingCashFlow?: number;
  investingCashFlow?: number;
  financingCashFlow?: number;
  inventory?: number;
  receivables?: number;
  payables?: number;
  notes?: string;
}

export default function DataEntryPanel() {
  const [activeTab, setActiveTab] = useState('manual');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [generateProgress, setGenerateProgress] = useState(0);
  
  const [formData, setFormData] = useState<FinancialDataEntry>({
    periodType: 'month',
    periodDate: new Date().toISOString().split('T')[0], // Ensure YYYY-MM-DD format
    notes: ''
  });

  const handleInputChange = (field: keyof FinancialDataEntry, value: string | number) => {
    setFormData(prev => ({
      ...prev,
      [field]: field === 'notes' || field === 'periodDate' || field === 'periodType' ? value : Number(value) || undefined
    }));
  };

  const { toast } = useToast();

  const handleGenerateTestData = async () => {
    setIsGenerating(true);
    setGenerateProgress(0);
    
    try {
      // Simulate progress animation
      const progressInterval = setInterval(() => {
        setGenerateProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + 18;
        });
      }, 200);
      
      // Make API call to generate test data  
      const res = await apiRequest('POST', '/api/financial-data/generate-test', {
        periodType: formData.periodType,
        periodDate: formData.periodDate,
        businessType: 'retail', // Default business type
        companyId: 'demo-company',
        instrumentId: 'financial_health', // Default instrument
        periodId: `demo-company-${new Date(formData.periodDate).getFullYear()}-${formData.periodType}` // Generate period ID
      });
      
      const response = await res.json();
      
      if (response.success) {
        const generatedData = response.data;
        
        // Update form with generated data - convert string values to numbers for form
        const testData: FinancialDataEntry = {
          periodType: generatedData.periodType,
          periodDate: generatedData.periodDate,
          revenue: parseInt(generatedData.revenue) || 0,
          costs: parseInt(generatedData.costs) || 0,
          grossProfit: parseInt(generatedData.grossProfit) || 0,
          operatingExpenses: parseInt(generatedData.operatingExpenses) || 0,
          operatingProfit: parseInt(generatedData.operatingProfit) || 0,
          netProfit: parseInt(generatedData.netProfit) || 0,
          totalAssets: parseInt(generatedData.totalAssets) || 0,
          currentAssets: parseInt(generatedData.currentAssets) || 0,
          fixedAssets: parseInt(generatedData.fixedAssets) || 0,
          currentLiabilities: parseInt(generatedData.currentLiabilities) || 0,
          longTermLiabilities: parseInt(generatedData.longTermLiabilities) || 0,
          equity: parseInt(generatedData.equity) || 0,
          operatingCashFlow: parseInt(generatedData.operatingCashFlow) || 0,
          investingCashFlow: parseInt(generatedData.investingCashFlow) || 0,
          financingCashFlow: parseInt(generatedData.financingCashFlow) || 0,
          inventory: parseInt(generatedData.inventory) || 0,
          receivables: parseInt(generatedData.receivables) || 0,
          payables: parseInt(generatedData.payables) || 0,
          notes: generatedData.notes
        };
        
        setFormData(testData);
        setGenerateProgress(100);
        
        toast({
          title: "Тестовые данные сгенерированы",
          description: "Реалистичные финансовые данные успешно сгенерированы"
        });
        
      } else {
        throw new Error(response.error || 'Ошибка генерации данных');
      }
      
    } catch (error: any) {
      console.error('Error generating test data:', error);
      setGenerateProgress(0);
      toast({
        title: "Ошибка генерации",
        description: error.message || 'Не удалось сгенерировать тестовые данные',
        variant: "destructive"
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSaveData = async () => {
    setIsSaving(true);
    
    try {
      // Prepare data for API call
      const periodDateObj = new Date(formData.periodDate);
      const saveData = {
        companyId: 'demo-company',
        instrumentId: 'financial_health', // Default instrument for financial data
        periodId: `demo-company-${periodDateObj.getFullYear()}-${String(periodDateObj.getMonth() + 1).padStart(2, '0')}-${String(periodDateObj.getDate()).padStart(2, '0')}-${formData.periodType}`, // Generate unique period ID
        periodType: formData.periodType,
        periodDate: periodDateObj,
        year: periodDateObj.getFullYear(),
        quarter: formData.periodType === 'quarter' ? Math.floor((periodDateObj.getMonth() + 3) / 3) : null,
        month: formData.periodType === 'month' ? periodDateObj.getMonth() + 1 : null,
        day: formData.periodType === 'day' ? periodDateObj.getDate() : null,
        
        // Financial data
        revenue: formData.revenue?.toString() || null,
        costs: formData.costs?.toString() || null,
        grossProfit: formData.grossProfit?.toString() || null,
        operatingExpenses: formData.operatingExpenses?.toString() || null,
        operatingProfit: formData.operatingProfit?.toString() || null,
        netProfit: formData.netProfit?.toString() || null,
        totalAssets: formData.totalAssets?.toString() || null,
        currentAssets: formData.currentAssets?.toString() || null,
        fixedAssets: formData.fixedAssets?.toString() || null,
        currentLiabilities: formData.currentLiabilities?.toString() || null,
        longTermLiabilities: formData.longTermLiabilities?.toString() || null,
        equity: formData.equity?.toString() || null,
        operatingCashFlow: formData.operatingCashFlow?.toString() || null,
        investingCashFlow: formData.investingCashFlow?.toString() || null,
        financingCashFlow: formData.financingCashFlow?.toString() || null,
        inventory: formData.inventory?.toString() || null,
        receivables: formData.receivables?.toString() || null,
        payables: formData.payables?.toString() || null,
        notes: formData.notes || null,
        createdBy: 'user'
      };
      
      const res = await apiRequest('POST', '/api/financial-data', saveData);
      const response = await res.json();
      
      if (response.success) {
        toast({
          title: "Данные сохранены",
          description: `Финансовые данные за ${getPeriodDisplayName(formData.periodType)} успешно сохранены`
        });
        
        // Reset form after successful save
        handleClearForm();
      } else {
        throw new Error(response.error || 'Ошибка сохранения');
      }
      
    } catch (error: any) {
      console.error('Error saving financial data:', error);
      toast({
        title: "Ошибка сохранения",
        description: error.message || 'Не удалось сохранить данные',
        variant: "destructive"
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleClearForm = () => {
    setFormData({
      periodType: formData.periodType,
      periodDate: formData.periodDate,
      notes: ''
    });
  };

  const getPeriodDisplayName = (periodType: string) => {
    switch (periodType) {
      case 'day': return 'день';
      case 'month': return 'месяц';  
      case 'quarter': return 'квартал';
      case 'year': return 'год';
      default: return periodType;
    }
  };

  const formatDate = (dateStr: string) => {
    if (!dateStr) return 'Не выбрана';
    const date = new Date(dateStr);
    if (isNaN(date.getTime())) return 'Неверная дата';
    return date.toLocaleDateString('ru-RU');
  };

  const formatCurrency = (value?: number) => {
    if (!value) return '';
    return value.toLocaleString('ru-RU');
  };

  const NumberInput = ({ 
    label, 
    field, 
    placeholder, 
    icon: Icon 
  }: { 
    label: string; 
    field: keyof FinancialDataEntry; 
    placeholder: string; 
    icon?: any;
  }) => (
    <div className="space-y-2">
      <Label htmlFor={field} className="text-xs md:text-sm flex items-center gap-2">
        {Icon && <Icon className="h-3 w-3 md:h-4 md:w-4" />}
        {label}
      </Label>
      <Input
        id={field}
        type="number"
        placeholder={placeholder}
        value={formData[field] as number || ''}
        onChange={(e) => handleInputChange(field, e.target.value)}
        className="text-xs md:text-sm min-h-11 md:min-h-10"
        data-testid={`input-${field}`}
      />
    </div>
  );

  return (
    <div className="space-y-4 md:space-y-6">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-2 w-full">
          <TabsTrigger value="manual" className="text-xs md:text-sm" data-testid="tab-manual-entry">
            <Edit3 className="h-3 w-3 md:h-4 md:w-4 mr-2" />
            Ручной ввод
          </TabsTrigger>
          <TabsTrigger value="generator" className="text-xs md:text-sm" data-testid="tab-test-data">
            <Dice3 className="h-3 w-3 md:h-4 md:w-4 mr-2" />
            Тестовые данные
          </TabsTrigger>
        </TabsList>

        <TabsContent value="manual" className="mt-4 md:mt-6">
          <Card data-testid="card-manual-entry">
            <CardHeader className="pb-3 md:pb-6">
              <div className="flex items-center gap-2">
                <Plus className="h-4 w-4 md:h-5 md:w-5 text-primary" />
                <CardTitle className="text-sm md:text-lg">
                  Ввод финансовых данных
                </CardTitle>
              </div>
              <CardDescription className="text-xs md:text-sm">
                Введите финансовые показатели компании вручную
              </CardDescription>
            </CardHeader>
            
            <CardContent className="space-y-4 md:space-y-6 px-3 md:px-6">
              {/* Period Selection */}
              <div className="grid gap-3 md:gap-4 grid-cols-1 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="period-type" className="text-xs md:text-sm flex items-center gap-2">
                    <Calendar className="h-3 w-3 md:h-4 md:w-4" />
                    Тип периода
                  </Label>
                  <Select 
                    value={formData.periodType} 
                    onValueChange={(value: 'day' | 'month' | 'quarter' | 'year') => 
                      handleInputChange('periodType', value)
                    }
                  >
                    <SelectTrigger 
                      data-testid="select-period-type" 
                      className="text-xs md:text-sm min-h-11 md:min-h-10"
                    >
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="day">День</SelectItem>
                      <SelectItem value="month">Месяц</SelectItem>
                      <SelectItem value="quarter">Квартал</SelectItem>
                      <SelectItem value="year">Год</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="period-date" className="text-xs md:text-sm">
                    Дата периода
                  </Label>
                  <Input
                    id="period-date"
                    type="date"
                    value={formData.periodDate}
                    onChange={(e) => handleInputChange('periodDate', e.target.value)}
                    className="text-xs md:text-sm min-h-11 md:min-h-10"
                    data-testid="input-period-date"
                  />
                </div>
              </div>

              {/* Financial Data Sections */}
              <Tabs defaultValue="pnl" className="w-full">
                <TabsList className="grid grid-cols-3 w-full">
                  <TabsTrigger value="pnl" className="text-xs md:text-sm">
                    <TrendingUp className="h-3 w-3 mr-1" />
                    <span className="hidden sm:inline">Прибыли и убытки</span>
                    <span className="sm:hidden">P&L</span>
                  </TabsTrigger>
                  <TabsTrigger value="balance" className="text-xs md:text-sm">
                    <BarChart3 className="h-3 w-3 mr-1" />
                    <span className="hidden sm:inline">Баланс</span>
                    <span className="sm:hidden">Баланс</span>
                  </TabsTrigger>
                  <TabsTrigger value="cashflow" className="text-xs md:text-sm">
                    <DollarSign className="h-3 w-3 mr-1" />
                    <span className="hidden sm:inline">Ден. потоки</span>
                    <span className="sm:hidden">CF</span>
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="pnl" className="mt-4 space-y-3 md:space-y-4">
                  <div className="grid gap-3 md:gap-4 grid-cols-1 md:grid-cols-2">
                    <NumberInput 
                      label="Выручка" 
                      field="revenue" 
                      placeholder="0"
                      icon={DollarSign}
                    />
                    <NumberInput 
                      label="Себестоимость" 
                      field="costs" 
                      placeholder="0" 
                    />
                    <NumberInput 
                      label="Валовая прибыль" 
                      field="grossProfit" 
                      placeholder="0" 
                    />
                    <NumberInput 
                      label="Операционные расходы" 
                      field="operatingExpenses" 
                      placeholder="0" 
                    />
                    <NumberInput 
                      label="Операционная прибыль" 
                      field="operatingProfit" 
                      placeholder="0" 
                    />
                    <NumberInput 
                      label="Чистая прибыль" 
                      field="netProfit" 
                      placeholder="0" 
                    />
                  </div>
                </TabsContent>

                <TabsContent value="balance" className="mt-4 space-y-3 md:space-y-4">
                  <div className="grid gap-3 md:gap-4 grid-cols-1 md:grid-cols-2">
                    <NumberInput 
                      label="Общие активы" 
                      field="totalAssets" 
                      placeholder="0" 
                    />
                    <NumberInput 
                      label="Оборотные активы" 
                      field="currentAssets" 
                      placeholder="0" 
                    />
                    <NumberInput 
                      label="Основные средства" 
                      field="fixedAssets" 
                      placeholder="0" 
                    />
                    <NumberInput 
                      label="Краткосрочные обязательства" 
                      field="currentLiabilities" 
                      placeholder="0" 
                    />
                    <NumberInput 
                      label="Долгосрочные обязательства" 
                      field="longTermLiabilities" 
                      placeholder="0" 
                    />
                    <NumberInput 
                      label="Собственный капитал" 
                      field="equity" 
                      placeholder="0" 
                    />
                  </div>
                </TabsContent>

                <TabsContent value="cashflow" className="mt-4 space-y-3 md:space-y-4">
                  <div className="grid gap-3 md:gap-4 grid-cols-1 md:grid-cols-2">
                    <NumberInput 
                      label="Операционный денежный поток" 
                      field="operatingCashFlow" 
                      placeholder="0" 
                    />
                    <NumberInput 
                      label="Инвестиционный денежный поток" 
                      field="investingCashFlow" 
                      placeholder="0" 
                    />
                    <NumberInput 
                      label="Финансовый денежный поток" 
                      field="financingCashFlow" 
                      placeholder="0" 
                    />
                    <NumberInput 
                      label="Запасы" 
                      field="inventory" 
                      placeholder="0" 
                    />
                    <NumberInput 
                      label="Дебиторская задолженность" 
                      field="receivables" 
                      placeholder="0" 
                    />
                    <NumberInput 
                      label="Кредиторская задолженность" 
                      field="payables" 
                      placeholder="0" 
                    />
                  </div>
                </TabsContent>
              </Tabs>

              {/* Notes */}
              <div className="space-y-2">
                <Label htmlFor="notes" className="text-xs md:text-sm">
                  Комментарии
                </Label>
                <Textarea
                  id="notes"
                  placeholder="Дополнительные комментарии к финансовым данным..."
                  value={formData.notes || ''}
                  onChange={(e) => handleInputChange('notes', e.target.value)}
                  className="text-xs md:text-sm min-h-20 resize-none"
                  data-testid="textarea-notes"
                />
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-2 pt-2">
                <Button 
                  onClick={handleSaveData}
                  disabled={isSaving}
                  className="flex-1 min-h-11 md:min-h-9 text-xs md:text-sm"
                  data-testid="button-save-data"
                >
                  {isSaving ? (
                    <>
                      <Target className="h-3 w-3 md:h-4 md:w-4 mr-2 animate-spin" />
                      Сохранение...
                    </>
                  ) : (
                    <>
                      <Save className="h-3 w-3 md:h-4 md:w-4 mr-2" />
                      Сохранить данные
                    </>
                  )}
                </Button>
                <Button 
                  variant="outline"
                  onClick={handleClearForm}
                  className="flex-1 sm:flex-initial min-h-11 md:min-h-9 text-xs md:text-sm"
                  data-testid="button-clear-form"
                >
                  Очистить
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="generator" className="mt-4 md:mt-6">
          <Card data-testid="card-test-generator">
            <CardHeader className="pb-3 md:pb-6">
              <div className="flex items-center gap-2">
                <Dice3 className="h-4 w-4 md:h-5 md:w-5 text-primary" />
                <CardTitle className="text-sm md:text-lg">
                  Генератор тестовых данных
                </CardTitle>
              </div>
              <CardDescription className="text-xs md:text-sm">
                Автоматическая генерация реалистичных финансовых данных для демонстрации
              </CardDescription>
            </CardHeader>

            <CardContent className="space-y-4 md:space-y-6 px-3 md:px-6">
              <div className="grid gap-3 md:gap-4 grid-cols-1 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label className="text-xs md:text-sm">Период для генерации</Label>
                  <div className="flex items-center gap-2 text-xs md:text-sm">
                    <Badge variant="outline" className="px-2 py-1">
                      {getPeriodDisplayName(formData.periodType)}
                    </Badge>
                    <span className="text-muted-foreground">
                      {formatDate(formData.periodDate)}
                    </span>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label className="text-xs md:text-sm">Тип бизнеса</Label>
                  <Select defaultValue="retail">
                    <SelectTrigger 
                      className="text-xs md:text-sm min-h-11 md:min-h-10"
                      data-testid="select-business-type"
                    >
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="retail">Розничная торговля</SelectItem>
                      <SelectItem value="manufacturing">Производство</SelectItem>
                      <SelectItem value="services">Услуги</SelectItem>
                      <SelectItem value="consulting">Консалтинг</SelectItem>
                      <SelectItem value="ecommerce">Электронная коммерция</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Button
                onClick={handleGenerateTestData}
                disabled={isGenerating}
                className="w-full min-h-11 md:min-h-9 text-xs md:text-sm"
                data-testid="button-generate-test-data"
              >
                {isGenerating ? (
                  <>
                    <Dice3 className="h-3 w-3 md:h-4 md:w-4 mr-2 animate-spin" />
                    Генерация данных...
                  </>
                ) : (
                  <>
                    <Dice3 className="h-3 w-3 md:h-4 md:w-4 mr-2" />
                    Сгенерировать тестовые данные
                  </>
                )}
              </Button>

              {isGenerating && (
                <div className="space-y-2">
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Генерация финансовых данных...</span>
                    <span>{generateProgress}%</span>
                  </div>
                  <Progress value={generateProgress} className="w-full" />
                </div>
              )}

              {/* Generated Data Preview */}
              {formData.revenue && !isGenerating && (
                <div className="space-y-3 md:space-y-4 pt-4 border-t">
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm md:text-base font-semibold">
                      Предварительный просмотр данных
                    </h4>
                    <Badge variant="secondary" className="text-xs">
                      Сгенерировано
                    </Badge>
                  </div>
                  
                  <div className="grid gap-2 md:gap-3 grid-cols-2 md:grid-cols-3">
                    <div className="space-y-1">
                      <p className="text-xs text-muted-foreground">Выручка</p>
                      <p className="text-sm md:text-base font-medium">
                        {formatCurrency(formData.revenue)} ₽
                      </p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-xs text-muted-foreground">Чистая прибыль</p>
                      <p className="text-sm md:text-base font-medium">
                        {formatCurrency(formData.netProfit)} ₽
                      </p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-xs text-muted-foreground">Активы</p>
                      <p className="text-sm md:text-base font-medium">
                        {formatCurrency(formData.totalAssets)} ₽
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-2">
                    <Button
                      onClick={handleSaveData}
                      disabled={isSaving}
                      className="flex-1 min-h-11 md:min-h-9 text-xs md:text-sm"
                      data-testid="button-save-generated-data"
                    >
                      {isSaving ? (
                        <>
                          <Target className="h-3 w-3 md:h-4 md:w-4 mr-2 animate-spin" />
                          Сохранение...
                        </>
                      ) : (
                        <>
                          <Save className="h-3 w-3 md:h-4 md:w-4 mr-2" />
                          Сохранить сгенерированные данные
                        </>
                      )}
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => setActiveTab('manual')}
                      className="flex-1 sm:flex-initial min-h-11 md:min-h-9 text-xs md:text-sm"
                    >
                      <Edit3 className="h-3 w-3 md:h-4 md:w-4 mr-2" />
                      Редактировать
                    </Button>
                  </div>
                </div>
              )}

              <div className="text-xs text-muted-foreground">
                Сгенерированные данные основаны на статистике реальных компаний и могут использоваться для демонстрации возможностей системы аналитики.
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}