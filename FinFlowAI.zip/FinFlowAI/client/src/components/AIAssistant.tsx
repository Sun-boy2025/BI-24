import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { 
  Zap, 
  Send, 
  Bot, 
  User, 
  Lightbulb, 
  TrendingUp, 
  AlertTriangle,
  CheckCircle
} from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

interface ChatMessage {
  id: string;
  type: 'user' | 'ai';
  content: string;
  timestamp: Date;
  analysisType?: 'recommendation' | 'insight' | 'warning' | 'forecast';
}

export default function AIAssistant() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      type: 'ai',
      content: 'Здравствуйте! Я AI-помощник для анализа ваших бизнес-данных. Задайте мне вопрос о финансовых показателях, и я проанализирую ваши данные.',
      timestamp: new Date(),
      analysisType: 'insight'
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSendMessage = () => {
    if (!inputText.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      type: 'user',
      content: inputText,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsLoading(true);

    // todo: remove mock functionality - simulate AI response
    setTimeout(() => {
      const aiResponse: ChatMessage = {
        id: (Date.now() + 1).toString(),
        type: 'ai',
        content: generateMockAIResponse(inputText),
        timestamp: new Date(),
        analysisType: getAnalysisType(inputText)
      };
      setMessages(prev => [...prev, aiResponse]);
      setIsLoading(false);
    }, 2000);

    console.log('Sending message to AI:', inputText);
  };

  // todo: remove mock functionality
  const generateMockAIResponse = (input: string): string => {
    const lowercaseInput = input.toLowerCase();
    
    if (lowercaseInput.includes('выручка') || lowercaseInput.includes('доход')) {
      return 'Анализ выручки показывает рост на 15.3% по сравнению с прошлым периодом. Основные драйверы роста: увеличение среднего чека на 8% и привлечение новых клиентов. Рекомендую сосредоточиться на удержании клиентов для стабилизации тренда.';
    }
    
    if (lowercaseInput.includes('прибыль') || lowercaseInput.includes('рентабельность')) {
      return 'Анализ рентабельности выявил снижение чистой прибыли на 8.2%. Основная причина - увеличение операционных расходов на 12%. Рекомендую провести аудит расходов и оптимизировать процессы для улучшения маржинальности.';
    }
    
    if (lowercaseInput.includes('риск') || lowercaseInput.includes('проблем')) {
      return '⚠️ Выявлены потенциальные риски: коэффициент текущей ликвидности снижается, что может указывать на проблемы с платежеспособностью. Рекомендую увеличить оборотный капитал и пересмотреть условия с поставщиками.';
    }
    
    return 'Я проанализировал ваш запрос. На основе текущих данных рекомендую обратить внимание на динамику ключевых показателей и провести более детальный анализ по интересующему вас направлению. Используйте специализированные отчеты для получения подробной информации.';
  };

  // todo: remove mock functionality
  const getAnalysisType = (input: string): ChatMessage['analysisType'] => {
    const lowercaseInput = input.toLowerCase();
    
    if (lowercaseInput.includes('риск') || lowercaseInput.includes('проблем')) return 'warning';
    if (lowercaseInput.includes('прогноз') || lowercaseInput.includes('будущ')) return 'forecast';
    if (lowercaseInput.includes('рекоменд') || lowercaseInput.includes('совет')) return 'recommendation';
    return 'insight';
  };

  const getMessageIcon = (analysisType?: ChatMessage['analysisType']) => {
    switch (analysisType) {
      case 'recommendation':
        return <Lightbulb className="h-3 w-3 md:h-4 md:w-4 text-yellow-500" />;
      case 'warning':
        return <AlertTriangle className="h-3 w-3 md:h-4 md:w-4 text-red-500" />;
      case 'forecast':
        return <TrendingUp className="h-3 w-3 md:h-4 md:w-4 text-blue-500" />;
      case 'insight':
        return <CheckCircle className="h-3 w-3 md:h-4 md:w-4 text-green-500" />;
      default:
        return null;
    }
  };

  const getBadgeText = (analysisType?: ChatMessage['analysisType']) => {
    switch (analysisType) {
      case 'recommendation':
        return 'Рекомендация';
      case 'warning':
        return 'Внимание';
      case 'forecast':
        return 'Прогноз';
      case 'insight':
        return 'Анализ';
      default:
        return '';
    }
  };

  const getBadgeVariant = (analysisType?: ChatMessage['analysisType']) => {
    switch (analysisType) {
      case 'recommendation':
        return 'default' as const;
      case 'warning':
        return 'destructive' as const;
      case 'forecast':
        return 'secondary' as const;
      case 'insight':
        return 'outline' as const;
      default:
        return 'outline' as const;
    }
  };

  return (
    <Card className="h-[500px] md:h-[600px] flex flex-col" data-testid="card-ai-assistant">
      <CardHeader className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3 space-y-2 sm:space-y-0 pb-3 md:pb-4 px-3 md:px-6">
        <div className="flex items-center gap-2 sm:gap-3 flex-1 min-w-0">
          <div className="p-1.5 md:p-2 bg-primary/10 rounded-lg flex-shrink-0">
            <Zap className="h-4 w-4 md:h-5 md:w-5 text-primary" />
          </div>
          <div className="min-w-0 flex-1">
            <CardTitle className="text-sm md:text-lg truncate" data-testid="text-ai-title">
              AI-помощник аналитика
            </CardTitle>
            <CardDescription className="text-xs md:text-sm truncate" data-testid="text-ai-description">
              Интеллектуальный анализ бизнес-данных
            </CardDescription>
          </div>
        </div>
        <Badge variant="secondary" className="text-xs px-2 py-0.5 flex-shrink-0 self-start sm:self-center" data-testid="badge-ai-status">
          Онлайн
        </Badge>
      </CardHeader>
      
      <CardContent className="flex flex-col flex-1 p-0">
        <div className="flex-1 overflow-y-auto px-3 md:px-6 space-y-3 md:space-y-4 min-h-0" data-testid="chat-messages">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex gap-2 md:gap-3 ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
              data-testid={`message-${message.id}`}
            >
              {message.type === 'ai' && (
                <Avatar className="h-6 w-6 md:h-8 md:w-8 flex-shrink-0">
                  <AvatarFallback className="bg-primary text-primary-foreground">
                    <Bot className="h-3 w-3 md:h-4 md:w-4" />
                  </AvatarFallback>
                </Avatar>
              )}
              
              <div className={`max-w-[85%] sm:max-w-[80%] ${message.type === 'user' ? 'order-last' : ''} min-w-0`}>
                <div
                  className={`p-2 md:p-3 rounded-lg ${
                    message.type === 'user'
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-muted'
                  }`}
                >
                  {message.type === 'ai' && message.analysisType && (
                    <div className="flex flex-wrap items-center gap-1.5 md:gap-2 mb-1.5 md:mb-2">
                      {getMessageIcon(message.analysisType)}
                      <Badge 
                        variant={getBadgeVariant(message.analysisType)} 
                        className="text-xs px-1.5 md:px-2 py-0.5"
                        data-testid={`badge-message-type-${message.id}`}
                      >
                        {getBadgeText(message.analysisType)}
                      </Badge>
                    </div>
                  )}
                  <p className="text-xs md:text-sm whitespace-pre-wrap break-words" data-testid={`text-message-content-${message.id}`}>
                    {message.content}
                  </p>
                </div>
                <p className="text-xs text-muted-foreground mt-1 px-1">
                  {message.timestamp.toLocaleTimeString('ru-RU', { 
                    hour: '2-digit', 
                    minute: '2-digit' 
                  })}
                </p>
              </div>
              
              {message.type === 'user' && (
                <Avatar className="h-6 w-6 md:h-8 md:w-8 flex-shrink-0">
                  <AvatarFallback className="bg-secondary">
                    <User className="h-3 w-3 md:h-4 md:w-4" />
                  </AvatarFallback>
                </Avatar>
              )}
            </div>
          ))}
          
          {isLoading && (
            <div className="flex gap-2 md:gap-3 justify-start" data-testid="loading-message">
              <Avatar className="h-6 w-6 md:h-8 md:w-8 flex-shrink-0">
                <AvatarFallback className="bg-primary text-primary-foreground">
                  <Bot className="h-3 w-3 md:h-4 md:w-4" />
                </AvatarFallback>
              </Avatar>
              <div className="bg-muted p-2 md:p-3 rounded-lg">
                <div className="flex gap-1">
                  <div className="w-1.5 h-1.5 md:w-2 md:h-2 bg-muted-foreground rounded-full animate-bounce"></div>
                  <div className="w-1.5 h-1.5 md:w-2 md:h-2 bg-muted-foreground rounded-full animate-bounce delay-100"></div>
                  <div className="w-1.5 h-1.5 md:w-2 md:h-2 bg-muted-foreground rounded-full animate-bounce delay-200"></div>
                </div>
              </div>
            </div>
          )}
        </div>
        
        <div className="border-t p-3 md:p-4">
          <div className="flex flex-col sm:flex-row gap-2">
            <Textarea
              placeholder="Задайте вопрос о ваших данных..."
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              disabled={isLoading}
              className="resize-none text-xs md:text-sm min-h-[60px] md:min-h-[80px] flex-1"
              rows={1}
              data-testid="input-ai-message"
            />
            <Button
              onClick={handleSendMessage}
              disabled={!inputText.trim() || isLoading}
              size="sm"
              className="self-end sm:self-start w-full sm:w-auto"
              data-testid="button-send-message"
            >
              <Send className="h-3 w-3 md:h-4 md:w-4 mr-1 sm:mr-0" />
              <span className="sm:hidden">Отправить</span>
            </Button>
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            AI анализирует ваши данные из 1С и предоставляет персонализированные рекомендации
          </p>
        </div>
      </CardContent>
    </Card>
  );
}