import { 
  BarChart3, 
  TrendingUp, 
  PieChart, 
  LineChart, 
  Calculator,
  FileText,
  Upload,
  Download,
  Zap,
  Target,
  DollarSign,
  Activity,
  Users,
  Briefcase,
  Settings,
  HelpCircle
} from "lucide-react";
import { 
  Sidebar, 
  SidebarContent, 
  SidebarGroup, 
  SidebarGroupContent, 
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const analyticsMenuItems = [
  {
    title: "Финансовое здоровье",
    icon: Activity,
    badge: "Топ",
    id: "financial_health"
  },
  {
    title: "Анализ прибыльности",
    icon: TrendingUp,
    id: "profitability_analysis"
  },
  {
    title: "Коэффициенты ликвидности",
    icon: LineChart,
    id: "liquidity_ratios"
  },
  {
    title: "Анализ задолженности",
    icon: DollarSign,
    id: "debt_analysis"
  },
  {
    title: "Коэффициенты эффективности",
    icon: Target,
    id: "efficiency_ratios"
  },
  {
    title: "Тренды роста",
    icon: BarChart3,
    badge: "Новый",
    id: "growth_trends"
  },
  {
    title: "Анализ денежных потоков",
    icon: Calculator,
    id: "cash_flow_analysis"
  },
  {
    title: "Точка безубыточности",
    icon: Target,
    id: "break_even_analysis"
  },
  {
    title: "Структура затрат",
    icon: PieChart,
    id: "cost_structure"
  },
  {
    title: "Анализ выручки",
    icon: TrendingUp,
    id: "revenue_analysis"
  },
  {
    title: "Анализ маржинальности",
    icon: LineChart,
    id: "margin_analysis"
  },
  {
    title: "Оборотный капитал",
    icon: Activity,
    id: "working_capital"
  }
];

const additionalMenuItems = [
  {
    title: "Оборачиваемость запасов",
    icon: BarChart3,
    id: "inventory_turnover"
  },
  {
    title: "Анализ дебиторки",
    icon: FileText,
    id: "receivables_analysis"
  },
  {
    title: "Анализ кредиторки",
    icon: Users,
    id: "payables_analysis"
  },
  {
    title: "Налоговая оптимизация",
    icon: Calculator,
    badge: "AI",
    id: "tax_optimization"
  },
  {
    title: "Бюджет vs факт",
    icon: Target,
    id: "budget_variance"
  },
  {
    title: "Точность прогнозов",
    icon: TrendingUp,
    id: "forecast_accuracy"
  },
  {
    title: "Сезонный анализ",
    icon: LineChart,
    id: "seasonal_analysis"
  },
  {
    title: "Бенчмаркинг",
    icon: BarChart3,
    id: "competitor_benchmarking"
  },
  {
    title: "Оценка рисков",
    icon: Activity,
    badge: "AI",
    id: "risk_assessment"
  },
  {
    title: "Инвестиционный анализ",
    icon: DollarSign,
    id: "investment_analysis"
  },
  {
    title: "KPI эффективности",
    icon: Target,
    id: "performance_kpi"
  },
  {
    title: "Дашборд руководителя",
    icon: Briefcase,
    badge: "Pro",
    id: "executive_dashboard"
  }
];

const toolsMenuItems = [
  {
    title: "Ввод данных",
    icon: Calculator,
    badge: "Новый",
    id: "data_entry"
  },
  {
    title: "Импорт из 1С",
    icon: Upload,
    id: "import_1c"
  },
  {
    title: "Экспорт отчетов",
    icon: Download,
    id: "export_reports"
  },
  {
    title: "AI Помощник",
    icon: Zap,
    badge: "AI",
    id: "ai_assistant"
  }
];

interface AppSidebarProps {
  selectedItem?: string;
  onItemSelect?: (itemId: string) => void;
  isMobile?: boolean;
}

export default function AppSidebar({ selectedItem, onItemSelect, isMobile = false }: AppSidebarProps) {
  const handleItemClick = (itemId: string) => {
    console.log(`Selected analytics item: ${itemId}`);
    onItemSelect?.(itemId);
  };

  return (
    <Sidebar>
      <SidebarHeader className={`${isMobile ? 'p-3' : 'p-4'}`}>
        <div className="flex items-center gap-2 md:gap-3">
          <div className={`${isMobile ? 'w-6 h-6' : 'w-8 h-8'} bg-primary rounded-lg flex items-center justify-center flex-shrink-0`}>
            <BarChart3 className={`${isMobile ? 'w-3 h-3' : 'w-5 h-5'} text-primary-foreground`} />
          </div>
          <div className="flex flex-col min-w-0">
            <h2 className={`font-semibold ${isMobile ? 'text-xs' : 'text-sm'} truncate`} data-testid="text-sidebar-title">
              {isMobile ? "BA Pro" : "Business Analytics"}
            </h2>
            {!isMobile && (
              <p className="text-xs text-muted-foreground">
                Система аналитики
              </p>
            )}
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel className={`text-xs ${isMobile ? '' : 'md:text-sm'}`}>Основные инструменты</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {toolsMenuItems.map((item) => (
                <SidebarMenuItem key={item.id}>
                  <SidebarMenuButton 
                    onClick={() => handleItemClick(item.id)}
                    data-testid={`menu-item-${item.id}`}
                    className={`${
                      selectedItem === item.id 
                        ? "bg-sidebar-accent text-sidebar-accent-foreground" 
                        : ""
                    } ${isMobile ? 'min-h-11 text-sm px-2' : 'min-h-9 px-3'}`}
                  >
                    <item.icon className="w-4 h-4 flex-shrink-0" />
                    <span className="truncate">{item.title}</span>
                    {item.badge && (
                      <Badge 
                        variant={item.badge === 'AI' ? 'default' : 'secondary'} 
                        className={`ml-auto ${isMobile ? 'text-xs px-1.5 py-0.5' : 'text-xs px-2 py-0.5'} flex-shrink-0`}
                        data-testid={`badge-${item.id}`}
                      >
                        {item.badge}
                      </Badge>
                    )}
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel className={`text-xs ${isMobile ? '' : 'md:text-sm'}`}>Базовая аналитика</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {analyticsMenuItems.map((item) => (
                <SidebarMenuItem key={item.id}>
                  <SidebarMenuButton 
                    onClick={() => handleItemClick(item.id)}
                    data-testid={`menu-item-${item.id}`}
                    className={`${
                      selectedItem === item.id 
                        ? "bg-sidebar-accent text-sidebar-accent-foreground" 
                        : ""
                    } ${isMobile ? 'min-h-11 text-sm px-2' : 'min-h-9 px-3'}`}
                  >
                    <item.icon className="w-4 h-4 flex-shrink-0" />
                    <span className="text-sm truncate">{item.title}</span>
                    {item.badge && (
                      <Badge 
                        variant={item.badge === 'Топ' ? 'default' : item.badge === 'Новый' ? 'secondary' : 'outline'} 
                        className={`ml-auto ${isMobile ? 'text-xs px-1.5 py-0.5' : 'text-xs px-2 py-0.5'} flex-shrink-0`}
                        data-testid={`badge-${item.id}`}
                      >
                        {item.badge}
                      </Badge>
                    )}
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel className={`text-xs ${isMobile ? '' : 'md:text-sm'}`}>Продвинутая аналитика</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {additionalMenuItems.map((item) => (
                <SidebarMenuItem key={item.id}>
                  <SidebarMenuButton 
                    onClick={() => handleItemClick(item.id)}
                    data-testid={`menu-item-${item.id}`}
                    className={`${
                      selectedItem === item.id 
                        ? "bg-sidebar-accent text-sidebar-accent-foreground" 
                        : ""
                    } ${isMobile ? 'min-h-11 text-sm px-2' : 'min-h-9 px-3'}`}
                  >
                    <item.icon className="w-4 h-4 flex-shrink-0" />
                    <span className="text-sm truncate">{item.title}</span>
                    {item.badge && (
                      <Badge 
                        variant={item.badge === 'AI' ? 'default' : item.badge === 'Pro' ? 'secondary' : 'outline'} 
                        className={`ml-auto ${isMobile ? 'text-xs px-1.5 py-0.5' : 'text-xs px-2 py-0.5'} flex-shrink-0`}
                        data-testid={`badge-${item.id}`}
                      >
                        {item.badge}
                      </Badge>
                    )}
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className={`${isMobile ? 'p-3' : 'p-4'} border-t`}>
        <div className={`flex ${isMobile ? 'flex-col gap-2' : 'gap-2'}`}>
          <Button 
            variant="ghost" 
            size={isMobile ? 'default' : 'sm'} 
            className={`${isMobile ? 'w-full justify-start min-h-11' : 'flex-1 min-h-9'}`}
            data-testid="button-settings"
          >
            <Settings className="w-4 h-4 mr-2 flex-shrink-0" />
            <span className="truncate">Настройки</span>
          </Button>
          <Button 
            variant="ghost" 
            size={isMobile ? 'default' : 'sm'} 
            className={`${isMobile ? 'w-full justify-start min-h-11' : 'min-h-9'}`}
            data-testid="button-help"
          >
            <HelpCircle className="w-4 h-4 mr-2 flex-shrink-0" />
            <span className={`${isMobile ? '' : 'hidden lg:inline'} truncate`}>Помощь</span>
          </Button>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}