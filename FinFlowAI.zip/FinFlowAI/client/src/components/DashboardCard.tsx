import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { TrendingUp, TrendingDown, Minus, MoreHorizontal, Download } from "lucide-react";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";

interface DashboardCardProps {
  title: string;
  value: string | number;
  description?: string;
  trend?: "up" | "down" | "neutral";
  trendValue?: string;
  badge?: string;
  badgeVariant?: "default" | "secondary" | "destructive" | "outline";
  loading?: boolean;
  isMobile?: boolean;
  onExport?: () => void;
  onViewDetails?: () => void;
}

export default function DashboardCard({
  title,
  value,
  description,
  trend,
  trendValue,
  badge,
  badgeVariant = "secondary",
  loading = false,
  isMobile = false,
  onExport,
  onViewDetails
}: DashboardCardProps) {
  const getTrendIcon = () => {
    switch (trend) {
      case "up":
        return <TrendingUp className="h-4 w-4 text-green-500" />;
      case "down":
        return <TrendingDown className="h-4 w-4 text-red-500" />;
      case "neutral":
        return <Minus className="h-4 w-4 text-muted-foreground" />;
      default:
        return null;
    }
  };

  const getTrendColor = () => {
    switch (trend) {
      case "up":
        return "text-green-500";
      case "down":
        return "text-red-500";
      case "neutral":
        return "text-muted-foreground";
      default:
        return "text-muted-foreground";
    }
  };

  const handleExport = () => {
    console.log(`Exporting ${title} card data`);
    onExport?.();
  };

  const handleViewDetails = () => {
    console.log(`Viewing details for ${title}`);
    onViewDetails?.();
  };

  if (loading) {
    return (
      <Card data-testid={`card-${title.toLowerCase().replace(/\s+/g, '-')}`}>
        <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
          <div className="flex flex-col space-y-2">
            <div className="h-4 bg-muted animate-pulse rounded w-32"></div>
            <div className="h-3 bg-muted animate-pulse rounded w-20"></div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-8 bg-muted animate-pulse rounded w-24 mb-2"></div>
          <div className="h-4 bg-muted animate-pulse rounded w-full"></div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card 
      className={`hover-elevate cursor-pointer ${isMobile ? 'p-1' : ''}`} 
      data-testid={`card-${title.toLowerCase().replace(/\s+/g, '-')}`}
    >
      <CardHeader className={`flex ${isMobile ? 'flex-col space-y-2' : 'flex-row items-center justify-between'} gap-2 space-y-0 ${isMobile ? 'pb-1 px-3' : 'pb-2'}`}>
        <div className={`flex items-center ${isMobile ? 'justify-between w-full' : 'gap-2'} min-w-0`}>
          <CardTitle className={`${isMobile ? 'text-xs' : 'text-sm'} font-medium truncate flex-1`} data-testid={`text-card-title-${title.toLowerCase().replace(/\s+/g, '-')}`}>
            {title}
          </CardTitle>
          {badge && (
            <Badge variant={badgeVariant} className={`text-xs ${isMobile ? 'px-1.5 py-0.5 text-xs' : 'px-2 py-0.5'} flex-shrink-0 ${isMobile ? 'ml-2' : 'ml-0'}`} data-testid={`badge-${title.toLowerCase().replace(/\s+/g, '-')}`}>
              {badge}
            </Badge>
          )}
          {isMobile && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-6 w-6 flex-shrink-0 ml-1" data-testid={`button-card-menu-${title.toLowerCase().replace(/\s+/g, '-')}`}>
                  <MoreHorizontal className="h-3 w-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={handleViewDetails} data-testid={`menu-item-view-details-${title.toLowerCase().replace(/\s+/g, '-')}`}>
                  Подробнее
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleExport} data-testid={`menu-item-export-${title.toLowerCase().replace(/\s+/g, '-')}`}>
                  <Download className="mr-2 h-4 w-4" />
                  Экспорт
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
        {!isMobile && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8 flex-shrink-0" data-testid={`button-card-menu-${title.toLowerCase().replace(/\s+/g, '-')}`}>
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={handleViewDetails} data-testid={`menu-item-view-details-${title.toLowerCase().replace(/\s+/g, '-')}`}>
                Подробнее
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleExport} data-testid={`menu-item-export-${title.toLowerCase().replace(/\s+/g, '-')}`}>
                <Download className="mr-2 h-4 w-4" />
                Экспорт
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        )}
      </CardHeader>
      <CardContent className={isMobile ? 'px-3 pt-1' : ''}>
        <div className={`flex items-center ${isMobile ? 'flex-col items-start gap-1' : 'justify-between'}`}>
          <div className={`${isMobile ? 'text-lg' : 'text-2xl'} font-bold ${isMobile ? 'self-start' : ''}`} data-testid={`text-card-value-${title.toLowerCase().replace(/\s+/g, '-')}`}>
            {value}
          </div>
          {trend && trendValue && (
            <div className={`flex items-center gap-1 ${getTrendColor()} ${isMobile ? 'self-end mt-1' : ''}`} data-testid={`text-trend-${title.toLowerCase().replace(/\s+/g, '-')}`}>
              {getTrendIcon()}
              <span className={`${isMobile ? 'text-xs' : 'text-sm'} font-medium`}>{trendValue}</span>
            </div>
          )}
        </div>
        {description && (
          <CardDescription className={`${isMobile ? 'mt-1 text-xs leading-tight' : 'mt-2'}`} data-testid={`text-card-description-${title.toLowerCase().replace(/\s+/g, '-')}`}>
            {description}
          </CardDescription>
        )}
      </CardContent>
    </Card>
  );
}