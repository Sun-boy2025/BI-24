import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Upload, 
  Download, 
  FileText, 
  Database, 
  CheckCircle, 
  AlertCircle,
  Clock,
  FileSpreadsheet
} from "lucide-react";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function ImportExportPanel() {
  const [importProgress, setImportProgress] = useState(0);
  const [exportProgress, setExportProgress] = useState(0);
  const [importStatus, setImportStatus] = useState<'idle' | 'uploading' | 'processing' | 'completed' | 'error'>('idle');
  const [exportFormat, setExportFormat] = useState<'pdf' | 'xlsx'>('pdf');
  const [selectedPeriod, setSelectedPeriod] = useState('2024-q4');

  const handleFileUpload = () => {
    console.log('Starting 1C file upload');
    setImportStatus('uploading');
    setImportProgress(0);
    
    // Simulate upload progress
    const interval = setInterval(() => {
      setImportProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setImportStatus('processing');
          
          // Simulate processing
          setTimeout(() => {
            setImportStatus('completed');
          }, 2000);
          
          return 100;
        }
        return prev + 10;
      });
    }, 200);
  };

  const handleExportReport = () => {
    console.log(`Exporting reports in ${exportFormat} format for period ${selectedPeriod}`);
    setExportProgress(0);
    
    const interval = setInterval(() => {
      setExportProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          console.log(`Export completed: business-analytics-${selectedPeriod}.${exportFormat}`);
          return 100;
        }
        return prev + 15;
      });
    }, 300);
  };

  const getStatusIcon = () => {
    switch (importStatus) {
      case 'completed':
        return <CheckCircle className="h-4 w-4 md:h-5 md:w-5 text-green-500" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 md:h-5 md:w-5 text-red-500" />;
      case 'uploading':
      case 'processing':
        return <Clock className="h-4 w-4 md:h-5 md:w-5 text-blue-500" />;
      default:
        return <Database className="h-4 w-4 md:h-5 md:w-5 text-muted-foreground" />;
    }
  };

  const getStatusText = () => {
    switch (importStatus) {
      case 'uploading':
        return 'Загрузка файла...';
      case 'processing':
        return 'Обработка данных...';
      case 'completed':
        return 'Данные успешно импортированы';
      case 'error':
        return 'Ошибка при импорте';
      default:
        return 'Готов к импорту';
    }
  };

  return (
    <div className="grid gap-4 md:gap-6 grid-cols-1 md:grid-cols-2">
      {/* Import Section */}
      <Card data-testid="card-import-1c">
        <CardHeader className="pb-3 md:pb-6">
          <div className="flex items-center gap-2">
            <Upload className="h-4 w-4 md:h-5 md:w-5 text-primary" />
            <CardTitle className="text-sm md:text-lg truncate">
              <span className="md:hidden">Импорт 1С</span>
              <span className="hidden md:inline">Импорт из 1С:Бухгалтерия</span>
            </CardTitle>
          </div>
          <CardDescription className="text-xs md:text-sm">
            Загрузите данные из 1С для анализа
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3 md:space-y-4 px-3 md:px-6">
          <div className="space-y-2">
            <Label htmlFor="file-upload" className="text-xs md:text-sm">Файл данных 1С</Label>
            <div className="flex flex-col md:flex-row gap-2 md:items-center">
              <Input 
                id="file-upload"
                type="file" 
                accept=".xml,.txt,.csv"
                disabled={importStatus === 'uploading' || importStatus === 'processing'}
                data-testid="input-file-upload"
                className="text-xs md:text-sm flex-1 min-w-0"
              />
              <Button 
                onClick={handleFileUpload}
                disabled={importStatus === 'uploading' || importStatus === 'processing'}
                size="sm"
                className="w-full md:w-auto flex-shrink-0 min-h-11 md:min-h-9"
                data-testid="button-upload-file"
              >
                {importStatus === 'uploading' || importStatus === 'processing' ? (
                  <>
                    <Clock className="h-3 w-3 md:h-4 md:w-4 mr-2" />
                    <span className="text-xs md:text-sm">Обработка</span>
                  </>
                ) : (
                  <>
                    <Upload className="h-3 w-3 md:h-4 md:w-4 mr-2" />
                    <span className="text-xs md:text-sm">Загрузить</span>
                  </>
                )}
              </Button>
            </div>
          </div>

          {importStatus !== 'idle' && (
            <div className="space-y-2">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2 min-w-0 flex-1">
                  {getStatusIcon()}
                  <span className="text-xs md:text-sm font-medium truncate" data-testid="text-import-status">
                    {getStatusText()}
                  </span>
                </div>
                <Badge 
                  variant={importStatus === 'completed' ? 'default' : importStatus === 'error' ? 'destructive' : 'secondary'}
                  className="text-xs px-2 py-0.5 flex-shrink-0"
                  data-testid="badge-import-status"
                >
                  {importStatus === 'completed' ? 'Готово' : 
                   importStatus === 'error' ? 'Ошибка' : 'В процессе'}
                </Badge>
              </div>
              
              {(importStatus === 'uploading' || importStatus === 'processing') && (
                <Progress value={importProgress} className="w-full" data-testid="progress-import" />
              )}
            </div>
          )}

          <div className="text-xs text-muted-foreground">
            Поддерживаемые форматы: XML, TXT, CSV
            <br />
            Поддерживаемые конфигурации: УСН, ОСНО, Патент
          </div>
        </CardContent>
      </Card>

      {/* Export Section */}
      <Card data-testid="card-export-reports">
        <CardHeader className="pb-3 md:pb-6">
          <div className="flex items-center gap-2">
            <Download className="h-4 w-4 md:h-5 md:w-5 text-primary" />
            <CardTitle className="text-sm md:text-lg">
              Экспорт отчетов
            </CardTitle>
          </div>
          <CardDescription className="text-xs md:text-sm">
            Экспорт аналитических отчетов в PDF или XLSX
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3 md:space-y-4 px-3 md:px-6">
          <div className="grid gap-3 md:gap-4 grid-cols-1 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="export-period" className="text-xs md:text-sm">
                Период
              </Label>
              <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                <SelectTrigger data-testid="select-export-period" className="text-xs md:text-sm min-h-11 md:min-h-10">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="2024-q4">4 кв. 2024</SelectItem>
                  <SelectItem value="2024-q3">3 кв. 2024</SelectItem>
                  <SelectItem value="2024-q2">2 кв. 2024</SelectItem>
                  <SelectItem value="2024-q1">1 кв. 2024</SelectItem>
                  <SelectItem value="2024-year">2024 год</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="export-format" className="text-xs md:text-sm">
                Формат
              </Label>
              <Select value={exportFormat} onValueChange={(value: 'pdf' | 'xlsx') => setExportFormat(value)}>
                <SelectTrigger data-testid="select-export-format" className="text-xs md:text-sm min-h-11 md:min-h-10">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pdf">
                    <div className="flex items-center gap-2">
                      <FileText className="h-3 w-3 md:h-4 md:w-4" />
                      <span className="text-xs md:text-sm">PDF отчет</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="xlsx">
                    <div className="flex items-center gap-2">
                      <FileSpreadsheet className="h-3 w-3 md:h-4 md:w-4" />
                      <span className="text-xs md:text-sm">Excel данные</span>
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button 
            onClick={handleExportReport} 
            className="w-full text-xs md:text-sm min-h-11 md:min-h-9" 
            size="sm"
            disabled={exportProgress > 0 && exportProgress < 100}
            data-testid="button-export-report"
          >
            {exportProgress > 0 && exportProgress < 100 ? (
              <>
                <Clock className="h-3 w-3 md:h-4 md:w-4 mr-2" />
                Формирование отчета...
              </>
            ) : (
              <>
                <Download className="h-3 w-3 md:h-4 md:w-4 mr-2" />
                Экспортировать отчеты
              </>
            )}
          </Button>

          {exportProgress > 0 && (
            <div className="space-y-2">
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs md:text-sm">
                <span data-testid="text-export-status" className="min-w-0 flex-1 truncate">
                  {exportProgress >= 100 ? 'Экспорт завершен' : 'Формирование отчета...'}
                </span>
                <span data-testid="text-export-progress" className="flex-shrink-0">{exportProgress}%</span>
              </div>
              <Progress value={exportProgress} className="w-full" data-testid="progress-export" />
            </div>
          )}

          <div className="text-xs text-muted-foreground">
            PDF - аналитические отчеты с графиками
            <br />
            XLSX - исходные данные для дальнейшего анализа
          </div>
        </CardContent>
      </Card>
    </div>
  );
}