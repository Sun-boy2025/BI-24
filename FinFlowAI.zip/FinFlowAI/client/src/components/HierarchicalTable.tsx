import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  ChevronRight, 
  ChevronDown, 
  Calendar,
  TrendingUp,
  TrendingDown,
  DollarSign,
  BarChart3,
  FileSpreadsheet,
  Plus
} from "lucide-react";
import type { HierarchicalDataPeriod, InstrumentData } from "@shared/schema";

// API Response types
interface ApiResponse<T> {
  success: boolean;
  data: T;
  error?: string;
}

interface HierarchicalTableProps {
  companyId: string;
  year: number;
  instrumentKey?: string;
  onPeriodSelect?: (period: HierarchicalDataPeriod) => void;
}

interface ExpandedPeriods {
  [periodId: string]: boolean;
}

export default function HierarchicalTable({
  companyId,
  year,
  instrumentKey,
  onPeriodSelect
}: HierarchicalTableProps) {
  const [expandedPeriods, setExpandedPeriods] = useState<ExpandedPeriods>({});

  // Fetch hierarchical period structure
  const { data: hierarchyData, isLoading: isLoadingHierarchy, error } = useQuery({
    queryKey: ['/api/periods/hierarchy', companyId, year],
    enabled: Boolean(companyId && year),
  });

  // Fetch instrument data for all periods
  const { data: instrumentDataList, isLoading: isLoadingData } = useQuery({
    queryKey: ['/api/instrument-data', companyId, instrumentKey],
    enabled: Boolean(companyId && instrumentKey),
  });

  const hierarchyResponse = hierarchyData as ApiResponse<HierarchicalDataPeriod[]> | undefined;
  const dataResponse = instrumentDataList as ApiResponse<InstrumentData[]> | undefined;
  
  const periods: HierarchicalDataPeriod[] = hierarchyResponse?.success ? hierarchyResponse.data || [] : [];
  const dataMap = new Map<string, InstrumentData>();
  
  // Create a map of period ID to instrument data for quick lookup
  if (dataResponse?.success && Array.isArray(dataResponse.data)) {
    dataResponse.data.forEach((item: InstrumentData) => {
      dataMap.set(item.periodId, item);
    });
  }

  const togglePeriod = (periodId: string, hasChildren: boolean) => {
    if (!hasChildren) return;
    
    setExpandedPeriods(prev => {
      const newExpanded = { ...prev };
      
      // Auto-collapse siblings at the same level (drill-down behavior)
      const period = findPeriodById(periods, periodId);
      if (period) {
        const siblings = period ? getSiblings(periods, period) : [];
        siblings.forEach(sibling => {
          if (sibling.id !== periodId) {
            delete newExpanded[sibling.id];
            // Also collapse all descendants of siblings
            collapseDescendants(sibling, newExpanded);
          }
        });
      }
      
      // Toggle the selected period
      if (newExpanded[periodId]) {
        delete newExpanded[periodId];
        // Collapse all descendants
        const periodData = findPeriodById(periods, periodId);
        if (periodData) {
          collapseDescendants(periodData, newExpanded);
        }
      } else {
        newExpanded[periodId] = true;
      }
      
      return newExpanded;
    });
  };

  const findPeriodById = (periods: HierarchicalDataPeriod[], id: string): HierarchicalDataPeriod | null => {
    for (const period of periods) {
      if (period.id === id) return period;
      const children = period.children || [];
      const found = findPeriodById(children, id);
      if (found) return found;
    }
    return null;
  };

  const getSiblings = (periods: HierarchicalDataPeriod[] | undefined, target: HierarchicalDataPeriod): HierarchicalDataPeriod[] => {
    if (!periods) return [];
    // Find siblings by looking for periods with the same parent
    const findSiblingsRecursive = (periodList: HierarchicalDataPeriod[], parentId: string | null): HierarchicalDataPeriod[] => {
      const directChildren = periodList.filter(p => p.parentId === parentId);
      if (directChildren.some(p => p.id === target.id)) {
        return directChildren;
      }
      
      for (const period of periodList) {
        const children = period.children || [];
        const result = findSiblingsRecursive(children, period.id);
        if (result.length > 0) return result;
      }
      return [];
    };
    
    return findSiblingsRecursive(periods, target.parentId);
  };

  const collapseDescendants = (period: HierarchicalDataPeriod, expandedMap: ExpandedPeriods) => {
    const children = period.children || [];
    children.forEach(child => {
      delete expandedMap[child.id];
      collapseDescendants(child, expandedMap);
    });
  };

  const formatDate = (date: string | Date | null | undefined, periodType: string) => {
    if (!date) return 'Дата не указана';
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    if (!dateObj || isNaN(dateObj.getTime())) return 'Неверная дата';
    
    switch (periodType) {
      case 'year':
        return dateObj.getFullYear().toString();
      case 'quarter':
        return `${Math.floor((dateObj.getMonth() + 3) / 3)} кв. ${dateObj.getFullYear()}`;
      case 'month':
        return dateObj.toLocaleDateString('ru-RU', { month: 'long', year: 'numeric' });
      case 'day':
        return dateObj.toLocaleDateString('ru-RU');
      default:
        return typeof date === 'string' ? date : dateObj.toLocaleDateString('ru-RU');
    }
  };

  const formatCurrency = (value?: string | null) => {
    if (!value) return '—';
    const num = parseFloat(value);
    if (isNaN(num)) return '—';
    return new Intl.NumberFormat('ru-RU', {
      style: 'currency',
      currency: 'RUB',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(num);
  };

  const formatCurrencyCompact = (value?: string | null) => {
    if (!value) return '—';
    const num = parseFloat(value);
    if (isNaN(num)) return '—';
    
    // For mobile, use compact format for large numbers
    if (Math.abs(num) >= 1000000) {
      return new Intl.NumberFormat('ru-RU', {
        notation: 'compact',
        maximumFractionDigits: 1,
      }).format(num) + '₽';
    } else if (Math.abs(num) >= 1000) {
      return new Intl.NumberFormat('ru-RU', {
        maximumFractionDigits: 0,
      }).format(num) + '₽';
    }
    
    return new Intl.NumberFormat('ru-RU', {
      style: 'currency',
      currency: 'RUB',
      maximumFractionDigits: 0,
    }).format(num);
  };

  const getPeriodTypeIcon = (periodType: string) => {
    switch (periodType) {
      case 'year': return <Calendar className="h-4 w-4" />;
      case 'quarter': return <BarChart3 className="h-4 w-4" />;
      case 'month': return <DollarSign className="h-4 w-4" />;
      case 'day': return <FileSpreadsheet className="h-4 w-4" />;
      default: return <Calendar className="h-4 w-4" />;
    }
  };

  const getPeriodTypeBadgeVariant = (periodType: string) => {
    switch (periodType) {
      case 'year': return 'default' as const;
      case 'quarter': return 'secondary' as const;
      case 'month': return 'outline' as const;
      case 'day': return 'destructive' as const;
      default: return 'default' as const;
    }
  };

  const renderPeriod = (period: HierarchicalDataPeriod, level: number = 0): JSX.Element => {
    const hasChildren = (period.children?.length || 0) > 0;
    const isExpanded = expandedPeriods[period.id] || false;
    const instrumentData = dataMap.get(period.id);
    const hasData = instrumentData || period.hasData;

    // Calculate revenue and profit for display
    let revenue = null;
    let netProfit = null;
    if (instrumentData) {
      // Try to get data from different field types
      const manualData = instrumentData.manualInputData as Record<string, any> || {};
      const calculatedData = instrumentData.autoCalculatedData as Record<string, any> || {};
      const editableData = instrumentData.editableCalculationData as Record<string, any> || {};
      
      // Try common field names for revenue
      revenue = manualData.revenue || manualData.выручка || manualData.income || 
               calculatedData.revenue || calculatedData.выручка || calculatedData.income ||
               editableData.revenue || editableData.выручка || editableData.income || null;
      
      // Try common field names for profit  
      netProfit = manualData.netProfit || manualData.чистаяПрибыль || manualData.profit ||
                 calculatedData.netProfit || calculatedData.чистаяПрибыль || calculatedData.profit ||
                 editableData.netProfit || editableData.чистаяПрибыль || editableData.profit || null;
    }

    return (
      <div key={period.id} data-testid={`period-row-${period.id}`}>
        <div 
          className={`
            flex items-center gap-2 md:gap-3 py-2 md:py-3 px-2 md:px-4 border-b border-border/50 hover-elevate cursor-pointer text-sm md:text-base
            ${level === 0 ? 'bg-card' : ''}
            ${level === 1 ? 'bg-accent/30' : ''}
            ${level === 2 ? 'bg-accent/20' : ''}  
            ${level === 3 ? 'bg-accent/10' : ''}
            ${hasData ? 'border-l-2 border-l-primary/60' : ''}
          `}
          style={{ paddingLeft: `${8 + level * 16}px` }}
          onClick={() => {
            togglePeriod(period.id, hasChildren);
            if (onPeriodSelect) onPeriodSelect(period);
          }}
        >
          {/* Expansion Toggle */}
          <div className="flex items-center justify-center w-9 h-9">
            {hasChildren ? (
              <Button
                variant="ghost"
                size="icon"
                data-testid={`button-toggle-${period.id}`}
              >
                {isExpanded ? (
                  <ChevronDown className="h-4 w-4" />
                ) : (
                  <ChevronRight className="h-4 w-4" />
                )}
              </Button>
            ) : (
              <div className="w-9 h-9" />
            )}
          </div>

          {/* Period Info */}
          <div className="flex items-center gap-1 md:gap-3 flex-1 min-w-0">
            <div className="hidden md:block">{getPeriodTypeIcon(period.period)}</div>
            
            <div className="flex items-center gap-1 md:gap-2 min-w-0 flex-1">
              <span className="font-medium truncate text-xs md:text-sm" data-testid={`text-period-name-${period.id}`}>
                {period.name}
              </span>
              <Badge variant={getPeriodTypeBadgeVariant(period.period)} className="text-xs shrink-0">
                {period.period === 'year' ? 'Г' : 
                 period.period === 'quarter' ? 'К' :
                 period.period === 'month' ? 'М' : 'Д'}
              </Badge>
            </div>
          </div>

          {/* Financial Data */}
          <div className="flex items-center gap-2 md:gap-6 text-xs md:text-sm">
            {revenue && (
              <div className="text-right min-w-[60px] md:min-w-[100px]">
                <div className="text-muted-foreground text-xs hidden md:block">Выручка</div>
                <div className="font-mono text-xs md:text-sm" data-testid={`text-revenue-${period.id}`}>
                  {formatCurrencyCompact(revenue)}
                </div>
              </div>
            )}
            
            {netProfit && (
              <div className="text-right min-w-[60px] md:min-w-[100px]">
                <div className="text-muted-foreground text-xs hidden md:block">Прибыль</div>
                <div className={`font-mono flex items-center gap-1 text-xs md:text-sm ${
                  parseFloat(netProfit) >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
                }`} data-testid={`text-profit-${period.id}`}>
                  {parseFloat(netProfit) >= 0 ? <TrendingUp className="h-2 w-2 md:h-3 md:w-3" /> : <TrendingDown className="h-2 w-2 md:h-3 md:w-3" />}
                  {formatCurrencyCompact(netProfit)}
                </div>
              </div>
            )}

            {/* Data indicator */}
            <div className="flex items-center shrink-0">
              {hasData ? (
                <Badge variant="outline" className="bg-primary/10 text-primary border-primary/30 text-xs">
                  <FileSpreadsheet className="h-2 w-2 md:h-3 md:w-3 mr-1" />
                  <span className="hidden md:inline">Данные</span>
                  <span className="md:hidden">★</span>
                </Badge>
              ) : (
                <Button
                  variant="outline"
                  size="sm"
                  data-testid={`button-add-data-${period.id}`}
                  onClick={(e) => {
                    e.stopPropagation();
                    // Handle add data action
                  }}
                >
                  <Plus className="h-2 w-2 md:h-3 md:w-3 mr-1" />
                  <span className="hidden md:inline">Добавить</span>
                  <span className="md:hidden">+</span>
                </Button>
              )}
            </div>
          </div>
        </div>

        {/* Children */}
        {hasChildren && isExpanded && (
          <div data-testid={`children-${period.id}`}>
            {(period.children || []).map(child => renderPeriod(child, level + 1))}
          </div>
        )}
      </div>
    );
  };

  if (error) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center text-destructive">
            <BarChart3 className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p>Ошибка загрузки данных</p>
            <p className="text-sm text-muted-foreground mt-1">
              {error instanceof Error ? error.message : 'Неизвестная ошибка'}
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card data-testid="card-hierarchical-table">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-primary" />
            <CardTitle className="text-lg">
              Иерархическая структура данных
            </CardTitle>
          </div>
          <Badge variant="secondary" className="text-sm">
            {year} год
          </Badge>
        </div>
      </CardHeader>
      
      <CardContent className="p-0">
        {isLoadingHierarchy ? (
          <div className="p-4 md:p-6 space-y-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="flex items-center gap-4">
                <Skeleton className="h-4 w-4 rounded" />
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-4 w-24 ml-auto" />
              </div>
            ))}
          </div>
        ) : periods.length === 0 ? (
          <div className="p-4 md:p-6 text-center text-muted-foreground">
            <Calendar className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p className="text-sm md:text-base">Нет данных для отображения</p>
            <p className="text-xs md:text-sm mt-1">
              Создайте периоды или добавьте данные для просмотра иерархии
            </p>
          </div>
        ) : (
          <div className="border-t overflow-x-auto">
            <div className="min-w-[600px]">
              {periods.map(period => renderPeriod(period, 0))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}