import { Bell, Settings, User, Moon, Sun, Monitor } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { useTheme } from "@/contexts/ThemeContext";

interface HeaderProps {
  isMobile?: boolean;
}

export default function Header({ isMobile = false }: HeaderProps) {
  const { theme, setTheme } = useTheme();
  
  const getThemeIcon = () => {
    switch (theme) {
      case "dark":
        return <Sun className={isMobile ? "h-4 w-4" : "h-5 w-5"} />;
      case "light":
        return <Moon className={isMobile ? "h-4 w-4" : "h-5 w-5"} />;
      default:
        return <Monitor className={isMobile ? "h-4 w-4" : "h-5 w-5"} />;
    }
  };

  const handleNotifications = () => {
    console.log('Notifications clicked');
  };

  const handleSettings = () => {
    console.log('Settings clicked');
  };

  const handleProfile = () => {
    console.log('Profile clicked');
  };

  return (
    <div className={`flex items-center ${isMobile ? 'gap-2' : 'gap-3'}`}>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button 
            variant="ghost" 
            size={isMobile ? undefined : "icon"} 
            data-testid="button-theme-toggle"
            className={isMobile ? '!h-11 !w-11 px-3' : ''}
          >
            {getThemeIcon()}
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem onClick={() => setTheme("light")} data-testid="theme-light">
            <Sun className="mr-2 h-4 w-4" />
            Светлая
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => setTheme("dark")} data-testid="theme-dark">
            <Moon className="mr-2 h-4 w-4" />
            Темная
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => setTheme("system")} data-testid="theme-system">
            <Monitor className="mr-2 h-4 w-4" />
            Системная
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      {!isMobile && (
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={handleNotifications}
          data-testid="button-notifications"
          className="relative"
        >
          <Bell className="h-5 w-5" />
          <Badge 
            variant="destructive" 
            className="absolute -top-1 -right-1 h-5 w-5 text-xs p-0 flex items-center justify-center"
            data-testid="badge-notification-count"
          >
            3
          </Badge>
        </Button>
      )}

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button 
            variant="ghost" 
            size={isMobile ? undefined : undefined}
            className={`relative ${isMobile ? '!h-11 !w-11 px-3' : 'h-9 w-9'} rounded-full`}
            data-testid="button-user-menu"
          >
            <Avatar className={isMobile ? 'h-8 w-8' : 'h-9 w-9'}>
              <AvatarImage src="/placeholder-avatar.jpg" alt="Профиль" />
              <AvatarFallback className="bg-primary text-primary-foreground text-xs">
                АИ
              </AvatarFallback>
            </Avatar>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className={isMobile ? 'w-48' : 'w-56'} align="end">
          {!isMobile && (
            <>
              <div className="flex items-center justify-start gap-2 p-2">
                <div className="flex flex-col space-y-1">
                  <p className="text-sm font-medium" data-testid="text-user-name">
                    Анна Иванова
                  </p>
                  <p className="text-xs text-muted-foreground" data-testid="text-user-role">
                    Бизнес-аналитик
                  </p>
                </div>
              </div>
              <DropdownMenuSeparator />
            </>
          )}
          <DropdownMenuItem onClick={handleProfile} data-testid="menu-item-profile">
            <User className="mr-2 h-4 w-4" />
            Профиль
          </DropdownMenuItem>
          <DropdownMenuItem onClick={handleSettings} data-testid="menu-item-settings">
            <Settings className="mr-2 h-4 w-4" />
            Настройки
          </DropdownMenuItem>
          {isMobile && (
            <DropdownMenuItem onClick={handleNotifications} data-testid="menu-item-notifications-mobile">
              <Bell className="mr-2 h-4 w-4" />
              Уведомления
              <Badge variant="destructive" className="ml-auto text-xs px-1.5 py-0.5">
                3
              </Badge>
            </DropdownMenuItem>
          )}
          <DropdownMenuSeparator />
          <DropdownMenuItem 
            className="text-destructive"
            onClick={() => console.log('Logout clicked')}
            data-testid="menu-item-logout"
          >
            Выйти
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}