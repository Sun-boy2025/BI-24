import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  ChevronRight, 
  ChevronDown, 
  TrendingUp, 
  TrendingDown,
  Calendar,
  DollarSign,
  BarChart3
} from 'lucide-react';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';

interface MovementData {
  id: string;
  period: string;
  periodType: 'year' | 'quarter' | 'month' | 'day';
  revenue: number;
  expenses: number;
  netFlow: number;
  children?: MovementData[];
  expanded?: boolean;
}

interface HierarchicalMovementsTableProps {
  title: string;
  data: MovementData[];
  onPeriodSelect?: (period: MovementData) => void;
}

export const HierarchicalMovementsTable: React.FC<HierarchicalMovementsTableProps> = ({ 
  title, 
  data: initialData, 
  onPeriodSelect 
}) => {
  const [data, setData] = useState<MovementData[]>(initialData);

  const formatCurrency = (value: number) => {
    const formatted = Math.abs(value).toLocaleString('ru-RU');
    return value >= 0 ? `${formatted} ₽` : `-${formatted} ₽`;
  };

  const toggleExpand = (id: string) => {
    const updateData = (items: MovementData[]): MovementData[] => {
      return items.map(item => {
        if (item.id === id) {
          return { ...item, expanded: !item.expanded };
        }
        if (item.children) {
          return { ...item, children: updateData(item.children) };
        }
        return item;
      });
    };
    setData(updateData(data));
  };

  const getPeriodIcon = (periodType: string) => {
    switch (periodType) {
      case 'year': return Calendar;
      case 'quarter': return BarChart3;
      case 'month': return Calendar;
      case 'day': return Calendar;
      default: return Calendar;
    }
  };

  const getPeriodDisplayName = (periodType: string) => {
    switch (periodType) {
      case 'year': return 'Год';
      case 'quarter': return 'Квартал';
      case 'month': return 'Месяц';
      case 'day': return 'День';
      default: return periodType;
    }
  };

  const renderRow = (item: MovementData, level = 0) => {
    const hasChildren = item.children && item.children.length > 0;
    const Icon = getPeriodIcon(item.periodType);
    
    return (
      <React.Fragment key={item.id}>
        <TableRow 
          className="hover-elevate cursor-pointer group"
          onClick={() => onPeriodSelect?.(item)}
          data-testid={`row-movement-${item.id}`}
        >
          <TableCell>
            <div 
              className="flex items-center gap-2"
              style={{ paddingLeft: `${level * 20}px` }}
            >
              {hasChildren && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 p-0"
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleExpand(item.id);
                  }}
                  data-testid={`button-toggle-${item.id}`}
                >
                  {item.expanded ? (
                    <ChevronDown className="h-3 w-3" />
                  ) : (
                    <ChevronRight className="h-3 w-3" />
                  )}
                </Button>
              )}
              {!hasChildren && <div className="w-6" />}
              
              <Icon className="h-4 w-4 text-muted-foreground" />
              
              <div className="flex flex-col">
                <span className="font-medium text-sm">
                  {item.period}
                </span>
                <Badge 
                  variant="outline" 
                  className="text-xs w-fit"
                >
                  {getPeriodDisplayName(item.periodType)}
                </Badge>
              </div>
            </div>
          </TableCell>
          
          <TableCell className="text-right">
            <div className="flex items-center justify-end gap-1">
              <TrendingUp className="h-3 w-3 text-green-600" />
              <span className="font-mono text-sm text-green-600">
                {formatCurrency(item.revenue)}
              </span>
            </div>
          </TableCell>
          
          <TableCell className="text-right">
            <div className="flex items-center justify-end gap-1">
              <TrendingDown className="h-3 w-3 text-red-600" />
              <span className="font-mono text-sm text-red-600">
                {formatCurrency(item.expenses)}
              </span>
            </div>
          </TableCell>
          
          <TableCell className="text-right">
            <div className="flex items-center justify-end gap-1">
              <DollarSign 
                className={`h-3 w-3 ${
                  item.netFlow >= 0 ? 'text-green-600' : 'text-red-600'
                }`} 
              />
              <span 
                className={`font-mono text-sm font-semibold ${
                  item.netFlow >= 0 ? 'text-green-600' : 'text-red-600'
                }`}
              >
                {formatCurrency(item.netFlow)}
              </span>
            </div>
          </TableCell>
        </TableRow>
        
        {hasChildren && item.expanded && 
          item.children!.map(child => renderRow(child, level + 1))
        }
      </React.Fragment>
    );
  };

  return (
    <Card data-testid="card-hierarchical-movements">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-lg">
          <BarChart3 className="h-5 w-5 text-primary" />
          {title}
        </CardTitle>
        <div className="text-sm text-muted-foreground">
          Движение средств с разбивкой по периодам • Нажмите для просмотра деталей
        </div>
      </CardHeader>
      
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[300px]">
                  Период
                </TableHead>
                <TableHead className="text-right">
                  Поступления
                </TableHead>
                <TableHead className="text-right">
                  Расходы  
                </TableHead>
                <TableHead className="text-right">
                  Чистый поток
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.length === 0 ? (
                <TableRow>
                  <TableCell 
                    colSpan={4} 
                    className="text-center py-8 text-muted-foreground"
                  >
                    Нет данных для отображения
                  </TableCell>
                </TableRow>
              ) : (
                data.map(item => renderRow(item))
              )}
            </TableBody>
          </Table>
        </div>
        
        {data.length > 0 && (
          <div className="mt-4 text-xs text-muted-foreground">
            💡 Раскройте периоды для детального просмотра по подпериодам
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default HierarchicalMovementsTable;