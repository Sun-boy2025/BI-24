import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calculator, Edit3, TrendingUp, BarChart3, Settings } from "lucide-react";

interface InstrumentData {
  title: string;
  description: string;
  category: string;
  auto_calculated_fields: string[];
  manual_input_fields: string[];
  editable_calculation_fields: string[];
  key_metrics: string[];
  main_formulas: string[];
}

interface InstrumentSpecificFieldsProps {
  instrumentKey: string;
  periodId?: string;
  onDataUpdate?: (data: Record<string, any>) => void;
}

// Полная конфигурация всех 25 аналитических инструментов
const INSTRUMENTS_CONFIG: Record<string, InstrumentData> = {
  // Инструмент 1 - Финансовое здоровье
  "financial_health": {
    title: "Финансовое здоровье",
    description: "Комплексная оценка финансового состояния компании",
    category: "financial_analysis",
    auto_calculated_fields: [
      "financial_stability_index", "overall_health_score", "risk_assessment", 
      "solvency_indicators", "liquidity_ratios", "profitability_metrics"
    ],
    manual_input_fields: [
      "current_assets", "current_liabilities", "total_assets", "total_equity",
      "annual_revenue", "net_profit", "debt_amount", "cash_reserves"
    ],
    editable_calculation_fields: [
      "risk_tolerance_level", "benchmark_industry", "health_score_weights",
      "critical_ratios_thresholds", "analysis_period"
    ],
    key_metrics: [
      "financial_strength_rating", "bankruptcy_risk_score", "investment_attractiveness",
      "credit_worthiness", "operational_efficiency", "growth_sustainability"
    ],
    main_formulas: [
      "current_ratio = current_assets / current_liabilities",
      "debt_to_equity = total_debt / total_equity",
      "roa = net_profit / total_assets * 100",
      "financial_health_score = weighted_average(all_ratios)"
    ]
  },

  // Инструмент 2 - Анализ прибыльности
  "profitability_analysis": {
    title: "Анализ прибыльности",
    description: "Детальный анализ рентабельности бизнеса",
    category: "profitability",
    auto_calculated_fields: [
      "gross_margin", "operating_margin", "net_margin", "roi", "roe", "roa"
    ],
    manual_input_fields: [
      "revenue", "cost_of_goods_sold", "operating_expenses", "interest_expenses",
      "tax_expenses", "total_assets", "shareholders_equity"
    ],
    editable_calculation_fields: [
      "target_margin", "industry_benchmark", "analysis_depth", "comparison_period"
    ],
    key_metrics: [
      "profitability_index", "margin_stability", "cost_efficiency", "revenue_quality"
    ],
    main_formulas: [
      "gross_margin = (revenue - cogs) / revenue * 100",
      "operating_margin = operating_profit / revenue * 100",
      "net_margin = net_profit / revenue * 100",
      "roi = net_profit / total_investment * 100"
    ]
  },

  // Инструмент 3 - Коэффициенты ликвидности
  "liquidity_ratios": {
    title: "Коэффициенты ликвидности",
    description: "Анализ способности компании выполнять краткосрочные обязательства",
    category: "liquidity_analysis",
    auto_calculated_fields: [
      "current_ratio", "quick_ratio", "cash_ratio", "working_capital", 
      "liquidity_index", "cash_conversion_cycle"
    ],
    manual_input_fields: [
      "cash_and_equivalents", "marketable_securities", "accounts_receivable",
      "inventory", "current_liabilities", "short_term_debt"
    ],
    editable_calculation_fields: [
      "minimum_liquidity_threshold", "optimal_cash_balance", "seasonal_adjustments",
      "emergency_fund_percentage"
    ],
    key_metrics: [
      "liquidity_strength", "cash_management_efficiency", "working_capital_optimization",
      "short_term_solvency"
    ],
    main_formulas: [
      "current_ratio = current_assets / current_liabilities",
      "quick_ratio = (current_assets - inventory) / current_liabilities", 
      "cash_ratio = cash_and_equivalents / current_liabilities",
      "working_capital = current_assets - current_liabilities"
    ]
  },

  // Инструмент 4 - Коэффициенты эффективности
  "efficiency_ratios": {
    title: "Коэффициенты эффективности",
    description: "Анализ эффективности использования активов и управления операциями",
    category: "efficiency_analysis",
    auto_calculated_fields: [
      "asset_turnover", "inventory_turnover", "receivables_turnover",
      "payables_turnover", "total_asset_efficiency", "operational_efficiency"
    ],
    manual_input_fields: [
      "total_revenue", "average_total_assets", "average_inventory", 
      "average_receivables", "average_payables", "cost_of_goods_sold"
    ],
    editable_calculation_fields: [
      "target_turnover_ratios", "industry_benchmarks", "seasonal_factors",
      "efficiency_improvement_goals"
    ],
    key_metrics: [
      "asset_utilization_score", "operational_productivity", "resource_efficiency",
      "business_cycle_optimization"
    ],
    main_formulas: [
      "asset_turnover = revenue / average_total_assets",
      "inventory_turnover = cogs / average_inventory",
      "receivables_turnover = revenue / average_receivables",
      "efficiency_index = weighted_average(all_turnover_ratios)"
    ]
  },

  // Инструмент 5 - Анализ денежных потоков
  "cash_flow_analysis": {
    title: "Анализ денежных потоков",
    description: "Детальный анализ движения денежных средств",
    category: "cash_flow",
    auto_calculated_fields: [
      "operating_cash_flow", "investing_cash_flow", "financing_cash_flow",
      "free_cash_flow", "cash_flow_margin", "cash_flow_coverage_ratio"
    ],
    manual_input_fields: [
      "cash_from_operations", "capital_expenditures", "debt_payments",
      "dividend_payments", "cash_from_financing", "beginning_cash_balance"
    ],
    editable_calculation_fields: [
      "cash_flow_forecast_period", "growth_capex_ratio", "dividend_policy",
      "debt_service_requirements"
    ],
    key_metrics: [
      "cash_generation_quality", "cash_flow_predictability", "liquidity_sustainability",
      "investment_self_financing_ability"
    ],
    main_formulas: [
      "free_cash_flow = operating_cash_flow - capital_expenditures",
      "cash_flow_margin = operating_cash_flow / revenue * 100",
      "cash_coverage_ratio = operating_cash_flow / total_debt",
      "cash_conversion_efficiency = free_cash_flow / net_income"
    ]
  },

  // Инструмент 6 - Отчет отдела продаж
  "sales_report": {
    title: "Отчет отдела продаж",
    description: "Анализ эффективности продаж, оценка работы продавцов и каналов",
    category: "sales_analytics",
    auto_calculated_fields: [
      "total_sales_revenue", "average_deal_size", "conversion_rate",
      "sales_cycle_length", "manager_performance_ranking", "sales_trend_analysis"
    ],
    manual_input_fields: [
      "sales_data_by_manager", "leads_data", "deals_pipeline", "sales_targets",
      "product_categories", "sales_channels", "customer_segments", "time_period_start", "time_period_end"
    ],
    editable_calculation_fields: [
      "target_conversion_rate", "minimum_deal_size", "sales_cycle_benchmark",
      "performance_weight_revenue", "performance_weight_deals", "seasonality_factor"
    ],
    key_metrics: [
      "monthly_sales_growth", "plan_achievement_percentage", "customer_acquisition_cost",
      "revenue_per_lead", "top_performing_managers", "underperforming_segments"
    ],
    main_formulas: [
      "conversion_rate = closed_deals / total_leads * 100",
      "average_deal_size = total_revenue / number_of_deals",
      "manager_efficiency = (actual_sales / planned_sales) * 100",
      "revenue_per_manager = total_revenue / number_of_managers",
      "customer_ltv = average_deal_size * purchase_frequency * customer_lifespan",
      "sales_velocity = (leads * conversion_rate * average_deal_size) / sales_cycle_length"
    ]
  },

  // Инструмент 7 - Факторы продаж
  "sales_factors": {
    title: "Факторы продаж",
    description: "Факторный анализ изменения выручки и выявление драйверов роста",
    category: "sales_factor_analysis",
    auto_calculated_fields: [
      "price_factor_impact", "volume_factor_impact", "mix_factor_impact",
      "total_revenue_change", "factor_contribution_ranking", "elasticity_coefficients"
    ],
    manual_input_fields: [
      "current_period_data", "previous_period_data", "product_prices_current", "product_prices_previous",
      "sales_volumes_current", "sales_volumes_previous", "external_factors", "marketing_spend", "competitor_actions"
    ],
    editable_calculation_fields: [
      "price_elasticity_base", "volume_sensitivity", "seasonal_adjustment",
      "market_growth_rate", "inflation_rate", "competition_intensity"
    ],
    key_metrics: [
      "dominant_growth_factor", "price_optimization_potential", "volume_growth_opportunity",
      "market_share_change", "competitive_position_index", "revenue_volatility_score"
    ],
    main_formulas: [
      "total_revenue_change = current_revenue - previous_revenue",
      "price_factor = (price_new - price_old) * volume_old",
      "volume_factor = price_new * (volume_new - volume_old)",
      "mix_factor = sum(share_change * margin_difference)",
      "price_elasticity = (volume_change_percent / price_change_percent)",
      "factor_significance = abs(factor_impact) / total_change * 100"
    ]
  },

  // Инструмент 8 - Отчет по маркетингу
  "marketing_report": {
    title: "Отчет по маркетингу",
    description: "Анализ эффективности маркетинговых каналов и ROI кампаний",
    category: "marketing_analytics",
    auto_calculated_fields: [
      "channel_roi", "customer_acquisition_cost", "lifetime_value",
      "ltv_cac_ratio", "channel_performance_ranking", "budget_allocation_optimal"
    ],
    manual_input_fields: [
      "marketing_channels", "channel_costs", "channel_conversions", "campaign_data",
      "customer_journey_data", "attribution_model", "brand_awareness_metrics", "organic_traffic_data", "competitor_spending"
    ],
    editable_calculation_fields: [
      "target_roi_threshold", "attribution_window_days", "ltv_calculation_period",
      "brand_value_weight", "organic_attribution_share", "seasonality_factors"
    ],
    key_metrics: [
      "best_performing_channel", "worst_performing_channel", "overall_marketing_roi",
      "customer_payback_period", "channel_saturation_points", "incremental_revenue_impact"
    ],
    main_formulas: [
      "cac = total_marketing_spend / number_of_acquired_customers",
      "roi_marketing = (revenue_from_channel - channel_cost) / channel_cost * 100",
      "roas = revenue_from_ads / ad_spend",
      "ltv_cac_ratio = lifetime_value / customer_acquisition_cost",
      "channel_efficiency = conversions / impressions * 100",
      "payback_period = cac / average_monthly_revenue_per_customer"
    ]
  },

  // Инструмент 9 - Юнит-экономика для маркетплейсов
  "marketplace_economics": {
    title: "Юнит-экономика для маркетплейсов",
    description: "Расчет прибыльности на единицу товара на маркетплейсах",
    category: "marketplace_economics",
    auto_calculated_fields: [
      "unit_profit", "unit_margin_percentage", "break_even_volume",
      "roi_per_unit", "marketplace_commission_total", "profitability_ranking"
    ],
    manual_input_fields: [
      "product_cost_price", "marketplace_selling_price", "marketplace_commission_rate", "fulfillment_cost",
      "advertising_cost_per_unit", "return_rate_percentage", "logistics_cost", "tax_rate", "packaging_cost", "defect_rate_percentage"
    ],
    editable_calculation_fields: [
      "target_margin_threshold", "minimum_roi_threshold", "volume_discount_tiers",
      "seasonal_price_adjustment", "competitor_price_factor", "inventory_carrying_cost"
    ],
    key_metrics: [
      "average_unit_margin", "most_profitable_products", "loss_making_products",
      "commission_impact_analysis", "price_optimization_potential", "volume_profitability_correlation"
    ],
    main_formulas: [
      "unit_profit = selling_price - cost_price - marketplace_commission - fulfillment - advertising - logistics - packaging - tax",
      "unit_margin = unit_profit / selling_price * 100",
      "marketplace_commission = selling_price * commission_rate",
      "break_even_volume = fixed_costs / unit_profit",
      "roi_per_unit = unit_profit / (cost_price + inventory_investment) * 100",
      "effective_commission_rate = total_marketplace_costs / selling_price * 100"
    ]
  },

  // Инструмент 10 - Финмодель для маркетплейсов
  "marketplace_model": {
    title: "Финмодель для маркетплейсов",
    description: "Комплексное финансовое планирование деятельности на маркетплейсах",
    category: "marketplace_financial_modeling",
    auto_calculated_fields: [
      "inventory_turnover_rate", "cash_flow_projection", "break_even_timeline",
      "roi_forecast", "growth_sustainability_index", "marketplace_dependency_risk"
    ],
    manual_input_fields: [
      "monthly_sales_forecast", "product_portfolio", "inventory_levels", "supplier_terms",
      "marketplace_growth_rates", "seasonal_patterns", "investment_requirements", "funding_sources", "cost_structure_data"
    ],
    editable_calculation_fields: [
      "growth_rate_assumption", "inventory_turnover_target", "cash_conversion_cycle_target",
      "marketplace_commission_trend", "advertising_spend_percentage", "reinvestment_rate"
    ],
    key_metrics: [
      "business_model_sustainability", "scalability_index", "competitive_advantage_duration",
      "funding_requirements", "exit_strategy_readiness", "market_expansion_potential"
    ],
    main_formulas: [
      "projected_revenue = base_revenue * (1 + growth_rate)^periods",
      "inventory_investment = projected_sales / inventory_turnover",
      "cash_flow = revenue - cogs - operating_expenses - marketplace_fees",
      "roi_annual = annual_profit / total_investment * 100",
      "payback_period = initial_investment / monthly_profit",
      "enterprise_value = annual_cash_flow / discount_rate"
    ]
  },

  // Инструмент 11 - План доходов и расходов
  "budget_planning": {
    title: "План доходов и расходов",
    description: "Комплексное планирование доходов и расходов компании с детализацией по статьям",
    category: "budget_planning",
    auto_calculated_fields: [
      "total_planned_revenue", "total_planned_expenses", "planned_profit_loss",
      "break_even_analysis", "variance_analysis", "profitability_forecast"
    ],
    manual_input_fields: [
      "revenue_sources", "planned_revenue_monthly", "fixed_expenses", "variable_expenses",
      "one_time_expenses", "seasonal_factors", "inflation_assumptions", "growth_assumptions", "contingency_reserves"
    ],
    editable_calculation_fields: [
      "planning_period_months", "revenue_growth_rate", "cost_inflation_rate",
      "contingency_percentage", "seasonality_adjustment", "scenario_pessimistic_factor", "scenario_optimistic_factor"
    ],
    key_metrics: [
      "revenue_diversification_index", "expense_structure_efficiency", "seasonal_stability_score",
      "plan_accuracy_rating", "cash_flow_predictability", "profitability_sustainability"
    ],
    main_formulas: [
      "planned_profit = planned_revenue - planned_expenses",
      "margin_percentage = (planned_revenue - variable_costs) / planned_revenue * 100",
      "break_even_point = fixed_costs / (1 - variable_cost_ratio)",
      "roi_planned = planned_profit / invested_capital * 100",
      "expense_ratio = planned_expenses / planned_revenue * 100",
      "growth_rate = (current_period - previous_period) / previous_period * 100"
    ]
  },

  // Инструмент 12 - Калькулятор финансового рычага
  "financial_leverage": {
    title: "Калькулятор финансового рычага",
    description: "Анализ эффективности использования заемного капитала и расчет финансового рычага",
    category: "leverage_analysis",
    auto_calculated_fields: [
      "financial_leverage_ratio", "debt_to_equity_ratio", "interest_coverage_ratio",
      "debt_service_coverage", "leverage_effect", "optimal_capital_structure"
    ],
    manual_input_fields: [
      "total_assets", "equity_capital", "debt_capital", "interest_expenses",
      "ebit", "tax_rate", "cost_of_debt", "cost_of_equity", "industry_benchmarks"
    ],
    editable_calculation_fields: [
      "target_debt_ratio", "maximum_leverage_ratio", "minimum_interest_coverage",
      "risk_premium_adjustment", "growth_financing_needs", "liquidity_buffer_percentage"
    ],
    key_metrics: [
      "leverage_efficiency_score", "financial_risk_rating", "capital_structure_optimality",
      "debt_capacity_utilization", "leverage_impact_on_roe", "financial_flexibility_index"
    ],
    main_formulas: [
      "financial_leverage = total_assets / equity_capital",
      "debt_to_equity = debt_capital / equity_capital", 
      "interest_coverage = ebit / interest_expenses",
      "roe_leveraged = roe_unleveraged + (roe_unleveraged - cost_of_debt) * (debt / equity) * (1 - tax_rate)",
      "degree_of_financial_leverage = ebit / (ebit - interest_expenses)",
      "wacc = (equity / total_capital) * cost_of_equity + (debt / total_capital) * cost_of_debt * (1 - tax_rate)"
    ]
  },

  // Инструмент 13 - Калькулятор себестоимости услуг
  "service_costing": {
    title: "Калькулятор себестоимости услуг",
    description: "Детальный расчет себестоимости услуг с учетом всех видов затрат",
    category: "cost_accounting",
    auto_calculated_fields: [
      "direct_costs_per_service", "indirect_costs_allocation", "full_service_cost",
      "cost_structure_analysis", "unit_profitability", "break_even_service_volume"
    ],
    manual_input_fields: [
      "service_categories", "direct_labor_costs", "direct_material_costs", "indirect_overhead_costs",
      "service_volumes", "allocation_basis", "administrative_expenses", "commercial_expenses", "depreciation_expenses"
    ],
    editable_calculation_fields: [
      "overhead_allocation_method", "labor_efficiency_factor", "capacity_utilization_rate",
      "quality_cost_factor", "learning_curve_effect", "indirect_cost_inflation"
    ],
    key_metrics: [
      "cost_competitiveness_index", "service_margin_analysis", "cost_structure_efficiency",
      "indirect_cost_ratio", "labor_productivity_ratio", "cost_reduction_potential"
    ],
    main_formulas: [
      "unit_cost = (direct_costs + allocated_indirect_costs) / service_volume",
      "indirect_allocation = total_indirect_costs * (service_volume / total_volume)",
      "margin_per_service = service_price - unit_cost",
      "contribution_margin = (service_price - variable_costs) / service_price",
      "cost_variance = actual_cost - standard_cost",
      "efficiency_ratio = standard_hours / actual_hours"
    ]
  },

  // Инструмент 14 - Зарплатная ведомость
  "payroll_analysis": {
    title: "Зарплатная ведомость",
    description: "Управление фондом оплаты труда и анализ кадровых затрат",
    category: "payroll_management",
    auto_calculated_fields: [
      "total_payroll_fund", "social_contributions", "payroll_taxes",
      "labor_cost_per_employee", "payroll_efficiency_metrics", "budget_variance_analysis"
    ],
    manual_input_fields: [
      "employee_data", "salary_scales", "bonuses_and_incentives", "social_benefits",
      "working_hours_data", "department_allocation", "tax_rates", "social_contribution_rates", "overtime_rates"
    ],
    editable_calculation_fields: [
      "average_salary_growth_rate", "social_contribution_rate", "income_tax_rate",
      "productivity_bonus_rate", "annual_bonus_provision", "vacation_provision_rate"
    ],
    key_metrics: [
      "payroll_cost_ratio", "labor_productivity_index", "average_compensation_level",
      "payroll_budget_accuracy", "employee_cost_efficiency", "compensation_competitiveness"
    ],
    main_formulas: [
      "gross_payroll = base_salary + bonuses + overtime + benefits",
      "social_contributions = gross_payroll * social_contribution_rate",
      "net_salary = gross_salary - income_tax - employee_contributions",
      "total_labor_cost = gross_payroll + employer_contributions + other_benefits",
      "labor_cost_per_revenue = total_labor_cost / total_revenue * 100",
      "productivity_index = revenue_per_employee / labor_cost_per_employee"
    ]
  },

  // Инструмент 15 - Учет логистики
  "logistics_analysis": {
    title: "Учет логистики",
    description: "Учет и анализ логистических затрат, оптимизация транспортных расходов",
    category: "logistics_accounting",
    auto_calculated_fields: [
      "total_logistics_costs", "cost_per_delivery", "warehouse_cost_per_unit",
      "transportation_efficiency", "logistics_cost_ratio", "delivery_performance_metrics"
    ],
    manual_input_fields: [
      "transportation_costs", "warehouse_costs", "packaging_costs", "delivery_volumes",
      "route_data", "fuel_costs", "driver_costs", "vehicle_maintenance", "insurance_costs"
    ],
    editable_calculation_fields: [
      "fuel_price_assumption", "vehicle_utilization_rate", "warehouse_efficiency_target",
      "delivery_time_standard", "cost_per_km_target", "seasonal_demand_factor"
    ],
    key_metrics: [
      "logistics_roi", "delivery_accuracy_rate", "transportation_cost_optimization",
      "warehouse_productivity", "route_efficiency_index", "customer_delivery_satisfaction"
    ],
    main_formulas: [
      "cost_per_delivery = total_logistics_costs / number_of_deliveries",
      "transportation_cost_per_unit = transportation_costs / units_delivered",
      "warehouse_cost_per_unit = warehouse_costs / units_stored",
      "fuel_efficiency = distance_traveled / fuel_consumed",
      "delivery_cost_ratio = logistics_costs / total_revenue * 100",
      "route_optimization_savings = baseline_cost - optimized_cost"
    ]
  },

  // Инструмент 16 - Анализ дебиторской задолженности
  "receivables_analysis": {
    title: "Анализ дебиторской задолженности",
    description: "Управление и анализ дебиторской задолженности, оценка кредитных рисков",
    category: "receivables_management",
    auto_calculated_fields: [
      "total_receivables", "receivables_turnover_ratio", "average_collection_period",
      "overdue_receivables_amount", "bad_debt_provision", "receivables_aging_analysis"
    ],
    manual_input_fields: [
      "receivables_data", "payment_terms", "customer_credit_ratings", "historical_bad_debts",
      "collection_costs", "industry_payment_patterns", "economic_indicators", "customer_financial_data", "collateral_information"
    ],
    editable_calculation_fields: [
      "credit_policy_strictness", "bad_debt_rate_assumption", "target_collection_period",
      "credit_limit_multiplier", "early_payment_discount_rate", "collection_efficiency_target"
    ],
    key_metrics: [
      "collection_effectiveness_index", "credit_risk_score", "receivables_quality_rating",
      "cash_conversion_efficiency", "customer_payment_behavior", "credit_policy_performance"
    ],
    main_formulas: [
      "receivables_turnover = net_credit_sales / average_receivables",
      "collection_period = 365 / receivables_turnover_ratio",
      "bad_debt_ratio = bad_debts_written_off / total_credit_sales * 100",
      "receivables_to_sales = total_receivables / annual_sales * 100",
      "overdue_percentage = overdue_receivables / total_receivables * 100",
      "provision_coverage = bad_debt_provision / total_receivables * 100"
    ]
  },

  // Инструмент 17 - Анализ кредиторской задолженности
  "payables_analysis": {
    title: "Анализ кредиторской задолженности",
    description: "Управление кредиторской задолженностью и оптимизация платежной дисциплины",
    category: "payables_management",
    auto_calculated_fields: [
      "total_payables", "payables_turnover_ratio", "average_payment_period",
      "overdue_payables_amount", "working_capital_impact", "supplier_payment_analysis"
    ],
    manual_input_fields: [
      "payables_data", "supplier_terms", "payment_discounts_available", "cash_flow_projections",
      "supplier_criticality", "contract_penalties", "seasonal_payment_patterns", "supplier_financing_options", "payment_method_costs"
    ],
    editable_calculation_fields: [
      "target_payment_period", "cash_discount_threshold", "supplier_risk_tolerance",
      "payment_priority_weights", "late_payment_penalty_rate", "optimal_cash_balance_target"
    ],
    key_metrics: [
      "payment_discipline_score", "supplier_relationship_index", "cash_management_efficiency",
      "trade_credit_utilization", "payment_optimization_potential", "supplier_dependency_risk"
    ],
    main_formulas: [
      "payables_turnover = cost_of_goods_sold / average_payables",
      "payment_period = 365 / payables_turnover_ratio",
      "cash_conversion_cycle = receivables_period + inventory_period - payables_period",
      "early_payment_savings = discount_rate * payable_amount",
      "cost_of_trade_credit = (1 + discount_rate / (1 - discount_rate)) ^ (365 / payment_period) - 1",
      "payables_to_purchases = total_payables / annual_purchases * 100"
    ]
  },

  // Инструмент 18 - Анализ запасов
  "inventory_turnover": {
    title: "Анализ запасов",
    description: "Управление товарными запасами и оптимизация складских операций",
    category: "inventory_management",
    auto_calculated_fields: [
      "inventory_turnover_ratio", "days_in_inventory", "abc_classification",
      "xyz_classification", "optimal_order_quantity", "inventory_carrying_cost"
    ],
    manual_input_fields: [
      "inventory_data", "sales_history", "supplier_lead_times", "storage_costs",
      "ordering_costs", "stockout_costs", "seasonal_demand_patterns", "product_lifecycle_stage", "supplier_reliability_data"
    ],
    editable_calculation_fields: [
      "target_service_level", "carrying_cost_rate", "safety_stock_multiplier",
      "reorder_point_buffer", "obsolescence_risk_factor", "demand_variability_factor"
    ],
    key_metrics: [
      "inventory_efficiency_index", "stockout_frequency", "inventory_accuracy_rate",
      "fill_rate_performance", "inventory_investment_roi", "warehouse_utilization_rate"
    ],
    main_formulas: [
      "inventory_turnover = cost_of_goods_sold / average_inventory",
      "days_in_inventory = 365 / inventory_turnover",
      "eoq = sqrt(2 * demand * ordering_cost / carrying_cost)",
      "safety_stock = z_score * sqrt(lead_time) * demand_std_dev",
      "reorder_point = lead_time_demand + safety_stock",
      "total_inventory_cost = carrying_cost + ordering_cost + stockout_cost"
    ]
  },

  // Инструмент 19 - Анализ производительности
  "productivity_analysis": {
    title: "Анализ производительности",
    description: "Анализ производительности труда и эффективности использования ресурсов",
    category: "productivity_analysis",
    auto_calculated_fields: [
      "labor_productivity_index", "output_per_employee", "revenue_per_labor_hour",
      "efficiency_ratios", "productivity_trends", "benchmark_comparison"
    ],
    manual_input_fields: [
      "production_output_data", "labor_hours_data", "employee_count_by_period", "revenue_by_department",
      "equipment_utilization", "quality_metrics", "training_investments", "technology_upgrades", "industry_benchmarks"
    ],
    editable_calculation_fields: [
      "target_productivity_growth", "working_hours_per_year", "quality_weight_factor",
      "automation_impact_factor", "learning_curve_coefficient", "seasonal_productivity_factor"
    ],
    key_metrics: [
      "overall_productivity_score", "productivity_improvement_rate", "resource_utilization_efficiency",
      "employee_engagement_impact", "technology_productivity_gain", "competitive_productivity_position"
    ],
    main_formulas: [
      "labor_productivity = total_output / total_labor_input",
      "productivity_growth = (current_productivity / previous_productivity - 1) * 100",
      "output_per_employee = total_revenue / number_of_employees",
      "efficiency_ratio = actual_output / standard_output",
      "multifactor_productivity = output / (labor_input + capital_input + material_input)",
      "productivity_index = (current_period_productivity / base_period_productivity) * 100"
    ]
  },

  // Инструмент 20 - Бюджетное управление
  "budget_variance": {
    title: "Бюджетное управление",
    description: "Комплексная система бюджетного планирования и контроля",
    category: "budget_management",
    auto_calculated_fields: [
      "budget_variance_analysis", "budget_execution_rate", "forecast_accuracy",
      "budget_performance_index", "resource_allocation_efficiency", "cost_center_analysis"
    ],
    manual_input_fields: [
      "departmental_budgets", "actual_vs_planned_data", "budget_categories", "cost_drivers",
      "revenue_budgets", "capex_budgets", "seasonal_adjustments", "budget_assumptions", "external_factors"
    ],
    editable_calculation_fields: [
      "budget_tolerance_threshold", "forecast_horizon_months", "variance_significance_level",
      "budget_cycle_frequency", "planning_detail_level", "contingency_reserve_percentage"
    ],
    key_metrics: [
      "budget_accuracy_score", "spending_discipline_index", "budget_flexibility_rating",
      "cost_control_effectiveness", "resource_optimization_potential", "planning_process_efficiency"
    ],
    main_formulas: [
      "budget_variance = actual_amount - budgeted_amount",
      "variance_percentage = (budget_variance / budgeted_amount) * 100",
      "budget_execution_rate = actual_spending / budgeted_amount * 100",
      "forecast_accuracy = (1 - abs(forecast_error / actual_value)) * 100",
      "cost_performance_index = budgeted_cost / actual_cost",
      "resource_utilization = actual_usage / planned_usage * 100"
    ]
  },

  // Инструмент 21 - Операционный анализ
  "operational_analysis": {
    title: "Операционный анализ",
    description: "Анализ операционной эффективности и оптимизация бизнес-процессов",
    category: "operations_analysis",
    auto_calculated_fields: [
      "operational_efficiency_index", "process_performance_metrics", "bottleneck_analysis",
      "capacity_utilization_rate", "quality_performance_indicators", "operational_cost_analysis"
    ],
    manual_input_fields: [
      "process_data", "cycle_times", "resource_utilization", "quality_metrics",
      "cost_per_process", "throughput_data", "error_rates", "customer_satisfaction", "employee_productivity"
    ],
    editable_calculation_fields: [
      "target_efficiency_level", "quality_threshold", "capacity_target",
      "cost_reduction_goal", "cycle_time_benchmark", "error_tolerance_level"
    ],
    key_metrics: [
      "overall_equipment_effectiveness", "first_pass_yield", "process_capability_index",
      "customer_value_creation", "waste_elimination_potential", "continuous_improvement_impact"
    ],
    main_formulas: [
      "operational_efficiency = output / input * 100",
      "cycle_time = total_time / number_of_units",
      "capacity_utilization = actual_output / maximum_capacity * 100",
      "quality_rate = defect_free_units / total_units * 100",
      "productivity_ratio = actual_productivity / standard_productivity",
      "cost_per_unit = total_operational_cost / units_produced"
    ]
  },

  // Инструмент 22 - Анализ рентабельности
  "margin_analysis": {
    title: "Анализ рентабельности",
    description: "Комплексный анализ рентабельности деятельности компании по различным направлениям",
    category: "profitability_analysis",
    auto_calculated_fields: [
      "return_on_sales", "return_on_assets", "return_on_equity",
      "gross_profit_margin", "operating_margin", "profitability_trends"
    ],
    manual_input_fields: [
      "revenue_data", "cost_data", "profit_data", "assets_data",
      "equity_data", "segment_performance", "product_profitability", "market_conditions", "competitive_benchmarks"
    ],
    editable_calculation_fields: [
      "target_ros_rate", "target_roa_rate", "target_roe_rate",
      "industry_average_margins", "cost_optimization_potential", "revenue_growth_assumption"
    ],
    key_metrics: [
      "profitability_stability_index", "margin_improvement_potential", "competitive_profitability_position",
      "profitability_risk_score", "sustainable_growth_rate", "value_creation_efficiency"
    ],
    main_formulas: [
      "ros = net_profit / net_sales * 100",
      "roa = net_profit / average_total_assets * 100",
      "roe = net_profit / average_shareholders_equity * 100",
      "gross_margin = (revenue - cogs) / revenue * 100",
      "operating_margin = operating_profit / revenue * 100",
      "dupont_roe = (net_profit / sales) * (sales / assets) * (assets / equity)"
    ]
  },

  // Инструмент 23 - Анализ ликвидности
  "working_capital": {
    title: "Анализ ликвидности",
    description: "Анализ платежеспособности и ликвидности компании",
    category: "liquidity_analysis",
    auto_calculated_fields: [
      "current_ratio", "quick_ratio", "cash_ratio",
      "working_capital", "cash_conversion_cycle", "liquidity_risk_assessment"
    ],
    manual_input_fields: [
      "current_assets", "current_liabilities", "cash_and_equivalents", "accounts_receivable",
      "inventory", "accounts_payable", "operating_cash_flows", "credit_facilities", "seasonal_patterns"
    ],
    editable_calculation_fields: [
      "minimum_current_ratio", "target_quick_ratio", "minimum_cash_ratio",
      "liquidity_buffer_days", "collection_efficiency_target", "inventory_liquidity_factor"
    ],
    key_metrics: [
      "liquidity_adequacy_score", "cash_flow_predictability", "liquidity_efficiency_index",
      "short_term_solvency_rating", "liquidity_management_quality", "financial_flexibility_measure"
    ],
    main_formulas: [
      "current_ratio = current_assets / current_liabilities",
      "quick_ratio = (current_assets - inventory) / current_liabilities",
      "cash_ratio = cash_and_equivalents / current_liabilities",
      "working_capital = current_assets - current_liabilities",
      "cash_conversion_cycle = dso + dio - dpo",
      "operating_cash_flow_ratio = operating_cash_flow / current_liabilities"
    ]
  },

  // Инструмент 24 - Финансовое планирование
  "financial_planning": {
    title: "Финансовое планирование",
    description: "Стратегическое и операционное финансовое планирование деятельности компании",
    category: "financial_planning",
    auto_calculated_fields: [
      "financial_forecast_model", "funding_requirements", "optimal_capital_structure",
      "scenario_analysis_results", "strategic_financial_metrics", "plan_sensitivity_analysis"
    ],
    manual_input_fields: [
      "strategic_objectives", "market_assumptions", "growth_projections", "investment_plans",
      "financing_options", "cost_structure_assumptions", "regulatory_constraints", "macroeconomic_factors", "competitive_landscape"
    ],
    editable_calculation_fields: [
      "planning_horizon_years", "revenue_growth_assumption", "margin_improvement_target",
      "capex_to_revenue_ratio", "target_debt_to_equity", "dividend_payout_policy"
    ],
    key_metrics: [
      "plan_achievability_score", "financial_strategy_alignment", "funding_sustainability_rating",
      "value_creation_potential", "financial_flexibility_preservation", "stakeholder_value_optimization"
    ],
    main_formulas: [
      "projected_revenue = base_revenue * (1 + growth_rate)^years",
      "financing_need = capex + working_capital_increase - operating_cash_flow",
      "sustainable_growth_rate = roe * (1 - dividend_payout_ratio)",
      "wacc = (debt_ratio * cost_of_debt * (1 - tax_rate)) + (equity_ratio * cost_of_equity)",
      "enterprise_value = sum(fcf_t / (1 + wacc)^t) + terminal_value",
      "debt_service_coverage = operating_cash_flow / debt_service"
    ]
  },

  // Инструмент 25 - Консолидированный отчет
  "consolidated_reporting": {
    title: "Консолидированный отчет",
    description: "Формирование консолидированной отчетности и управленческих отчетов",
    category: "consolidated_reporting",
    auto_calculated_fields: [
      "consolidated_revenue", "consolidated_profit", "consolidated_assets",
      "minority_interest", "intercompany_eliminations", "segment_performance_metrics"
    ],
    manual_input_fields: [
      "subsidiary_financials", "ownership_percentages", "intercompany_transactions", "currency_exchange_rates",
      "accounting_policy_differences", "segment_allocation_rules", "consolidation_adjustments", "goodwill_and_intangibles", "joint_ventures_data"
    ],
    editable_calculation_fields: [
      "consolidation_threshold", "functional_currency", "translation_method",
      "goodwill_impairment_test", "segment_reporting_threshold", "materiality_threshold"
    ],
    key_metrics: [
      "consolidation_quality_index", "reporting_timeliness_score", "segment_performance_variance",
      "intercompany_elimination_accuracy", "currency_impact_magnitude", "stakeholder_information_value"
    ],
    main_formulas: [
      "consolidated_revenue = sum(subsidiary_revenues) - intercompany_sales",
      "minority_interest = (subsidiary_equity * minority_percentage)",
      "goodwill = purchase_price - fair_value_net_assets",
      "currency_translation_adjustment = sum((assets - liabilities) * exchange_rate_change)",
      "segment_profit_margin = segment_profit / segment_revenue * 100",
      "return_on_invested_capital = nopat / invested_capital"
    ]
  }
};

export default function InstrumentSpecificFields({ 
  instrumentKey, 
  periodId,
  onDataUpdate 
}: InstrumentSpecificFieldsProps) {
  const instrumentConfig = INSTRUMENTS_CONFIG[instrumentKey];
  
  // State for storing all input data
  const [inputData, setInputData] = useState<Record<string, any>>({});
  const [settingsData, setSettingsData] = useState<Record<string, any>>({});
  
  // Initialize data when instrument changes
  useEffect(() => {
    if (instrumentConfig) {
      const initialInputData: Record<string, any> = {};
      const initialSettingsData: Record<string, any> = {};
      
      // Initialize manual input fields
      instrumentConfig.manual_input_fields.forEach(field => {
        initialInputData[field] = '';
      });
      
      // Initialize editable calculation fields
      instrumentConfig.editable_calculation_fields.forEach(field => {
        initialSettingsData[field] = '';
      });
      
      setInputData(initialInputData);
      setSettingsData(initialSettingsData);
      
      // Notify parent component of initial data
      if (onDataUpdate) {
        onDataUpdate({
          instrumentKey,
          periodId,
          inputData: initialInputData,
          settingsData: initialSettingsData,
          timestamp: new Date().toISOString()
        });
      }
    }
  }, [instrumentKey, periodId, instrumentConfig, onDataUpdate]);

  // Handler for manual input changes
  const handleInputChange = (fieldName: string, value: any) => {
    const newInputData = { ...inputData, [fieldName]: value };
    setInputData(newInputData);
    
    if (onDataUpdate) {
      onDataUpdate({
        instrumentKey,
        periodId,
        inputData: newInputData,
        settingsData,
        timestamp: new Date().toISOString()
      });
    }
  };

  // Handler for settings changes
  const handleSettingsChange = (fieldName: string, value: any) => {
    const newSettingsData = { ...settingsData, [fieldName]: value };
    setSettingsData(newSettingsData);
    
    if (onDataUpdate) {
      onDataUpdate({
        instrumentKey,
        periodId,
        inputData,
        settingsData: newSettingsData,
        timestamp: new Date().toISOString()
      });
    }
  };

  // Reset all data
  const handleResetData = () => {
    const resetInputData: Record<string, any> = {};
    const resetSettingsData: Record<string, any> = {};
    
    instrumentConfig.manual_input_fields.forEach(field => {
      resetInputData[field] = '';
    });
    
    instrumentConfig.editable_calculation_fields.forEach(field => {
      resetSettingsData[field] = '';
    });
    
    setInputData(resetInputData);
    setSettingsData(resetSettingsData);
    
    if (onDataUpdate) {
      onDataUpdate({
        instrumentKey,
        periodId,
        inputData: resetInputData,
        settingsData: resetSettingsData,
        timestamp: new Date().toISOString()
      });
    }
  };
  
  if (!instrumentConfig) {
    return (
      <Card data-testid={`card-instrument-not-found-${instrumentKey}`}>
        <CardContent className="p-6">
          <div className="text-center text-muted-foreground">
            <Calculator className="h-8 w-8 mx-auto mb-2 opacity-50" data-testid="icon-calculator-not-found" />
            <p data-testid="text-instrument-not-found">Конфигурация для инструмента "{instrumentKey}" не найдена</p>
            <p className="text-sm mt-1" data-testid="text-instrument-update-info">Базовая конфигурация будет добавлена в ближайшем обновлении</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Словарь переводов полей на русский язык
  const FIELD_TRANSLATIONS: Record<string, string> = {
    // Финансовое здоровье - Financial Health
    "current_assets": "Оборотные активы",
    "current_liabilities": "Краткосрочные обязательства", 
    "total_assets": "Общие активы",
    "total_equity": "Собственный капитал",
    "annual_revenue": "Годовая выручка",
    "net_profit": "Чистая прибыль",
    "debt_amount": "Сумма долга",
    "cash_reserves": "Денежные резервы",
    "financial_stability_index": "Индекс финансовой стабильности",
    "overall_health_score": "Общий балл здоровья",
    "risk_assessment": "Оценка рисков",
    "solvency_indicators": "Показатели платежеспособности",
    "liquidity_ratios": "Коэффициенты ликвидности",
    "profitability_metrics": "Показатели прибыльности",
    "risk_tolerance_level": "Уровень толерантности к рискам",
    "benchmark_industry": "Отраслевой бенчмарк",
    "health_score_weights": "Веса оценки здоровья",
    "critical_ratios_thresholds": "Пороги критических коэффициентов",
    "analysis_period": "Период анализа",
    "financial_strength_rating": "Рейтинг финансовой устойчивости",
    "bankruptcy_risk_score": "Балл риска банкротства",
    "investment_attractiveness": "Инвестиционная привлекательность",
    "credit_worthiness": "Кредитоспособность",
    "operational_efficiency": "Операционная эффективность",
    "growth_sustainability": "Устойчивость роста",

    // Анализ прибыльности - Profitability Analysis
    "revenue": "Выручка",
    "cost_of_goods_sold": "Себестоимость проданных товаров",
    "operating_expenses": "Операционные расходы",
    "interest_expenses": "Процентные расходы",
    "tax_expenses": "Налоговые расходы",
    "shareholders_equity": "Акционерный капитал",
    "gross_margin": "Валовая маржа",
    "operating_margin": "Операционная маржа",
    "net_margin": "Чистая маржа",
    "roi": "Рентабельность инвестиций (ROI)",
    "roe": "Рентабельность собственного капитала (ROE)",
    "roa": "Рентабельность активов (ROA)",
    "target_margin": "Целевая маржа",
    "industry_benchmark": "Отраслевой бенчмарк",
    "analysis_depth": "Глубина анализа",
    "comparison_period": "Период сравнения",
    "profitability_index": "Индекс прибыльности",
    "margin_stability": "Стабильность маржи",
    "cost_efficiency": "Эффективность затрат",
    "revenue_quality": "Качество выручки",

    // Коэффициенты ликвидности - Liquidity Ratios  
    "cash_and_equivalents": "Денежные средства и эквиваленты",
    "marketable_securities": "Рыночные ценные бумаги",
    "accounts_receivable": "Дебиторская задолженность",
    "inventory": "Запасы",
    "short_term_debt": "Краткосрочная задолженность",
    "current_ratio": "Коэффициент текущей ликвидности",
    "quick_ratio": "Коэффициент быстрой ликвидности",
    "cash_ratio": "Коэффициент абсолютной ликвидности",
    "working_capital": "Оборотный капитал",
    "liquidity_index": "Индекс ликвидности",
    "cash_conversion_cycle": "Цикл конверсии денежных средств",
    "minimum_liquidity_threshold": "Минимальный порог ликвидности",
    "optimal_cash_balance": "Оптимальный денежный баланс",
    "seasonal_adjustments": "Сезонные корректировки",
    "emergency_fund_percentage": "Процент резервного фонда",
    "liquidity_strength": "Сила ликвидности",
    "cash_management_efficiency": "Эффективность управления денежными средствами",
    "working_capital_optimization": "Оптимизация оборотного капитала",
    "short_term_solvency": "Краткосрочная платежеспособность",

    // Коэффициенты эффективности - Efficiency Ratios
    "total_revenue": "Общая выручка",
    "average_total_assets": "Средние общие активы",
    "average_inventory": "Средние запасы",
    "average_receivables": "Средняя дебиторская задолженность",
    "average_payables": "Средняя кредиторская задолженность",
    "asset_turnover": "Оборачиваемость активов",
    "inventory_turnover": "Оборачиваемость запасов",
    "receivables_turnover": "Оборачиваемость дебиторской задолженности",
    "payables_turnover": "Оборачиваемость кредиторской задолженности",
    "total_asset_efficiency": "Эффективность общих активов",
    "target_turnover_ratios": "Целевые коэффициенты оборачиваемости",
    "industry_benchmarks": "Отраслевые бенчмарки",
    "seasonal_factors": "Сезонные факторы",
    "efficiency_improvement_goals": "Цели повышения эффективности",
    "asset_utilization_score": "Балл использования активов",
    "operational_productivity": "Операционная производительность",
    "resource_efficiency": "Эффективность ресурсов",
    "business_cycle_optimization": "Оптимизация бизнес-цикла",

    // Анализ денежных потоков - Cash Flow Analysis
    "cash_from_operations": "Денежные средства от операций",
    "capital_expenditures": "Капитальные расходы",
    "debt_payments": "Выплаты по долгам",
    "dividend_payments": "Выплаты дивидендов",
    "cash_from_financing": "Денежные средства от финансирования",
    "beginning_cash_balance": "Начальный денежный баланс",
    "operating_cash_flow": "Операционный денежный поток",
    "investing_cash_flow": "Инвестиционный денежный поток",
    "financing_cash_flow": "Финансовый денежный поток",
    "free_cash_flow": "Свободный денежный поток",
    "cash_flow_margin": "Маржа денежного потока",
    "cash_flow_coverage_ratio": "Коэффициент покрытия денежного потока",
    "cash_flow_forecast_period": "Период прогноза денежного потока",
    "growth_capex_ratio": "Соотношение роста и капитальных вложений",
    "dividend_policy": "Дивидендная политика",
    "debt_service_requirements": "Требования по обслуживанию долга",
    "cash_generation_quality": "Качество генерации денежных средств",
    "cash_flow_predictability": "Предсказуемость денежного потока",
    "liquidity_sustainability": "Устойчивость ликвидности",
    "investment_self_financing_ability": "Способность к самофинансированию инвестиций",

    // Отчет отдела продаж - Sales Report
    "sales_data_by_manager": "Данные продаж по менеджерам",
    "leads_data": "Данные по лидам",
    "deals_pipeline": "Воронка сделок",
    "sales_targets": "Цели продаж",
    "product_categories": "Категории продуктов",
    "sales_channels": "Каналы продаж",
    "customer_segments": "Сегменты клиентов",
    "time_period_start": "Начало периода",
    "time_period_end": "Конец периода",
    "total_sales_revenue": "Общая выручка от продаж",
    "average_deal_size": "Средний размер сделки",
    "conversion_rate": "Коэффициент конверсии",
    "sales_cycle_length": "Длительность цикла продаж",
    "manager_performance_ranking": "Рейтинг эффективности менеджеров",
    "sales_trend_analysis": "Анализ трендов продаж",
    "target_conversion_rate": "Целевой коэффициент конверсии",
    "minimum_deal_size": "Минимальный размер сделки",
    "sales_cycle_benchmark": "Бенчмарк цикла продаж",
    "performance_weight_revenue": "Вес выручки в эффективности",
    "performance_weight_deals": "Вес сделок в эффективности",
    "seasonality_factor": "Фактор сезонности",
    "monthly_sales_growth": "Месячный рост продаж",
    "plan_achievement_percentage": "Процент выполнения плана",
    "customer_acquisition_cost": "Стоимость привлечения клиента",
    "revenue_per_lead": "Выручка с лида",
    "top_performing_managers": "Лучшие менеджеры",
    "underperforming_segments": "Неэффективные сегменты",

    // Факторы продаж - Sales Factors
    "market_conditions": "Рыночные условия",
    "competition_level": "Уровень конкуренции",
    "market_seasonal_factors": "Сезонные факторы рынка",
    "price_sensitivity": "Чувствительность к цене",
    "customer_loyalty": "Лояльность клиентов",
    "brand_recognition": "Узнаваемость бренда",
    "sales_team_experience": "Опыт команды продаж",
    "lead_quality": "Качество лидов",
    "market_penetration": "Проникновение на рынок",
    "competitive_advantage": "Конкурентное преимущество",
    "customer_satisfaction": "Удовлетворенность клиентов",
    "sales_process_efficiency": "Эффективность процесса продаж",

    // Отчет маркетингу - Marketing Report  
    "marketing_budget": "Бюджет маркетинга",
    "campaign_performance": "Эффективность кампаний",
    "lead_generation_cost": "Стоимость генерации лидов",
    "brand_awareness": "Узнаваемость бренда",
    "customer_lifetime_value": "Пожизненная ценность клиента",
    "return_on_marketing_investment": "Возврат инвестиций в маркетинг",
    "digital_marketing_roi": "ROI цифрового маркетинга",
    "social_media_engagement": "Вовлеченность в соцсетях",
    "website_traffic": "Трафик сайта",
    "email_marketing_effectiveness": "Эффективность email-маркетинга",
    "content_marketing_performance": "Эффективность контент-маркетинга",
    "advertising_spend": "Расходы на рекламу",

    // Юнит-экономика маркетплейсы - Marketplace Economics
    "gross_merchandise_value": "Валовая стоимость товаров",
    "take_rate": "Комиссия маркетплейса",
    "average_order_value": "Средний чек заказа",
    "marketplace_customer_acquisition_cost": "Стоимость привлечения клиента на маркетплейсе",
    "marketplace_customer_lifetime_value": "Пожизненная ценность клиента маркетплейса",
    "unit_contribution_margin": "Маржинальный вклад на единицу",
    "payback_period": "Период окупаемости",
    "monthly_active_users": "Месячная активная аудитория",
    "retention_rate": "Коэффициент удержания",
    "churn_rate": "Коэффициент оттока",
    "repeat_purchase_rate": "Коэффициент повторных покупок",
    "net_revenue_retention": "Чистое удержание выручки",

    // Финмодель маркетплейсы - Marketplace Financial Model
    "platform_revenue": "Выручка платформы",
    "commission_revenue": "Комиссионная выручка",
    "subscription_revenue": "Выручка от подписок",
    "advertising_revenue": "Рекламная выручка",
    "fulfillment_costs": "Расходы на выполнение",
    "technology_costs": "Технологические расходы", 
    "marketing_costs": "Маркетинговые расходы",
    "customer_support_costs": "Расходы на поддержку клиентов",
    "payment_processing_costs": "Расходы на обработку платежей",
    "net_marketplace_margin": "Чистая маржа маркетплейса",
    "operating_leverage": "Операционный рычаг",
    "scalability_metrics": "Показатели масштабируемости",

    // План доходов-расходов - Budget Planning
    "planned_revenue": "Планируемая выручка",
    "planned_expenses": "Планируемые расходы",
    "budget_variance": "Отклонение от бюджета",
    "forecast_accuracy": "Точность прогноза",
    "expense_categories": "Категории расходов",
    "revenue_streams": "Потоки доходов",
    "cost_centers": "Центры затрат",
    "budget_allocation": "Распределение бюджета",
    "spending_patterns": "Паттерны расходов",
    "budget_control_measures": "Меры контроля бюджета",
    "variance_analysis": "Анализ отклонений",
    "budget_optimization": "Оптимизация бюджета",

    // Калькулятор финансового рычага - Financial Leverage
    "financial_leverage_ratio": "Коэффициент финансового рычага",
    "debt_to_equity_ratio": "Соотношение долга к капиталу",
    "times_interest_earned": "Покрытие процентов прибылью",
    "degree_of_financial_leverage": "Степень финансового рычага",
    "interest_coverage_ratio": "Коэффициент покрытия процентов",
    "debt_service_coverage": "Покрытие обслуживания долга",
    "leverage_effect": "Эффект левериджа",
    "optimal_capital_structure": "Оптимальная структура капитала",
    "financial_risk_assessment": "Оценка финансового риска",
    "cost_of_capital": "Стоимость капитала",
    "leverage_optimization": "Оптимизация левериджа",
    "capital_adequacy": "Достаточность капитала",

    // Калькулятор себестоимости услуг - Service Costing
    "direct_labor_costs": "Прямые затраты на рабочую силу",
    "indirect_costs": "Косвенные затраты",
    "material_costs": "Затраты на материалы",
    "overhead_costs": "Накладные расходы",
    "service_hours": "Часы предоставления услуг",
    "hourly_rate": "Почасовая ставка",
    "cost_per_service": "Стоимость услуги",
    "profit_margin_target": "Целевая маржа прибыли",
    "pricing_strategy": "Стратегия ценообразования",
    "cost_allocation_method": "Метод распределения затрат",
    "service_profitability": "Прибыльность услуги",
    "break_even_point": "Точка безубыточности",

    // Зарплатная ведомость - Payroll Analysis
    "gross_salary": "Валовая зарплата",
    "net_salary": "Чистая зарплата",
    "tax_deductions": "Налоговые вычеты",
    "social_contributions": "Социальные взносы",
    "overtime_pay": "Оплата сверхурочных",
    "bonus_payments": "Премиальные выплаты",
    "payroll_tax": "Налог на фонд оплаты труда",
    "employee_benefits": "Льготы сотрудников",
    "payroll_costs": "Расходы на зарплату",
    "average_salary": "Средняя зарплата",
    "salary_progression": "Прогрессия зарплаты",
    "compensation_analysis": "Анализ компенсации",

    // Учет логистики - Logistics Analysis
    "transportation_costs": "Транспортные расходы",
    "warehousing_costs": "Складские расходы",
    "inventory_holding_costs": "Затраты на хранение запасов",
    "order_fulfillment_time": "Время выполнения заказа",
    "delivery_performance": "Эффективность доставки",
    "logistics_kpi": "KPI логистики",
    "supply_chain_efficiency": "Эффективность цепи поставок",
    "distribution_costs": "Расходы на распределение",
    "logistics_optimization": "Оптимизация логистики",
    "carrier_performance": "Производительность перевозчиков",
    "route_optimization": "Оптимизация маршрутов",
    "cost_per_shipment": "Стоимость отгрузки",

    // Анализ дебиторской задолженности - Receivables Analysis
    "accounts_receivable_balance": "Баланс дебиторской задолженности",
    "days_sales_outstanding": "Дни продаж в долге",
    "collection_period": "Период сбора",
    "bad_debt_provision": "Резерв по безнадежным долгам",
    "receivables_turnover_analysis": "Анализ оборачиваемости дебиторской задолженности",
    "aging_analysis": "Анализ старения",
    "credit_risk_assessment": "Оценка кредитного риска",
    "collection_efficiency": "Эффективность сбора",
    "customer_payment_patterns": "Паттерны платежей клиентов",
    "receivables_management": "Управление дебиторской задолженностью",
    "write_off_rate": "Коэффициент списаний",
    "recovery_rate": "Коэффициент возврата",

    // Анализ кредиторской задолженности - Payables Analysis
    "accounts_payable_balance": "Баланс кредиторской задолженности",
    "days_payable_outstanding": "Дни кредиторской задолженности",
    "payment_terms": "Условия оплаты",
    "early_payment_discounts": "Скидки за досрочную оплату",
    "supplier_payment_patterns": "Паттерны платежей поставщикам",
    "cash_flow_optimization": "Оптимизация денежного потока",
    "vendor_relationship_management": "Управление отношениями с поставщиками",
    "payment_schedule": "График платежей",
    "working_capital_management": "Управление оборотным капиталом",
    "payables_efficiency": "Эффективность кредиторской задолженности",
    "supplier_performance": "Производительность поставщика",
    "payment_automation": "Автоматизация платежей",

    // Анализ производительности - Productivity Analysis
    "labor_productivity": "Производительность труда",
    "output_per_hour": "Выпуск в час",
    "efficiency_ratio": "Коэффициент эффективности",
    "capacity_utilization": "Использование мощностей",
    "productivity_trends": "Тренды производительности",
    "performance_benchmarks": "Бенчмарки производительности",
    "resource_utilization": "Использование ресурсов",
    "quality_metrics": "Показатели качества",
    "downtime_analysis": "Анализ простоев",
    "productivity_improvement": "Улучшение производительности",
    "automation_impact": "Влияние автоматизации",
    "employee_performance": "Производительность сотрудников",

    // Бюджетное управление - Budget Management
    "budget_planning": "Планирование бюджета",
    "budget_execution": "Исполнение бюджета",
    "budget_monitoring": "Мониторинг бюджета",
    "cost_control": "Контроль затрат",
    "budget_adjustments": "Корректировки бюджета",
    "performance_budgeting": "Бюджетирование по результатам",
    "zero_based_budgeting": "Бюджетирование с нуля",
    "rolling_forecasts": "Скользящие прогнозы",
    "budget_accountability": "Ответственность по бюджету",
    "resource_allocation": "Распределение ресурсов",
    "budget_transparency": "Прозрачность бюджета",
    "fiscal_discipline": "Фискальная дисциплина",

    // Операционный анализ - Operational Analysis
    "operational_metrics": "Операционные показатели",
    "process_efficiency": "Эффективность процессов",
    "cycle_time": "Время цикла",
    "throughput": "Пропускная способность",
    "quality_control": "Контроль качества",
    "operational_costs": "Операционные расходы",
    "process_optimization": "Оптимизация процессов",
    "operational_excellence": "Операционное совершенство",
    "continuous_improvement": "Непрерывное улучшение",
    "lean_operations": "Бережливые операции",
    "six_sigma": "Шесть сигм",
    "operational_kpi": "KPI операций",

    // Анализ рентабельности - Margin Analysis  
    "gross_profit_margin": "Валовая маржа прибыли",
    "operating_profit_margin": "Операционная маржа прибыли", 
    "net_profit_margin": "Чистая маржа прибыли",
    "ebitda_margin": "EBITDA маржа",
    "contribution_margin": "Маржинальный вклад",
    "segment_profitability": "Рентабельность сегмента",
    "product_line_margins": "Маржи продуктовых линий",
    "customer_profitability": "Рентабельность клиента",
    "margin_analysis": "Анализ маржинальности",
    "profit_optimization": "Оптимизация прибыли",
    "margin_improvement": "Улучшение маржи",
    "profitability_drivers": "Драйверы рентабельности",

    // Анализ ликвидности - Working Capital
    "net_working_capital": "Чистый оборотный капитал",
    "working_capital_ratio": "Коэффициент оборотного капитала",
    "working_capital_turnover": "Оборачиваемость оборотного капитала",
    "working_capital_cash_cycle": "Денежный цикл оборотного капитала",
    "inventory_days": "Дни запасов",
    "receivables_days": "Дни дебиторской задолженности",
    "payables_days": "Дни кредиторской задолженности",
    "working_capital_management_strategy": "Стратегия управления оборотным капиталом",
    "liquidity_position": "Позиция ликвидности",
    "short_term_financing": "Краткосрочное финансирование",
    "capital_optimization_strategy": "Стратегия оптимизации капитала",
    "cash_management": "Управление денежными средствами",

    // Финансовое планирование - Financial Planning
    "financial_goals": "Финансовые цели",
    "strategic_planning": "Стратегическое планирование",
    "financial_forecasting": "Финансовое прогнозирование",
    "scenario_analysis": "Сценарный анализ",
    "sensitivity_analysis": "Анализ чувствительности",
    "capital_planning": "Планирование капитала",
    "investment_planning": "Планирование инвестиций",
    "risk_management": "Управление рисками",
    "financial_modeling": "Финансовое моделирование",
    "long_term_planning": "Долгосрочное планирование",
    "financial_strategy": "Финансовая стратегия",
    "performance_measurement": "Измерение производительности",

    // Консолидированный отчет - Consolidated Reporting
    "consolidated_revenue": "Консолидированная выручка",
    "consolidated_expenses": "Консолидированные расходы",
    "intercompany_eliminations": "Исключения внутригрупповых операций",
    "subsidiary_performance": "Производительность дочерних компаний",
    "group_financial_position": "Финансовое положение группы",
    "consolidation_adjustments": "Корректировки консолидации",
    "minority_interests": "Доли миноритариев",
    "goodwill_impairment": "Обесценение гудвилла",
    "translation_differences": "Курсовые разности",
    "segment_reporting": "Сегментная отчетность",
    "consolidated_kpi": "KPI консолидации",
    "group_performance_metrics": "Показатели эффективности группы",

    // Дополнительные поля анализа кредиторской задолженности - Missing Payables Analysis Fields  
    "payables_data": "Данные кредиторской задолженности",
    "supplier_terms": "Условия поставщиков", 
    "payment_discounts_available": "Доступные скидки за оплату",
    "cash_flow_projections": "Прогнозы денежных потоков",
    "supplier_criticality": "Критичность поставщиков",
    "contract_penalties": "Штрафы по контрактам", 
    "seasonal_payment_patterns": "Сезонные платежные паттерны",
    "supplier_financing_options": "Опции финансирования поставщиков",
    "payment_method_costs": "Стоимость способов оплаты",

    // Дополнительные поля дебиторской задолженности - Missing Receivables Analysis Fields
    "receivables_data": "Данные дебиторской задолженности",
    "customer_credit_ratings": "Кредитные рейтинги клиентов",
    "historical_bad_debts": "Исторические безнадежные долги",
    "collection_costs": "Затраты на взыскание",
    "industry_payment_patterns": "Отраслевые платежные паттерны", 
    "economic_indicators": "Экономические индикаторы",
    "customer_financial_data": "Финансовые данные клиентов",
    "collateral_information": "Информация о залогах",

    // Дополнительные поля анализа запасов - Missing Inventory Fields  
    "inventory_data": "Данные по запасам",
    "sales_history": "История продаж",
    "supplier_lead_times": "Время поставки поставщиков",
    "storage_costs": "Затраты на хранение",
    "ordering_costs": "Затраты на заказ", 
    "stockout_costs": "Затраты от дефицита запасов",
    "seasonal_demand_patterns": "Сезонные паттерны спроса",
    "product_lifecycle_stage": "Стадия жизненного цикла продукта",
    "supplier_reliability_data": "Данные о надежности поставщиков",

    // Прочие пропущенные поля - Other Missing Fields
    "monthly_sales_forecast": "Месячный прогноз продаж",
    "product_portfolio": "Портфель продуктов",  
    "inventory_levels": "Уровни запасов",
    "marketplace_growth_rates": "Темпы роста маркетплейса",
    "seasonal_patterns": "Сезонные паттерны",
    "investment_requirements": "Инвестиционные требования",
    "funding_sources": "Источники финансирования",
    "cost_structure_data": "Данные структуры затрат"
  };

  const formatFieldName = (fieldName: string) => {
    // Если есть перевод, используем русское название
    if (FIELD_TRANSLATIONS[fieldName]) {
      return FIELD_TRANSLATIONS[fieldName];
    }
    
    // Если перевода нет, используем стандартное форматирование
    return fieldName
      .replace(/_/g, ' ')
      .replace(/\b\w/g, l => l.toUpperCase())
      .replace(/Id/g, 'ID')
      .replace(/Roi/g, 'ROI')
      .replace(/Roa/g, 'ROA')
      .replace(/Roe/g, 'ROE');
  };

  // Функция для получения английского названия поля
  const getFieldEnglishName = (fieldName: string) => {
    return fieldName
      .replace(/_/g, ' ')
      .replace(/\b\w/g, l => l.toUpperCase())
      .replace(/Id/g, 'ID')
      .replace(/Roi/g, 'ROI')
      .replace(/Roa/g, 'ROA')
      .replace(/Roe/g, 'ROE');
  };

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      'financial_analysis': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
      'profitability': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
      'liquidity_analysis': 'bg-cyan-100 text-cyan-800 dark:bg-cyan-900 dark:text-cyan-300',
      'efficiency_analysis': 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300',
      'cash_flow': 'bg-teal-100 text-teal-800 dark:bg-teal-900 dark:text-teal-300',
      'cost_analysis': 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300'
    };
    return colors[category] || 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300';
  };

  return (
    <Card data-testid={`card-instrument-${instrumentKey}`}>
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-primary/10 rounded-lg">
              <BarChart3 className="h-5 w-5 text-primary" />
            </div>
            <div>
              <CardTitle className="text-lg">{instrumentConfig.title}</CardTitle>
              <p className="text-sm text-muted-foreground mt-1">
                {instrumentConfig.description}
              </p>
            </div>
          </div>
          <Badge className={getCategoryColor(instrumentConfig.category)}>
            {formatFieldName(instrumentConfig.category)}
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="p-0">
        <Tabs defaultValue="input" className="w-full">
          <TabsList className="grid w-full grid-cols-4 mx-6 mb-4">
            <TabsTrigger value="input" data-testid="tab-manual-input">
              <Edit3 className="h-4 w-4 mr-1" />
              Ввод данных
            </TabsTrigger>
            <TabsTrigger value="calculated" data-testid="tab-calculated">
              <Calculator className="h-4 w-4 mr-1" />
              Расчеты
            </TabsTrigger>
            <TabsTrigger value="metrics" data-testid="tab-metrics">
              <TrendingUp className="h-4 w-4 mr-1" />
              Метрики
            </TabsTrigger>
            <TabsTrigger value="settings" data-testid="tab-settings">
              <Settings className="h-4 w-4 mr-1" />
              Настройки
            </TabsTrigger>
          </TabsList>

          {/* Ручной ввод данных */}
          <TabsContent value="input" className="px-6 pb-6">
            <div className="space-y-4">
              <h4 className="text-sm font-medium flex items-center gap-2" data-testid="heading-manual-input">
                <Edit3 className="h-4 w-4" data-testid="icon-manual-input" />
                Поля для ручного ввода
              </h4>
              <div className="grid gap-4 md:grid-cols-2">
                {instrumentConfig.manual_input_fields.map((field, index) => (
                  <div key={field} className="space-y-2" data-testid={`field-group-${field}`}>
                    <Label htmlFor={`input-${field}`} className="text-sm" data-testid={`label-${field}`}>
                      <div className="flex flex-col">
                        <span className="font-medium text-foreground">{formatFieldName(field)}</span>
                        <span className="text-xs text-muted-foreground font-normal">{getFieldEnglishName(field)}</span>
                      </div>
                    </Label>
                    <Input
                      id={`input-${field}`}
                      value={inputData[field] || ''}
                      onChange={(e) => handleInputChange(field, e.target.value)}
                      placeholder={`Введите ${formatFieldName(field).toLowerCase()}`}
                      data-testid={`input-${field}`}
                      className="h-9"
                    />
                  </div>
                ))}
              </div>
              {instrumentConfig.manual_input_fields.length === 0 && (
                <div className="text-center text-muted-foreground py-8" data-testid="no-manual-fields-message">
                  <Edit3 className="h-6 w-6 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">Для этого инструмента не требуется ручной ввод данных</p>
                </div>
              )}
            </div>
          </TabsContent>

          {/* Автоматические расчеты */}
          <TabsContent value="calculated" className="px-6 pb-6">
            <div className="space-y-4">
              <h4 className="text-sm font-medium flex items-center gap-2" data-testid="heading-calculated-fields">
                <Calculator className="h-4 w-4" data-testid="icon-calculator" />
                Автоматически рассчитываемые поля
              </h4>
              <div className="grid gap-3 md:grid-cols-2">
                {instrumentConfig.auto_calculated_fields.map((field, index) => (
                  <div 
                    key={field} 
                    className="flex items-center justify-between p-3 bg-muted/50 rounded-lg hover-elevate"
                    data-testid={`calculated-field-${field}`}
                  >
                    <span className="text-sm font-medium" data-testid={`calculated-field-name-${field}`}>
                      {formatFieldName(field)}
                    </span>
                    <Badge variant="secondary" className="text-xs" data-testid={`calculated-badge-${field}`}>
                      Авто-расчет
                    </Badge>
                  </div>
                ))}
              </div>
              
              {instrumentConfig.auto_calculated_fields.length === 0 && (
                <div className="text-center text-muted-foreground py-8" data-testid="no-calculated-fields-message">
                  <Calculator className="h-6 w-6 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">Для этого инструмента нет автоматически рассчитываемых полей</p>
                </div>
              )}
              
              <Separator className="my-4" data-testid="separator-formulas" />
              
              <div className="space-y-3">
                <h5 className="text-sm font-medium text-muted-foreground" data-testid="heading-formulas">
                  Основные формулы расчета
                </h5>
                {instrumentConfig.main_formulas.map((formula, index) => (
                  <div 
                    key={index}
                    className="p-3 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-200 dark:border-blue-800 hover-elevate"
                    data-testid={`formula-${index}`}
                  >
                    <code className="text-sm text-blue-800 dark:text-blue-300" data-testid={`formula-code-${index}`}>
                      {formula}
                    </code>
                  </div>
                ))}
                {instrumentConfig.main_formulas.length === 0 && (
                  <div className="text-center text-muted-foreground py-4" data-testid="no-formulas-message">
                    <p className="text-sm">Формулы расчета будут добавлены позже</p>
                  </div>
                )}
              </div>
            </div>
          </TabsContent>

          {/* Ключевые метрики */}
          <TabsContent value="metrics" className="px-6 pb-6">
            <div className="space-y-4">
              <h4 className="text-sm font-medium flex items-center gap-2" data-testid="heading-key-metrics">
                <TrendingUp className="h-4 w-4" data-testid="icon-trending-up" />
                Ключевые показатели эффективности
              </h4>
              <div className="grid gap-3 md:grid-cols-2">
                {instrumentConfig.key_metrics.map((metric, index) => (
                  <div 
                    key={metric}
                    className="flex items-center justify-between p-3 bg-green-50 dark:bg-green-950/20 rounded-lg border border-green-200 dark:border-green-800 hover-elevate"
                    data-testid={`metric-${metric}`}
                  >
                    <span className="text-sm font-medium text-green-800 dark:text-green-300" data-testid={`metric-name-${metric}`}>
                      {formatFieldName(metric)}
                    </span>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs border-green-300 dark:border-green-600" data-testid={`metric-badge-${metric}`}>
                        KPI
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
              {instrumentConfig.key_metrics.length === 0 && (
                <div className="text-center text-muted-foreground py-8" data-testid="no-metrics-message">
                  <TrendingUp className="h-6 w-6 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">Ключевые метрики для этого инструмента еще не определены</p>
                </div>
              )}
            </div>
          </TabsContent>

          {/* Настройки расчетов */}
          <TabsContent value="settings" className="px-6 pb-6">
            <div className="space-y-4">
              <h4 className="text-sm font-medium flex items-center gap-2" data-testid="heading-settings">
                <Settings className="h-4 w-4" data-testid="icon-settings" />
                Настройки расчетов
              </h4>
              <div className="grid gap-4 md:grid-cols-2">
                {instrumentConfig.editable_calculation_fields.map((field, index) => (
                  <div key={field} className="space-y-2" data-testid={`setting-group-${field}`}>
                    <Label htmlFor={`setting-${field}`} className="text-sm" data-testid={`setting-label-${field}`}>
                      <div className="flex flex-col">
                        <span className="font-medium text-foreground">{formatFieldName(field)}</span>
                        <span className="text-xs text-muted-foreground font-normal">{getFieldEnglishName(field)}</span>
                      </div>
                    </Label>
                    <Input
                      id={`setting-${field}`}
                      value={settingsData[field] || ''}
                      onChange={(e) => handleSettingsChange(field, e.target.value)}
                      placeholder={`Настройка: ${formatFieldName(field).toLowerCase()}`}
                      data-testid={`setting-${field}`}
                      className="h-9"
                    />
                  </div>
                ))}
              </div>
              
              {instrumentConfig.editable_calculation_fields.length === 0 && (
                <div className="text-center text-muted-foreground py-8" data-testid="no-settings-message">
                  <Settings className="h-6 w-6 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">Для этого инструмента нет настраиваемых параметров расчета</p>
                </div>
              )}
              
              <div className="flex justify-end gap-2 mt-6 pt-4 border-t" data-testid="settings-actions">
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={handleResetData}
                  data-testid="button-reset-settings"
                >
                  Сбросить
                </Button>
                <Button 
                  size="sm" 
                  data-testid="button-save-settings"
                  onClick={() => {
                    // Settings are automatically saved through onDataUpdate
                    // This could trigger additional validation or confirmation
                    console.log('Settings saved for instrument:', instrumentKey);
                  }}
                >
                  Сохранить настройки
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}