import { 
  LineChart, 
  Line, 
  BarChart, 
  Bar, 
  PieChart, 
  Pie, 
  Cell,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from 'recharts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Download, TrendingUp, BarChart3, PieChart as PieChartIcon } from "lucide-react";

interface ChartDataPoint {
  name: string;
  value: number;
  [key: string]: string | number;
}

interface AnalyticsChartProps {
  title: string;
  description?: string;
  type: 'line' | 'bar' | 'pie';
  data: ChartDataPoint[];
  dataKey?: string;
  xAxisKey?: string;
  badge?: string;
  loading?: boolean;
  isMobile?: boolean;
  onExport?: () => void;
}

export default function AnalyticsChart({
  title,
  description,
  type,
  data,
  dataKey = 'value',
  xAxisKey = 'name',
  badge,
  loading = false,
  isMobile = false,
  onExport
}: AnalyticsChartProps) {
  const colors = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

  const handleExport = () => {
    console.log(`Exporting chart: ${title}`);
    onExport?.();
  };

  const getChartIcon = () => {
    const iconSize = isMobile ? 'h-4 w-4' : 'h-5 w-5';
    switch (type) {
      case 'line':
        return <TrendingUp className={iconSize} />;
      case 'bar':
        return <BarChart3 className={iconSize} />;
      case 'pie':
        return <PieChartIcon className={iconSize} />;
      default:
        return <BarChart3 className={iconSize} />;
    }
  };

  const renderChart = () => {
    if (loading) {
      return (
        <div className={`${isMobile ? 'h-48' : 'h-80'} flex items-center justify-center`}>
          <div className="text-center">
            <div className={`animate-spin rounded-full ${isMobile ? 'h-6 w-6' : 'h-8 w-8'} border-b-2 border-primary mx-auto mb-2`}></div>
            <p className={`${isMobile ? 'text-xs' : 'text-sm'} text-muted-foreground`}>Загрузка данных...</p>
          </div>
        </div>
      );
    }

    switch (type) {
      case 'line':
        return (
          <ResponsiveContainer width="100%" height={isMobile ? 200 : 320}>
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis 
                dataKey={xAxisKey} 
                stroke="hsl(var(--muted-foreground))"
                fontSize={isMobile ? 10 : 12}
                tick={isMobile ? { fontSize: 10 } : { fontSize: 12 }}
              />
              <YAxis 
                stroke="hsl(var(--muted-foreground))"
                fontSize={isMobile ? 10 : 12}
                tick={isMobile ? { fontSize: 10 } : { fontSize: 12 }}
              />
              <Tooltip 
                contentStyle={{
                  backgroundColor: 'hsl(var(--popover))',
                  border: '1px solid hsl(var(--popover-border))',
                  borderRadius: '6px'
                }}
              />
              <Legend />
              <Line 
                type="monotone" 
                dataKey={dataKey} 
                stroke="hsl(var(--primary))" 
                strokeWidth={2}
                dot={{ fill: 'hsl(var(--primary))', strokeWidth: 2, r: 4 }}
                activeDot={{ r: 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
        );

      case 'bar':
        return (
          <ResponsiveContainer width="100%" height={isMobile ? 200 : 320}>
            <BarChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis 
                dataKey={xAxisKey} 
                stroke="hsl(var(--muted-foreground))"
                fontSize={isMobile ? 10 : 12}
                tick={isMobile ? { fontSize: 10 } : { fontSize: 12 }}
              />
              <YAxis 
                stroke="hsl(var(--muted-foreground))"
                fontSize={isMobile ? 10 : 12}
                tick={isMobile ? { fontSize: 10 } : { fontSize: 12 }}
              />
              <Tooltip 
                contentStyle={{
                  backgroundColor: 'hsl(var(--popover))',
                  border: '1px solid hsl(var(--popover-border))',
                  borderRadius: '6px'
                }}
              />
              <Legend />
              <Bar 
                dataKey={dataKey} 
                fill="hsl(var(--primary))"
                radius={[4, 4, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        );

      case 'pie':
        return (
          <ResponsiveContainer width="100%" height={isMobile ? 200 : 320}>
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey={dataKey}
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{
                  backgroundColor: 'hsl(var(--popover))',
                  border: '1px solid hsl(var(--popover-border))',
                  borderRadius: '6px'
                }}
              />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        );

      default:
        return null;
    }
  };

  return (
    <Card className="hover-elevate" data-testid={`chart-${title.toLowerCase().replace(/\s+/g, '-')}`}>
      <CardHeader className={`flex ${isMobile ? 'flex-col space-y-2' : 'flex-row items-center justify-between'} gap-2 space-y-0 ${isMobile ? 'pb-2 px-3' : 'pb-4'}`}>
        <div className={`flex items-center gap-2 ${isMobile ? 'w-full' : ''}`}>
          {getChartIcon()}
          <div className={isMobile ? 'flex-1 min-w-0' : ''}>
            <CardTitle className={`${isMobile ? 'text-sm' : 'text-base'} font-medium ${isMobile ? 'truncate' : ''}`} data-testid={`text-chart-title-${title.toLowerCase().replace(/\s+/g, '-')}`}>
              {title}
            </CardTitle>
            {description && !isMobile && (
              <CardDescription className="mt-1" data-testid={`text-chart-description-${title.toLowerCase().replace(/\s+/g, '-')}`}>
                {description}
              </CardDescription>
            )}
          </div>
        </div>
        <div className={`flex items-center gap-2 ${isMobile ? 'w-full justify-between' : ''}`}>
          {badge && (
            <Badge variant="secondary" className={`text-xs ${isMobile ? 'flex-shrink-0' : ''}`} data-testid={`badge-chart-${title.toLowerCase().replace(/\s+/g, '-')}`}>
              {badge}
            </Badge>
          )}
          <Button 
            variant="ghost" 
            size={isMobile ? 'sm' : 'sm'} 
            onClick={handleExport}
            className={isMobile ? 'h-8 w-8 p-0' : ''}
            data-testid={`button-export-chart-${title.toLowerCase().replace(/\s+/g, '-')}`}
          >
            <Download className={isMobile ? 'h-3 w-3' : 'h-4 w-4'} />
          </Button>
        </div>
      </CardHeader>
      <CardContent className={`pt-0 ${isMobile ? 'px-3 pb-3' : ''}`}>
        {renderChart()}
      </CardContent>
    </Card>
  );
}