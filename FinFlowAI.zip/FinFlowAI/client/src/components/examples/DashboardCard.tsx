import DashboardCard from '../DashboardCard';

export default function DashboardCardExample() {
  return (
    <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-3 p-6">
      <DashboardCard
        title="Общая выручка"
        value="12,450,000 ₽"
        description="За текущий месяц"
        trend="up"
        trendValue="+15.3%"
        badge="Рост"
        badgeVariant="default"
        onExport={() => console.log('Export revenue data')}
        onViewDetails={() => console.log('View revenue details')}
      />
      
      <DashboardCard
        title="Коэффициент ликвидности"
        value="2.34"
        description="Нормальный уровень"
        trend="neutral"
        trendValue="0%"
        badge="Стабильно"
        badgeVariant="secondary"
        onExport={() => console.log('Export liquidity data')}
        onViewDetails={() => console.log('View liquidity details')}
      />
      
      <DashboardCard
        title="Чистая прибыль"
        value="2,850,000 ₽"
        description="Снижение по сравнению с прошлым месяцем"
        trend="down"
        trendValue="-8.2%"
        badge="Внимание"
        badgeVariant="destructive"
        onExport={() => console.log('Export profit data')}
        onViewDetails={() => console.log('View profit details')}
      />

      <DashboardCard
        title="Анализ рентабельности"
        value="Loading..."
        loading={true}
      />
    </div>
  );
}