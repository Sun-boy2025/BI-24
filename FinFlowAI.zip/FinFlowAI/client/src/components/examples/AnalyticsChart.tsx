import AnalyticsChart from '../AnalyticsChart';

export default function AnalyticsChartExample() {
  // todo: remove mock functionality - sample data for demo
  const lineData = [
    { name: 'Янв', value: 4000, revenue: 2400, profit: 400 },
    { name: 'Фев', value: 3000, revenue: 1398, profit: 210 },
    { name: 'Мар', value: 2000, revenue: 9800, profit: 290 },
    { name: 'Апр', value: 2780, revenue: 3908, profit: 300 },
    { name: 'Май', value: 1890, revenue: 4800, profit: 181 },
    { name: 'Июн', value: 2390, revenue: 3800, profit: 250 },
  ];

  const barData = [
    { name: 'Q1', value: 12450000 },
    { name: 'Q2', value: 15230000 },
    { name: 'Q3', value: 18920000 },
    { name: 'Q4', value: 21850000 },
  ];

  const pieData = [
    { name: 'Себестоимость', value: 45 },
    { name: 'Операционные расходы', value: 30 },
    { name: 'Налоги', value: 15 },
    { name: 'Чистая прибыль', value: 10 },
  ];

  return (
    <div className="grid gap-6 p-6">
      <div className="grid gap-6 md:grid-cols-2">
        <AnalyticsChart
          title="Динамика выручки"
          description="Помесячная динамика за 2024 год"
          type="line"
          data={lineData}
          dataKey="revenue"
          badge="Тренд"
          onExport={() => console.log('Export revenue trend chart')}
        />
        
        <AnalyticsChart
          title="Прибыль по кварталам"
          description="Квартальная прибыль в рублях"
          type="bar"
          data={barData}
          badge="Квартал"
          onExport={() => console.log('Export quarterly profit chart')}
        />
      </div>
      
      <div className="grid gap-6 md:grid-cols-2">
        <AnalyticsChart
          title="Структура расходов"
          description="Распределение затрат компании"
          type="pie"
          data={pieData}
          badge="Анализ"
          onExport={() => console.log('Export cost structure chart')}
        />
        
        <AnalyticsChart
          title="Загрузка данных..."
          type="bar"
          data={[]}
          loading={true}
        />
      </div>
    </div>
  );
}