import { SidebarProvider } from "@/components/ui/sidebar";
import AppSidebar from '../Sidebar';

export default function SidebarExample() {
  const style = {
    "--sidebar-width": "18rem",
    "--sidebar-width-icon": "4rem",
  };

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <AppSidebar 
          selectedItem="financial_health"
          onItemSelect={(id) => console.log('Selected item:', id)}
        />
        <div className="flex-1 p-8 bg-background">
          <div className="text-muted-foreground">
            Контентная область - выбранный элемент будет отображаться здесь
          </div>
        </div>
      </div>
    </SidebarProvider>
  );
}