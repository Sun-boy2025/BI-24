import AIAssistant from '../AIAssistant';

export default function AIAssistantExample() {
  return (
    <div className="p-6 max-w-4xl">
      <AIAssistant />
    </div>
  );
}