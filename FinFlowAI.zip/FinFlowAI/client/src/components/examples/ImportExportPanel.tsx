import ImportExportPanel from '../ImportExportPanel';

export default function ImportExportPanelExample() {
  return (
    <div className="p-6">
      <ImportExportPanel />
    </div>
  );
}