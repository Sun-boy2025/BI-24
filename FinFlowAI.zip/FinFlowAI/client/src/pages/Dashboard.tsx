import { useState, useEffect } from "react";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import AppSidebar from "@/components/Sidebar";
import Header from "@/components/Header";
import DashboardCard from "@/components/DashboardCard";
import AnalyticsChart from "@/components/AnalyticsChart";
import ImportExportPanel from "@/components/ImportExportPanel";
import AIAssistant from "@/components/AIAssistant";
import DataEntryPanel from "@/components/DataEntryPanel";
import HierarchicalTable from "@/components/HierarchicalTable";
import HierarchicalMovementsTable from "@/components/HierarchicalMovementsTable";
import InstrumentSpecificFields from "@/components/InstrumentSpecificFields";
import { 
  getDashboardCards, 
  getRevenueChartData, 
  getProfitChartData, 
  getExpenseStructureData,
  convertToMovementData 
} from "@/data/unifiedFinancialData";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  TrendingUp, 
  DollarSign, 
  Activity, 
  Target,
  Calendar,
  Users,
  BarChart3
} from "lucide-react";

export default function Dashboard() {
  const [selectedItem, setSelectedItem] = useState("financial_health");
  const [selectedCompany, setSelectedCompany] = useState("ООО «Ромашка»");
  const [isMobile, setIsMobile] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => {
    const checkScreenSize = () => {
      setIsMobile(window.innerWidth < 768);
      if (window.innerWidth >= 768) {
        setSidebarOpen(false);
      }
    };

    checkScreenSize();
    window.addEventListener('resize', checkScreenSize);
    return () => window.removeEventListener('resize', checkScreenSize);
  }, []);

  // Унифицированные данные для всех компонентов
  const dashboardCards = getDashboardCards();

  const revenueData = getRevenueChartData();

  const expenseStructure = getExpenseStructureData();

  const profitData = getProfitChartData();

  const handleItemSelect = (itemId: string) => {
    setSelectedItem(itemId);
    if (isMobile) {
      setSidebarOpen(false);
    }
    console.log(`Dashboard: Selected item changed to ${itemId}`);
  };

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
    console.log('Sidebar toggled:', !sidebarOpen);
  };

  const getItemTitle = (itemId: string) => {
    const itemTitles: Record<string, string> = {
      financial_health: "Финансовое здоровье компании",
      profitability_analysis: "Анализ прибыльности", 
      liquidity_ratios: "Коэффициенты ликвидности",
      debt_analysis: "Анализ задолженности",
      efficiency_ratios: "Коэффициенты эффективности",
      growth_trends: "Тренды роста",
      cash_flow_analysis: "Анализ денежных потоков",
      break_even_analysis: "Точка безубыточности",
      cost_structure: "Структура затрат",
      revenue_analysis: "Анализ выручки",
      margin_analysis: "Анализ маржинальности",
      working_capital: "Оборотный капитал",
      data_entry: "Управление финансовыми данными",
      import_1c: "Импорт данных из 1С",
      export_reports: "Экспорт отчетов",
      ai_assistant: "AI-помощник аналитика"
    };
    return itemTitles[itemId] || "Аналитический отчет";
  };

  const renderMainContent = () => {
    switch (selectedItem) {
      case "data_entry":
        return (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-semibold" data-testid="text-content-title">
                  {getItemTitle(selectedItem)}
                </h2>
                <p className="text-muted-foreground">
                  Ручной ввод и генерация финансовых данных
                </p>
              </div>
              <Badge variant="secondary" className="px-3 py-1">
                Новая функция
              </Badge>
            </div>
            <DataEntryPanel />
          </div>
        );
        
      case "import_1c":
      case "export_reports":
        return (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-semibold" data-testid="text-content-title">
                  {getItemTitle(selectedItem)}
                </h2>
                <p className="text-muted-foreground">
                  Управление импортом и экспортом данных
                </p>
              </div>
            </div>
            <ImportExportPanel />
          </div>
        );

      case "ai_assistant":
        return (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-semibold" data-testid="text-content-title">
                  {getItemTitle(selectedItem)}
                </h2>
                <p className="text-muted-foreground">
                  Интеллектуальный анализ ваших бизнес-данных
                </p>
              </div>
              <Badge variant="default" className="px-3 py-1">
                Powered by AI
              </Badge>
            </div>
            <AIAssistant />
          </div>
        );

      default:
        return (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-semibold" data-testid="text-content-title">
                  {getItemTitle(selectedItem)}
                </h2>
                <p className="text-muted-foreground">
                  Подробный анализ и рекомендации
                </p>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="px-3 py-1">
                  <Calendar className="h-3 w-3 mr-1" />
                  4 кв. {new Date().getFullYear()}
                </Badge>
                <Button variant="outline" size="sm" data-testid="button-change-period">
                  Изменить период
                </Button>
              </div>
            </div>

            <Tabs defaultValue="data" className="w-full">
              <TabsList className="grid w-full grid-cols-5">
                <TabsTrigger value="data" data-testid="tab-data">
                  Данные
                </TabsTrigger>
                <TabsTrigger value="overview" data-testid="tab-overview">
                  Обзор
                </TabsTrigger>
                <TabsTrigger value="movements" data-testid="tab-movements">
                  Движения
                </TabsTrigger>
                <TabsTrigger value="charts" data-testid="tab-charts">
                  Графики
                </TabsTrigger>
                <TabsTrigger value="details" data-testid="tab-details">
                  Детализация
                </TabsTrigger>
              </TabsList>

              <TabsContent value="data" className="space-y-6">
                <div className="grid gap-6 lg:grid-cols-2">
                  <div className="lg:col-span-1">
                    <HierarchicalTable 
                      companyId="demo-company"
                      year={new Date().getFullYear()}
                      instrumentKey={selectedItem}
                      onPeriodSelect={(period) => {
                        console.log('Period selected:', period);
                        // Handle period selection - could open detailed view
                      }}
                    />
                  </div>
                  <div className="lg:col-span-1">
                    <InstrumentSpecificFields 
                      instrumentKey={selectedItem}
                      onDataUpdate={(data) => {
                        console.log('Instrument data updated:', data);
                        // Handle data updates for the selected instrument
                      }}
                    />
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="overview" className="space-y-6">
                <div className={`grid gap-4 ${isMobile ? 'grid-cols-1' : 'md:grid-cols-2 lg:grid-cols-4'}`}>
                  {dashboardCards.map((card, index) => (
                    <DashboardCard
                      key={index}
                      title={card.title}
                      value={card.value}
                      description={card.description}
                      trend={card.trend}
                      trendValue={card.trendValue}
                      badge={card.badge}
                      badgeVariant={card.badgeVariant}
                      isMobile={isMobile}
                      onExport={() => console.log(`Export ${card.title} data`)}
                      onViewDetails={() => console.log(`View ${card.title} details`)}
                    />
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="movements" className="space-y-6">
                <HierarchicalMovementsTable 
                  title="Движение денежных средств"
                  data={convertToMovementData()}
                  onPeriodSelect={(period) => {
                    console.log('Selected period for detailed analysis:', period);
                    // Could navigate to detailed view or show modal with period-specific data
                  }}
                />
              </TabsContent>

              <TabsContent value="charts" className="space-y-6">
                <div className="grid gap-6">
                  <AnalyticsChart
                    title="Динамика выручки по месяцам"
                    description="Помесячная выручка за 2025 год"
                    type="line"
                    data={revenueData}
                    badge="Тренд"
                    isMobile={isMobile}
                    onExport={() => console.log('Export revenue chart')}
                  />
                  
                  <div className={`grid gap-6 ${isMobile ? 'grid-cols-1' : 'md:grid-cols-2'}`}>
                    <AnalyticsChart
                      title="Структура расходов"
                      description="Распределение операционных расходов"
                      type="pie"
                      data={expenseStructure}
                      badge="Анализ"
                      isMobile={isMobile}
                      onExport={() => console.log('Export expense structure')}
                    />
                    
                    <AnalyticsChart
                      title="Квартальная прибыль"
                      description="Чистая прибыль по кварталам"
                      type="bar"
                      data={profitData}
                      badge="Квартал"
                      isMobile={isMobile}
                      onExport={() => console.log('Export quarterly profit')}
                    />
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="details" className="space-y-6">
                <div className={`grid gap-6 ${isMobile ? 'grid-cols-1' : 'md:grid-cols-3'}`}>
                  <div className={isMobile ? '' : 'md:col-span-2'}>
                    <div className="bg-card border border-card-border rounded-lg p-6">
                      <h3 className="text-lg font-semibold mb-4" data-testid="text-detailed-analysis">
                        Детальный анализ показателей
                      </h3>
                      <div className="space-y-4 text-sm">
                        <div className="p-4 bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-800 rounded-lg">
                          <div className="flex items-center gap-2 mb-2">
                            <TrendingUp className="h-4 w-4 text-green-500" />
                            <strong>Положительные тенденции:</strong>
                          </div>
                          <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                            <li>Выручка растет стабильными темпами (+15.3%)</li>
                            <li>Коэффициент ликвидности в норме (2.34)</li>
                            <li>ROI выше среднего по отрасли (18.5%)</li>
                          </ul>
                        </div>
                        
                        <div className="p-4 bg-yellow-50 dark:bg-yellow-950/20 border border-yellow-200 dark:border-yellow-800 rounded-lg">
                          <div className="flex items-center gap-2 mb-2">
                            <Activity className="h-4 w-4 text-yellow-500" />
                            <strong>Требуют внимания:</strong>
                          </div>
                          <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                            <li>Снижение чистой прибыли на 8.2%</li>
                            <li>Увеличение доли операционных расходов</li>
                            <li>Необходимо оптимизировать структуру затрат</li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="bg-card border border-card-border rounded-lg p-4">
                      <h4 className="font-semibold mb-3 flex items-center gap-2">
                        <Users className="h-4 w-4" />
                        Команда
                      </h4>
                      <div className="text-sm text-muted-foreground space-y-2">
                        <p><strong>Компания:</strong> {selectedCompany}</p>
                        <p><strong>ИНН:</strong> 7707083893</p>
                        <p><strong>Налоговый режим:</strong> УСН 15%</p>
                        <p><strong>Аналитик:</strong> Анна Иванова</p>
                      </div>
                    </div>
                    
                    <div className="bg-card border border-card-border rounded-lg p-4">
                      <h4 className="font-semibold mb-3 flex items-center gap-2">
                        <BarChart3 className="h-4 w-4" />
                        Быстрые действия
                      </h4>
                      <div className="space-y-2">
                        <Button variant="outline" size="sm" className="w-full" data-testid="button-generate-report">
                          Создать отчет
                        </Button>
                        <Button variant="outline" size="sm" className="w-full" data-testid="button-compare-periods">
                          Сравнить периоды
                        </Button>
                        <Button variant="outline" size="sm" className="w-full" data-testid="button-export-data">
                          Экспорт данных
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        );
    }
  };

  return (
    <div className="flex h-screen w-full bg-background">
      <SidebarProvider
        open={isMobile ? sidebarOpen : undefined}
        onOpenChange={isMobile ? setSidebarOpen : undefined}
        style={{
          "--sidebar-width": isMobile ? "16rem" : "18rem",
          "--sidebar-width-icon": "4rem",
        } as React.CSSProperties}
      >
        <AppSidebar 
          selectedItem={selectedItem}
          onItemSelect={handleItemSelect}
          isMobile={isMobile}
        />
        
        <div className="flex flex-col flex-1 overflow-hidden min-w-0">
          <header className="flex items-center justify-between px-4 lg:px-6 py-3 border-b bg-card border-card-border flex-shrink-0">
            <div className="flex items-center gap-2 lg:gap-4 min-w-0 flex-1">
              <SidebarTrigger 
                data-testid="button-sidebar-toggle" 
                onClick={isMobile ? toggleSidebar : undefined}
                className="lg:hidden flex-shrink-0"
              />
              <div className="flex flex-col min-w-0 flex-1">
                <h1 className="text-lg lg:text-xl font-semibold text-foreground truncate" data-testid="text-main-title">
                  {isMobile ? "BA Pro" : "BusinessAnalytics Pro"}
                </h1>
                <p className="text-xs lg:text-sm text-muted-foreground truncate" data-testid="text-company-name">
                  {isMobile ? "ООО Ромашка" : selectedCompany}
                </p>
              </div>
            </div>

            <div className="flex-shrink-0">
              <Header isMobile={isMobile} />
            </div>
          </header>

          <main className="flex-1 overflow-y-auto p-4 lg:p-6 lg:pl-8" data-testid="main-content">
            {renderMainContent()}
          </main>

          {/* Mobile sidebar overlay */}
          {isMobile && sidebarOpen && (
            <div 
              className="fixed inset-0 bg-black/50 z-40 lg:hidden" 
              onClick={() => setSidebarOpen(false)}
              data-testid="sidebar-overlay"
            />
          )}
        </div>
      </SidebarProvider>
    </div>
  );
}